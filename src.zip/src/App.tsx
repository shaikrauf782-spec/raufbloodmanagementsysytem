import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.js';
import { Footer } from './components/Footer.js';
import { DbStatusBanner } from './components/DbStatusBanner.js';
import { QuickRequestModal } from './components/QuickRequestModal.js';
import { HomePage } from './pages/HomePage.js';
import { FindBloodPage } from './pages/FindBloodPage.js';
import { DonorRegistrationPage } from './pages/DonorRegistrationPage.js';
import { HospitalRegistrationPage } from './pages/HospitalRegistrationPage.js';
import { LoginPage } from './pages/LoginPage.js';
import { AdminDashboardPage } from './pages/AdminDashboardPage.js';
import { DonorManagementPage } from './pages/DonorManagementPage.js';
import { BloodInventoryPage } from './pages/BloodInventoryPage.js';
import { BloodRequestsPage } from './pages/BloodRequestsPage.js';
import { DonationsPage } from './pages/DonationsPage.js';
import { DonorDashboardPage } from './pages/DonorDashboardPage.js';
import { HospitalDashboardPage } from './pages/HospitalDashboardPage.js';
import { AboutPage } from './pages/AboutPage.js';
import { FaqPage } from './pages/FaqPage.js';
import { ContactPage } from './pages/ContactPage.js';
import { DatabaseStudioPage } from './pages/DatabaseStudioPage.js';
import { BloodGroup, BloodStockItem, DashboardStats, DbStatusInfo, User } from './types.js';
import { api } from './api/client.js';

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Database status
  const [dbStatus, setDbStatus] = useState<DbStatusInfo | null>(null);
  const [tableCounts, setTableCounts] = useState<Record<string, number>>({});
  const [isReconnecting, setIsReconnecting] = useState(false);

  // Common datasets for home and quick actions
  const [inventory, setInventory] = useState<BloodStockItem[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);

  // Quick Request Modal
  const [quickRequestOpen, setQuickRequestOpen] = useState(false);
  const [prefilledGroup, setPrefilledGroup] = useState<BloodGroup>('O+');

  useEffect(() => {
    // Check DB status and load initial metrics
    loadGlobalData();
  }, []);

  const loadGlobalData = async () => {
    try {
      const dbRes = await api.getDbStatus();
      setDbStatus(dbRes.database);
      setTableCounts(dbRes.tableCounts);
    } catch (err) {
      console.warn('Failed to load DB status:', err);
    }

    try {
      const [invRes, statsRes] = await Promise.all([
        api.getInventory(),
        api.getDashboardStats(),
      ]);
      setInventory(invRes.inventory);
      setStats(statsRes.stats);
    } catch (err) {
      console.warn('Failed to load metrics:', err);
    }
  };

  const handleReconnect = async () => {
    setIsReconnecting(true);
    try {
      const res = await api.reconnectDb();
      setDbStatus(res.status);
      await loadGlobalData();
    } catch (err) {
      console.error('Reconnect error:', err);
    } finally {
      setIsReconnecting(false);
    }
  };

  const handleOpenRequestWithGroup = (group: BloodGroup) => {
    setPrefilledGroup(group);
    setQuickRequestOpen(true);
  };

  const handleLoginSuccess = (user: User, role: string) => {
    setCurrentUser(user);
    if (role === 'admin') setCurrentPage('admin-dashboard');
    else if (role === 'hospital') setCurrentPage('hospital-dashboard');
    else setCurrentPage('donor-dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentPage('home');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-slate-900 font-sans">
      {/* 1. MySQL Real-Time Connection Diagnostic Banner */}
      <DbStatusBanner
        status={dbStatus}
        tableCounts={tableCounts}
        onReconnect={handleReconnect}
        isReconnecting={isReconnecting}
      />

      {/* 2. Primary Navigation Bar */}
      <Navbar
        currentPage={currentPage}
        onNavigate={(p) => {
          setCurrentPage(p);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        currentUser={currentUser}
        onLogout={handleLogout}
        onOpenQuickRequest={() => setQuickRequestOpen(true)}
      />

      {/* 3. Main Routed View */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            onNavigate={(p) => { setCurrentPage(p); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
            inventory={inventory}
            stats={stats}
            onOpenQuickRequest={() => setQuickRequestOpen(true)}
          />
        )}

        {currentPage === 'find-blood' && (
          <FindBloodPage
            onNavigate={setCurrentPage}
            onRequestBlood={handleOpenRequestWithGroup}
          />
        )}

        {currentPage === 'register-donor' && (
          <DonorRegistrationPage
            onNavigate={setCurrentPage}
            onRegistered={() => {
              setCurrentPage('donor-dashboard');
              loadGlobalData();
            }}
          />
        )}

        {currentPage === 'register-hospital' && (
          <HospitalRegistrationPage
            onNavigate={setCurrentPage}
            onRegistered={() => {
              setCurrentPage('hospital-dashboard');
              loadGlobalData();
            }}
          />
        )}

        {currentPage === 'login-donor' && (
          <LoginPage
            initialRole="donor"
            onLoginSuccess={handleLoginSuccess}
            onNavigate={setCurrentPage}
          />
        )}

        {currentPage === 'login-hospital' && (
          <LoginPage
            initialRole="hospital"
            onLoginSuccess={handleLoginSuccess}
            onNavigate={setCurrentPage}
          />
        )}

        {currentPage === 'login-admin' && (
          <LoginPage
            initialRole="admin"
            onLoginSuccess={handleLoginSuccess}
            onNavigate={setCurrentPage}
          />
        )}

        {currentPage === 'admin-dashboard' && (
          <AdminDashboardPage
            onNavigate={setCurrentPage}
            onRequestBlood={handleOpenRequestWithGroup}
          />
        )}

        {currentPage === 'donor-dashboard' && (
          <DonorDashboardPage
            currentUser={currentUser}
            onNavigate={setCurrentPage}
          />
        )}

        {currentPage === 'hospital-dashboard' && (
          <HospitalDashboardPage
            currentUser={currentUser}
            onNavigate={setCurrentPage}
            onOpenQuickRequest={() => setQuickRequestOpen(true)}
          />
        )}

        {currentPage === 'donors' && (
          <DonorManagementPage
            onNavigate={setCurrentPage}
          />
        )}

        {currentPage === 'inventory' && (
          <BloodInventoryPage
            onNavigate={setCurrentPage}
            onRequestBlood={handleOpenRequestWithGroup}
          />
        )}

        {currentPage === 'requests' && (
          <BloodRequestsPage
            onNavigate={setCurrentPage}
            onOpenQuickRequest={() => setQuickRequestOpen(true)}
          />
        )}

        {currentPage === 'donations' && (
          <DonationsPage
            onNavigate={setCurrentPage}
          />
        )}

        {currentPage === 'about' && (
          <AboutPage
            onNavigate={setCurrentPage}
          />
        )}

        {currentPage === 'faq' && (
          <FaqPage
            onNavigate={setCurrentPage}
          />
        )}

        {currentPage === 'contact' && (
          <ContactPage
            onNavigate={setCurrentPage}
          />
        )}

        {currentPage === 'database-studio' && (
          <DatabaseStudioPage
            status={dbStatus}
            tableCounts={tableCounts}
            onReconnect={handleReconnect}
            isReconnecting={isReconnecting}
          />
        )}
      </main>

      {/* 4. Footer */}
      <Footer onNavigate={(p) => { setCurrentPage(p); window.scrollTo({ top: 0, behavior: 'smooth' }); }} />

      {/* 5. Quick Emergency Requisition Modal */}
      <QuickRequestModal
        isOpen={quickRequestOpen}
        onClose={() => setQuickRequestOpen(false)}
        onSuccess={() => {
          loadGlobalData();
          if (currentPage === 'requests' || currentPage === 'admin-dashboard') {
            // refresh
          }
        }}
      />
    </div>
  );
}
