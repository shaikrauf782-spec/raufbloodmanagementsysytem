export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export interface User {
  id: number;
  email: string;
  name: string;
  role: 'admin' | 'donor' | 'hospital' | 'staff';
  phone?: string;
  is_verified?: number;
}

export interface Donor {
  id: number;
  user_id?: number | null;
  donor_code: string;
  full_name: string;
  dob: string;
  gender: 'Male' | 'Female' | 'Other';
  blood_group: BloodGroup;
  phone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  weight_kg: number;
  last_donation_date?: string | null;
  eligibility_status: 'Eligible' | 'Temporarily Ineligible' | 'Permanently Ineligible' | 'Under Review';
  medical_notes?: string;
  emergency_contact_name?: string;
  emergency_contact_phone?: string;
  total_donations_count: number;
  created_at: string;
}

export interface Hospital {
  id: number;
  user_id?: number | null;
  hospital_code: string;
  name: string;
  registration_number: string;
  contact_person: string;
  designation?: string;
  phone: string;
  emergency_phone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  verification_status: 'Pending' | 'Verified' | 'Rejected';
  verified_by_user_id?: number | null;
  verified_at?: string | null;
  rejection_reason?: string | null;
  created_at: string;
}

export interface BloodStockItem {
  blood_group: BloodGroup;
  component_type: string;
  available_units: number;
  reserved_units: number;
  low_threshold: number;
  critical_threshold: number;
  status: 'Optimal' | 'Adequate' | 'Low' | 'Critical';
}

export interface BloodUnit {
  id: number;
  unit_id: string;
  blood_bank_id: number;
  donor_id?: number | null;
  blood_group: BloodGroup;
  component_type: string;
  volume_ml: number;
  collection_date: string;
  expiry_date: string;
  storage_location: string;
  testing_status: 'Tested - Safe' | 'Pending Testing' | 'Reactive - Quarantined';
  unit_status: 'Available' | 'Reserved' | 'Issued' | 'Discarded - Expired' | 'Discarded - Contaminated';
  issued_to_hospital_id?: number | null;
  created_at: string;
}

export interface BloodRequest {
  id: number;
  request_code: string;
  hospital_id?: number | null;
  patient_name: string;
  patient_ref_id: string;
  hospital_name: string;
  blood_group: BloodGroup;
  component_type: string;
  units_required: number;
  units_fulfilled: number;
  required_date: string;
  priority: 'Standard' | 'Urgent' | 'Emergency - Critical';
  status: 'Pending' | 'Approved' | 'Partially Fulfilled' | 'Fulfilled' | 'Rejected' | 'Cancelled';
  contact_number: string;
  doctor_name?: string;
  diagnosis_reason?: string;
  additional_notes?: string;
  approved_by_user_id?: number | null;
  approved_at?: string | null;
  fulfilled_at?: string | null;
  rejection_reason?: string | null;
  created_at: string;
}

export interface Donation {
  id: number;
  donation_code: string;
  donor_id: number;
  blood_bank_id: number;
  donation_date: string;
  blood_group: string;
  component_type: string;
  units_donated: number;
  hemoglobin_level: number;
  blood_pressure: string;
  pulse_rate: number;
  donation_status: 'Completed' | 'Screening Failed' | 'Adverse Reaction' | 'Cancelled';
  nurse_or_phlebotomist: string;
  remarks?: string;
  certificate_issued: number;
  created_at: string;
}

export interface DashboardStats {
  totalDonors: number;
  totalBloodUnits: number;
  totalBloodRequests: number;
  pendingRequests: number;
  approvedRequests: number;
  fulfilledRequests: number;
  completedDonations: number;
  bloodGroupDistribution: Array<{
    group: BloodGroup;
    units: number;
    lowThreshold: number;
    isLow: boolean;
  }>;
  lowStockAlerts: any[];
  recentActivities: any[];
}

export interface DbStatusInfo {
  connected: boolean;
  host: string;
  port: number;
  user: string;
  database: string;
  errorMessage?: string;
  errorCode?: string;
  lastChecked: string;
  activeStorage: 'mysql' | 'memory-mirror';
  poolStats?: {
    activeConnections: number;
  };
}
