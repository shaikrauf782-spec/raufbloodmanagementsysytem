import React, { useState } from 'react';
import { AlertTriangle, X, CheckCircle2, Droplet, Clock } from 'lucide-react';
import { BloodGroup } from '../types.js';
import { api } from '../api/client.js';

interface QuickRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const QuickRequestModal: React.FC<QuickRequestModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    patient_name: '',
    patient_ref_id: '',
    hospital_name: '',
    blood_group: 'O+' as BloodGroup,
    component_type: 'Whole Blood',
    units_required: 2,
    required_date: new Date().toISOString().split('T')[0],
    priority: 'Emergency - Critical' as 'Standard' | 'Urgent' | 'Emergency - Critical',
    contact_number: '',
    doctor_name: '',
    diagnosis_reason: '',
    additional_notes: '',
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await api.createRequest(formData);
      setSuccessMsg(`Emergency request ${res.request.request_code} logged into MySQL database! Priority: ${formData.priority}`);
      setTimeout(() => {
        setSuccessMsg(null);
        onSuccess();
        onClose();
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Failed to submit blood request');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-red-200 animate-in fade-in zoom-in-95">
        <div className="p-5 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-t-2xl flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-white/20 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-heading font-bold text-base">Emergency Blood Requisition</h3>
              <p className="text-xs text-red-100">Immediate hospital transfusion triage</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-white/10 rounded-lg text-white/80 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
              {error}
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Patient Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. John Doe"
                value={formData.patient_name}
                onChange={(e) => setFormData({ ...formData, patient_name: e.target.value })}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Patient Ref/Hospital ID</label>
              <input
                type="text"
                placeholder="e.g. PT-9901"
                value={formData.patient_ref_id}
                onChange={(e) => setFormData({ ...formData, patient_ref_id: e.target.value })}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Hospital Name *</label>
            <input
              type="text"
              required
              placeholder="e.g. St. Jude General Hospital"
              value={formData.hospital_name}
              onChange={(e) => setFormData({ ...formData, hospital_name: e.target.value })}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Blood Group Required *</label>
              <select
                value={formData.blood_group}
                onChange={(e) => setFormData({ ...formData, blood_group: e.target.value as BloodGroup })}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500 font-bold text-red-700"
              >
                {(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as BloodGroup[]).map((bg) => (
                  <option key={bg} value={bg}>{bg}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Units Required *</label>
              <input
                type="number"
                min="1"
                max="10"
                required
                value={formData.units_required}
                onChange={(e) => setFormData({ ...formData, units_required: Number(e.target.value) })}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500 font-bold"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Priority Level</label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value as any })}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500 font-semibold"
              >
                <option value="Emergency - Critical">🚨 Emergency - Critical (&lt; 1 hr)</option>
                <option value="Urgent">⚠️ Urgent (Within 12 hrs)</option>
                <option value="Standard">Standard Scheduled Surgery</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Emergency Contact Phone *</label>
              <input
                type="tel"
                required
                placeholder="+1 (555) 000-0000"
                value={formData.contact_number}
                onChange={(e) => setFormData({ ...formData, contact_number: e.target.value })}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Attending Physician / Surgeon</label>
            <input
              type="text"
              placeholder="e.g. Dr. Jennifer Vance"
              value={formData.doctor_name}
              onChange={(e) => setFormData({ ...formData, doctor_name: e.target.value })}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Clinical Diagnosis & Reason</label>
            <textarea
              rows={2}
              placeholder="e.g. Hemorrhagic shock, major cardiac surgery, acute leukemia..."
              value={formData.diagnosis_reason}
              onChange={(e) => setFormData({ ...formData, diagnosis_reason: e.target.value })}
              className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 text-xs font-bold rounded-lg bg-red-600 text-white hover:bg-red-700 disabled:opacity-50 shadow-md shadow-red-600/30 flex items-center gap-1.5"
            >
              {loading ? 'Submitting...' : 'Transmit Emergency Request'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
