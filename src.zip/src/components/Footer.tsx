import React from 'react';
import { Droplet, Heart, Phone, Mail, MapPin, ShieldCheck, Database, FileText } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-[#14243A] text-slate-300 pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800">
          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center text-white shadow-lg shadow-red-600/30">
                <Droplet className="w-5 h-5 fill-white" />
              </div>
              <span className="font-heading font-extrabold text-2xl tracking-tight text-white">
                RAUF <span className="text-red-500">BLOOD SYSTEM</span>
              </span>
            </div>

            <p className="text-sm text-slate-400 max-w-sm leading-relaxed">
              Every Drop Counts. Every Donor Matters. Rauf Blood Management System is a certified, real-time blood bank management platform connecting donors, hospitals, and medical centers to prevent transfusion delays.
            </p>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3 text-xs">
              <div className="w-9 h-9 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                <Phone className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[11px] uppercase tracking-wider text-slate-400 block font-semibold">
                  24/7 Emergency Transfusion Desk
                </span>
                <span className="text-base font-bold text-white tracking-wide">
                  +1 (555) 019-2834
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Licensed Blood Bank • ID: BB-LIC-2024-001</span>
            </div>
          </div>

          {/* Quick Services */}
          <div>
            <h4 className="font-heading font-bold text-sm text-white uppercase tracking-wider mb-4">
              Blood Services
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button onClick={() => onNavigate('find-blood')} className="hover:text-white transition-colors cursor-pointer">
                  Find Blood Available
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('inventory')} className="hover:text-white transition-colors cursor-pointer">
                  Blood Group Stock (A, B, AB, O)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('requests')} className="hover:text-white transition-colors cursor-pointer">
                  Hospital Blood Requests
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('register-donor')} className="hover:text-white transition-colors cursor-pointer">
                  Become a Voluntary Donor
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('register-hospital')} className="hover:text-white transition-colors cursor-pointer">
                  Hospital Registration
                </button>
              </li>
            </ul>
          </div>

          {/* Management Portals */}
          <div>
            <h4 className="font-heading font-bold text-sm text-white uppercase tracking-wider mb-4">
              System Portals
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button onClick={() => onNavigate('admin-dashboard')} className="hover:text-white transition-colors cursor-pointer text-red-400 font-semibold">
                  Admin Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('donor-dashboard')} className="hover:text-white transition-colors cursor-pointer">
                  Donor Dashboard & Card
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('hospital-dashboard')} className="hover:text-white transition-colors cursor-pointer">
                  Hospital Transfusion Portal
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('donors')} className="hover:text-white transition-colors cursor-pointer">
                  Donor Directory
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('donations')} className="hover:text-white transition-colors cursor-pointer">
                  Donation History & Logs
                </button>
              </li>
            </ul>
          </div>

          {/* Resources & Database */}
          <div>
            <h4 className="font-heading font-bold text-sm text-white uppercase tracking-wider mb-4">
              Architecture & Help
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button onClick={() => onNavigate('database-studio')} className="hover:text-white transition-colors cursor-pointer flex items-center gap-1.5 text-amber-300">
                  <Database className="w-3.5 h-3.5" /> MySQL 8.0 Studio
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-white transition-colors cursor-pointer">
                  About Rauf Blood System
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('faq')} className="hover:text-white transition-colors cursor-pointer">
                  Transfusion FAQs
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('contact')} className="hover:text-white transition-colors cursor-pointer">
                  Contact Centers
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© 2026 Rauf Blood Management System. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <Database className="w-3 h-3 text-slate-400" /> MySQL 8.0 + InnoDB Transactional Architecture
            </span>
            <span>•</span>
            <span className="text-slate-400">Strict Medical Data Privacy Standard</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
