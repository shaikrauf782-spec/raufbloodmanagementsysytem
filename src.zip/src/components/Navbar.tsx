import React, { useState } from 'react';
import {
  Droplet,
  Heart,
  Shield,
  Building2,
  Users,
  Search,
  PlusCircle,
  Menu,
  X,
  ChevronDown,
  LogIn,
  LogOut,
  Database,
  BarChart3,
  Calendar,
  AlertTriangle,
  Info,
  PhoneCall,
  HelpCircle,
} from 'lucide-react';
import { User } from '../types.js';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  currentUser: User | null;
  onLogout: () => void;
  onOpenQuickRequest: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  onNavigate,
  currentUser,
  onLogout,
  onOpenQuickRequest,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [loginDropdownOpen, setLoginDropdownOpen] = useState(false);
  const [moreDropdownOpen, setMoreDropdownOpen] = useState(false);

  const navItem = (page: string, label: string, icon?: React.ReactNode) => {
    const isActive = currentPage === page;
    return (
      <button
        onClick={() => {
          onNavigate(page);
          setMobileMenuOpen(false);
        }}
        className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
          isActive
            ? 'bg-red-50 text-red-700 font-bold border border-red-200'
            : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
        }`}
      >
        {icon}
        {label}
      </button>
    );
  };

  return (
    <nav className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Tagline */}
          <div className="flex items-center gap-8">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2.5 group cursor-pointer text-left"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center text-white shadow-md shadow-red-500/25 group-hover:scale-105 transition-transform">
                <Droplet className="w-5 h-5 fill-white" />
              </div>
              <div>
                <span className="font-heading font-extrabold text-xl tracking-tight text-[#14243A] block leading-none">
                  RAUF <span className="text-red-600">BLOOD</span>
                </span>
                <span className="text-[10px] uppercase font-semibold tracking-wider text-slate-400 block mt-0.5">
                  Management System
                </span>
              </div>
            </button>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-1">
              {navItem('home', 'Home')}
              {navItem('find-blood', 'Find Blood', <Search className="w-3.5 h-3.5" />)}
              {navItem('inventory', 'Blood Inventory', <Droplet className="w-3.5 h-3.5" />)}
              {navItem('requests', 'Blood Requests', <AlertTriangle className="w-3.5 h-3.5" />)}
              {navItem('donors', 'Donors', <Users className="w-3.5 h-3.5" />)}
              {navItem('donations', 'Donations', <Calendar className="w-3.5 h-3.5" />)}

              {/* Role-Specific Dashboards */}
              {currentUser?.role === 'admin' && navItem('admin-dashboard', 'Admin Portal', <Shield className="w-3.5 h-3.5 text-red-600" />)}
              {currentUser?.role === 'donor' && navItem('donor-dashboard', 'My Donor Hub', <Heart className="w-3.5 h-3.5 text-red-600" />)}
              {currentUser?.role === 'hospital' && navItem('hospital-dashboard', 'Hospital Portal', <Building2 className="w-3.5 h-3.5 text-blue-600" />)}

              {/* More dropdown */}
              <div className="relative">
                <button
                  onClick={() => setMoreDropdownOpen(!moreDropdownOpen)}
                  className="px-3 py-2 text-xs font-semibold rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 flex items-center gap-1 cursor-pointer"
                >
                  More
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>
                {moreDropdownOpen && (
                  <div
                    onMouseLeave={() => setMoreDropdownOpen(false)}
                    className="absolute left-0 mt-1 w-48 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-150"
                  >
                    <button
                      onClick={() => { onNavigate('about'); setMoreDropdownOpen(false); }}
                      className="w-full text-left px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Info className="w-3.5 h-3.5 text-slate-400" /> About Us
                    </button>
                    <button
                      onClick={() => { onNavigate('faq'); setMoreDropdownOpen(false); }}
                      className="w-full text-left px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <HelpCircle className="w-3.5 h-3.5 text-slate-400" /> Transfusion FAQ
                    </button>
                    <button
                      onClick={() => { onNavigate('contact'); setMoreDropdownOpen(false); }}
                      className="w-full text-left px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <PhoneCall className="w-3.5 h-3.5 text-slate-400" /> Contact & Centers
                    </button>
                    <div className="border-t border-slate-100 my-1"></div>
                    <button
                      onClick={() => { onNavigate('database-studio'); setMoreDropdownOpen(false); }}
                      className="w-full text-left px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 flex items-center gap-2 text-red-600 font-semibold"
                    >
                      <Database className="w-3.5 h-3.5" /> MySQL 8.0 Studio
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Action Buttons */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Quick Emergency Request Button */}
            <button
              onClick={onOpenQuickRequest}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-red-50 text-red-700 border border-red-200 hover:bg-red-100 flex items-center gap-1.5 cursor-pointer shadow-xs transition-all"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
              Emergency Request
            </button>

            {/* User Session or Login options */}
            {currentUser ? (
              <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
                <div className="text-right">
                  <span className="text-xs font-bold text-slate-900 block leading-tight truncate max-w-[130px]">
                    {currentUser.name}
                  </span>
                  <span className="text-[10px] font-semibold uppercase px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 inline-block">
                    {currentUser.role}
                  </span>
                </div>
                <button
                  onClick={onLogout}
                  title="Logout"
                  className="p-2 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="relative">
                <button
                  onClick={() => setLoginDropdownOpen(!loginDropdownOpen)}
                  className="px-3.5 py-2 text-xs font-bold rounded-lg bg-[#14243A] text-white hover:bg-slate-800 shadow-sm flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  Sign In / Register
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {loginDropdownOpen && (
                  <div
                    onMouseLeave={() => setLoginDropdownOpen(false)}
                    className="absolute right-0 mt-1 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50"
                  >
                    <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Sign In Portals
                    </div>
                    <button
                      onClick={() => { onNavigate('login-donor'); setLoginDropdownOpen(false); }}
                      className="w-full text-left px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Heart className="w-3.5 h-3.5 text-red-600" /> Donor Login
                    </button>
                    <button
                      onClick={() => { onNavigate('login-hospital'); setLoginDropdownOpen(false); }}
                      className="w-full text-left px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Building2 className="w-3.5 h-3.5 text-blue-600" /> Hospital Login
                    </button>
                    <button
                      onClick={() => { onNavigate('login-admin'); setLoginDropdownOpen(false); }}
                      className="w-full text-left px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 font-semibold text-red-700"
                    >
                      <Shield className="w-3.5 h-3.5" /> Admin Secure Portal
                    </button>

                    <div className="border-t border-slate-100 my-1.5"></div>
                    <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      New Registration
                    </div>
                    <button
                      onClick={() => { onNavigate('register-donor'); setLoginDropdownOpen(false); }}
                      className="w-full text-left px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <PlusCircle className="w-3.5 h-3.5 text-emerald-600" /> Register as Donor
                    </button>
                    <button
                      onClick={() => { onNavigate('register-hospital'); setLoginDropdownOpen(false); }}
                      className="w-full text-left px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Building2 className="w-3.5 h-3.5 text-indigo-600" /> Register Hospital
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Mobile hamburger */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={onOpenQuickRequest}
              className="p-2 text-xs font-semibold rounded-lg bg-red-50 text-red-700 border border-red-200"
            >
              <AlertTriangle className="w-4 h-4" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-2 max-h-[85vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-2 mb-3">
            <button
              onClick={() => { onNavigate('find-blood'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-lg bg-red-50 text-red-700 text-xs font-bold flex items-center gap-2"
            >
              <Search className="w-4 h-4" /> Find Blood
            </button>
            <button
              onClick={() => { onOpenQuickRequest(); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-lg bg-red-600 text-white text-xs font-bold flex items-center gap-2"
            >
              <AlertTriangle className="w-4 h-4" /> Request Blood
            </button>
          </div>

          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-2 pt-2">
            Core Modules
          </div>
          {navItem('home', 'Home')}
          {navItem('inventory', 'Blood Inventory & Stock')}
          {navItem('requests', 'Blood Requests')}
          {navItem('donors', 'Donor Management')}
          {navItem('donations', 'Donation Records')}

          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-2 pt-3">
            Portals & Dashboards
          </div>
          {navItem('admin-dashboard', 'Admin Dashboard')}
          {navItem('donor-dashboard', 'Donor Dashboard')}
          {navItem('hospital-dashboard', 'Hospital Dashboard')}

          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-2 pt-3">
            Account & Registration
          </div>
          {navItem('login-donor', 'Donor Login')}
          {navItem('login-hospital', 'Hospital Login')}
          {navItem('login-admin', 'Admin Login')}
          {navItem('register-donor', 'Donor Registration')}
          {navItem('register-hospital', 'Hospital Registration')}

          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-2 pt-3">
            Information & MySQL
          </div>
          {navItem('about', 'About Rauf Blood System')}
          {navItem('faq', 'Transfusion FAQ')}
          {navItem('contact', 'Contact Us & Centers')}
          {navItem('database-studio', 'MySQL 8.0 Studio & Schema')}

          {currentUser && (
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs text-slate-600 font-medium">Logged in as {currentUser.name}</span>
              <button
                onClick={() => { onLogout(); setMobileMenuOpen(false); }}
                className="text-xs font-bold text-red-600"
              >
                Sign Out
              </button>
            </div>
          )}
        </div>
      )}
    </nav>
  );
};
