import {
  BloodGroup,
  BloodRequest,
  BloodStockItem,
  BloodUnit,
  DashboardStats,
  DbStatusInfo,
  Donation,
  Donor,
  Hospital,
  User,
} from '../types.js';

const API_BASE = '/api';

async function fetchJson<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${url}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error || data.message || `Request failed with status ${response.status}`);
  }
  return data;
}

export const api = {
  // Database status and reconnect
  getDbStatus: async () => {
    return fetchJson<{
      status: string;
      database: DbStatusInfo;
      tableCounts: Record<string, number>;
      timestamp: string;
    }>('/database/status');
  },

  reconnectDb: async () => {
    return fetchJson<{
      success: boolean;
      status: DbStatusInfo;
    }>('/database/reconnect', { method: 'POST' });
  },

  // Auth
  login: async (credentials: { email: string; password: string; role?: string }) => {
    return fetchJson<{
      success: boolean;
      user: User;
      profile?: Donor | Hospital | null;
      token: string;
    }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  },

  registerDonor: async (data: Partial<Donor> & { password: string }) => {
    return fetchJson<{
      success: boolean;
      message: string;
      user: User;
      donor: Donor;
    }>('/auth/register-donor', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  registerHospital: async (data: Partial<Hospital> & { password: string }) => {
    return fetchJson<{
      success: boolean;
      message: string;
      user: User;
      hospital: Hospital;
    }>('/auth/register-hospital', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Donors
  getDonors: async (params?: { blood_group?: string; city?: string; search?: string; eligibility?: string }) => {
    const query = new URLSearchParams();
    if (params?.blood_group) query.append('blood_group', params.blood_group);
    if (params?.city) query.append('city', params.city);
    if (params?.search) query.append('search', params.search);
    if (params?.eligibility) query.append('eligibility', params.eligibility);
    const qs = query.toString() ? `?${query.toString()}` : '';
    return fetchJson<{ success: boolean; count: number; data: Donor[] }>(`/donors${qs}`);
  },

  getDonorById: async (id: number) => {
    return fetchJson<{ success: boolean; donor: Donor; donations: Donation[] }>(`/donors/${id}`);
  },

  updateDonor: async (id: number, data: Partial<Donor>) => {
    return fetchJson<{ success: boolean; message: string; donor: Donor }>(`/donors/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  deleteDonor: async (id: number) => {
    return fetchJson<{ success: boolean; message: string; donor: Donor }>(`/donors/${id}`, {
      method: 'DELETE',
    });
  },

  // Inventory
  getInventory: async () => {
    return fetchJson<{
      success: boolean;
      totalAvailableUnits: number;
      lowStockCount: number;
      inventory: BloodStockItem[];
      allStockRows: any[];
    }>('/inventory');
  },

  getUnits: async (params?: { blood_group?: string; status?: string }) => {
    const query = new URLSearchParams();
    if (params?.blood_group) query.append('blood_group', params.blood_group);
    if (params?.status) query.append('status', params.status);
    const qs = query.toString() ? `?${query.toString()}` : '';
    return fetchJson<{ success: boolean; count: number; data: BloodUnit[] }>(`/inventory/units${qs}`);
  },

  addUnit: async (unit: Partial<BloodUnit>) => {
    return fetchJson<{ success: boolean; message: string; unit: BloodUnit }>('/inventory/units', {
      method: 'POST',
      body: JSON.stringify(unit),
    });
  },

  updateUnit: async (id: number, updates: Partial<BloodUnit>) => {
    return fetchJson<{ success: boolean; message: string; unit: BloodUnit }>(`/inventory/units/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  // Blood Requests
  getRequests: async (params?: { status?: string; blood_group?: string; priority?: string; search?: string }) => {
    const query = new URLSearchParams();
    if (params?.status) query.append('status', params.status);
    if (params?.blood_group) query.append('blood_group', params.blood_group);
    if (params?.priority) query.append('priority', params.priority);
    if (params?.search) query.append('search', params.search);
    const qs = query.toString() ? `?${query.toString()}` : '';
    return fetchJson<{ success: boolean; count: number; data: BloodRequest[] }>(`/requests${qs}`);
  },

  createRequest: async (data: Partial<BloodRequest>) => {
    return fetchJson<{ success: boolean; message: string; request: BloodRequest }>('/requests', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  approveRequest: async (id: number) => {
    return fetchJson<{ success: boolean; message: string; request: BloodRequest }>(`/requests/${id}/approve`, {
      method: 'PUT',
    });
  },

  fulfillRequest: async (id: number) => {
    return fetchJson<{ success: boolean; message: string; request: BloodRequest; stockBalance: number }>(`/requests/${id}/fulfill`, {
      method: 'PUT',
    });
  },

  rejectRequest: async (id: number, reason: string) => {
    return fetchJson<{ success: boolean; message: string; request: BloodRequest }>(`/requests/${id}/reject`, {
      method: 'PUT',
      body: JSON.stringify({ rejection_reason: reason }),
    });
  },

  // Donations
  getDonations: async () => {
    return fetchJson<{ success: boolean; count: number; data: Donation[] }>('/donations');
  },

  recordDonation: async (data: Partial<Donation> & { donor_id: number; blood_group: string }) => {
    return fetchJson<{ success: boolean; message: string; donation: Donation; donor: Donor }>('/donations', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Hospitals
  getHospitals: async () => {
    return fetchJson<{ success: boolean; count: number; data: Hospital[] }>('/hospitals');
  },

  verifyHospital: async (id: number, status: 'Verified' | 'Rejected', reason?: string) => {
    return fetchJson<{ success: boolean; message: string; hospital: Hospital }>(`/hospitals/${id}/verify`, {
      method: 'PUT',
      body: JSON.stringify({ status, rejection_reason: reason }),
    });
  },

  // Dashboard Stats
  getDashboardStats: async () => {
    return fetchJson<{ success: boolean; stats: DashboardStats }>('/dashboard/stats');
  },
};
