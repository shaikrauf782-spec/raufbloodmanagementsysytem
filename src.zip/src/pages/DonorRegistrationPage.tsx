import React, { useState } from 'react';
import { Heart, UserPlus, CheckCircle2, AlertCircle, Shield, Droplet } from 'lucide-react';
import confetti from 'canvas-confetti';
import { BloodGroup } from '../types.js';
import { api } from '../api/client.js';

interface DonorRegistrationPageProps {
  onNavigate: (page: string) => void;
  onRegistered: () => void;
}

export const DonorRegistrationPage: React.FC<DonorRegistrationPageProps> = ({
  onNavigate,
  onRegistered,
}) => {
  const [formData, setFormData] = useState({
    full_name: '',
    dob: '1995-06-15',
    gender: 'Male' as 'Male' | 'Female' | 'Other',
    blood_group: 'O+' as BloodGroup,
    phone: '',
    email: '',
    password: '',
    confirm_password: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    weight_kg: 68,
    last_donation_date: '',
    emergency_contact_name: '',
    emergency_contact_phone: '',
    medical_notes: '',
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successDonorCode, setSuccessDonorCode] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (formData.password !== formData.confirm_password) {
      setError('Passwords do not match. Please re-enter.');
      return;
    }

    if (formData.weight_kg < 45) {
      setError('Donor safety notice: Minimum weight for whole blood donation is 45 kg (99 lbs).');
      return;
    }

    setLoading(true);

    try {
      const res = await api.registerDonor(formData);
      setSuccessDonorCode(res.donor.donor_code);

      // Trigger celebratory confetti
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });

      setTimeout(() => {
        onRegistered();
      }, 3500);
    } catch (err: any) {
      setError(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
        {/* Header Banner */}
        <div className="p-8 bg-gradient-to-r from-red-600 to-red-800 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-white text-xs font-bold uppercase tracking-wider">
              <Heart className="w-3.5 h-3.5 fill-white" /> Voluntary Donor Portal
            </span>
            <h1 className="font-heading font-extrabold text-2xl sm:text-3xl text-white">
              Register as a Lifesaver
            </h1>
            <p className="text-xs sm:text-sm text-red-100 leading-relaxed">
              Join thousands of heroes in our donor registry. Your blood group details will be stored securely with bcrypt encryption in MySQL.
            </p>
          </div>
          <div className="text-right">
            <span className="text-xs text-red-200 block">Already have a donor account?</span>
            <button
              onClick={() => onNavigate('login-donor')}
              className="mt-1 px-4 py-2 bg-white text-red-700 text-xs font-bold rounded-xl hover:bg-red-50 transition-colors"
            >
              Donor Sign In
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          {error && (
            <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successDonorCode && (
            <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-2 animate-in fade-in">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                <h3 className="font-heading font-bold text-base">Registration Complete!</h3>
              </div>
              <p className="text-xs text-slate-700">
                Your voluntary donor code is <strong className="font-mono text-red-700 text-sm">{successDonorCode}</strong>.
                Your profile has been committed to the MySQL database. Redirecting to your personal donor hub...
              </p>
            </div>
          )}

          {/* Section 1: Personal & Medical Information */}
          <div className="space-y-4">
            <div className="border-b border-slate-100 pb-2 flex items-center gap-2 text-slate-900 font-heading font-bold text-sm">
              <Droplet className="w-4 h-4 text-red-600" />
              1. Personal & Blood Group Information
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Robert Chen"
                  value={formData.full_name}
                  onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Date of Birth *</label>
                <input
                  type="date"
                  required
                  value={formData.dob}
                  onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Gender *</label>
                <select
                  value={formData.gender}
                  onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500 font-medium"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Blood Group *</label>
                <select
                  value={formData.blood_group}
                  onChange={(e) => setFormData({ ...formData, blood_group: e.target.value as BloodGroup })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500 font-bold text-red-600 bg-red-50/50"
                >
                  {(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as BloodGroup[]).map((bg) => (
                    <option key={bg} value={bg}>{bg}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Weight in kg (min 45 kg) *</label>
                <input
                  type="number"
                  min="40"
                  max="160"
                  required
                  value={formData.weight_kg}
                  onChange={(e) => setFormData({ ...formData, weight_kg: Number(e.target.value) })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500 font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Last Blood Donation Date</label>
                <input
                  type="date"
                  value={formData.last_donation_date}
                  onChange={(e) => setFormData({ ...formData, last_donation_date: e.target.value })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Contact & Location */}
          <div className="space-y-4">
            <div className="border-b border-slate-100 pb-2 flex items-center gap-2 text-slate-900 font-heading font-bold text-sm">
              <Shield className="w-4 h-4 text-red-600" />
              2. Contact & Residential Address
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Mobile Phone Number *</label>
                <input
                  type="tel"
                  required
                  placeholder="+1 (555) 000-0000"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address *</label>
                <input
                  type="email"
                  required
                  placeholder="robert.chen@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-1">
                <label className="block text-xs font-semibold text-slate-700 mb-1">City *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Metro City"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">State / Province *</label>
                <input
                  type="text"
                  required
                  placeholder="State"
                  value={formData.state}
                  onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">PIN / Postal Code *</label>
                <input
                  type="text"
                  required
                  placeholder="10001"
                  value={formData.pincode}
                  onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Street Address</label>
              <input
                type="text"
                placeholder="Apartment, suite, unit, street"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          {/* Section 3: Account Security */}
          <div className="space-y-4">
            <div className="border-b border-slate-100 pb-2 flex items-center gap-2 text-slate-900 font-heading font-bold text-sm">
              <Shield className="w-4 h-4 text-red-600" />
              3. Account Security (Stored using bcrypt)
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Password *</label>
                <input
                  type="password"
                  required
                  placeholder="Minimum 6 characters"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Confirm Password *</label>
                <input
                  type="password"
                  required
                  placeholder="Re-type password"
                  value={formData.confirm_password}
                  onChange={(e) => setFormData({ ...formData, confirm_password: e.target.value })}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>
          </div>

          {/* Submit */}
          <div className="pt-4 flex items-center justify-between border-t border-slate-100">
            <span className="text-xs text-slate-400">
              By registering, you consent to emergency SMS callouts when matching your blood group.
            </span>

            <button
              type="submit"
              disabled={loading}
              className="px-8 py-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-lg shadow-red-600/30 flex items-center gap-2 disabled:opacity-50 transition-all cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              {loading ? 'Submitting to Database...' : 'Complete Donor Registration'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
