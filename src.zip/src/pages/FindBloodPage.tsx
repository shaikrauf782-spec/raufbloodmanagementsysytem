import React, { useState, useEffect } from 'react';
import { Search, Droplet, MapPin, Building2, AlertTriangle, ShieldCheck, CheckCircle2, Filter, Users, Phone, Calendar } from 'lucide-react';
import { BloodGroup, BloodStockItem, BloodUnit, Donor } from '../types.js';
import { api } from '../api/client.js';

interface FindBloodPageProps {
  onNavigate: (page: string) => void;
  onRequestBlood: (group: BloodGroup) => void;
}

export const FindBloodPage: React.FC<FindBloodPageProps> = ({ onNavigate, onRequestBlood }) => {
  const [selectedGroup, setSelectedGroup] = useState<string>('All');
  const [searchCity, setSearchCity] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'units' | 'donors'>('donors');
  const [units, setUnits] = useState<BloodUnit[]>([]);
  const [donors, setDonors] = useState<Donor[]>([]);
  const [inventory, setInventory] = useState<BloodStockItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [selectedGroup, searchCity, activeTab]);

  const loadData = async () => {
    setLoading(true);
    try {
      const invRes = await api.getInventory();
      setInventory(invRes.inventory);

      if (activeTab === 'units') {
        const unitRes = await api.getUnits({
          blood_group: selectedGroup !== 'All' ? selectedGroup : undefined,
          status: 'Available',
        });
        setUnits(unitRes.data);
      } else {
        const donorRes = await api.getDonors({
          blood_group: selectedGroup !== 'All' ? selectedGroup : undefined,
          city: searchCity.trim() || undefined,
        });
        setDonors(donorRes.data);
      }
    } catch (err) {
      console.error('Failed to load blood data:', err);
    } finally {
      setLoading(false);
    }
  };

  const bloodGroups: Array<'All' | BloodGroup> = ['All', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Page Header */}
      <div className="bg-gradient-to-r from-[#14243A] to-slate-800 rounded-3xl p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600/30 text-red-300 text-xs font-bold border border-red-500/30">
            <Search className="w-3.5 h-3.5 text-red-400" />
            Live Search & Requisition
          </span>
          <h1 className="font-heading font-extrabold text-3xl sm:text-4xl text-white">
            Find Blood Availability & Donors
          </h1>
          <p className="text-xs sm:text-sm text-slate-300">
            Search certified voluntary donors and available units in MySQL real-time database.
          </p>
        </div>

        <button
          onClick={() => onRequestBlood(selectedGroup !== 'All' ? (selectedGroup as BloodGroup) : 'O+')}
          className="px-5 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-lg shadow-red-600/30 flex items-center gap-2 shrink-0 transition-all cursor-pointer"
        >
          <AlertTriangle className="w-4 h-4" />
          Raise Blood Requisition
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('donors')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'donors'
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/25'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5" /> Search Voluntary Donors
            </button>
            <button
              onClick={() => setActiveTab('units')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'units'
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/25'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Droplet className="w-3.5 h-3.5" /> Blood Bank Cold Storage
            </button>
          </div>

          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              placeholder="Filter by city (e.g. Metro City)..."
              value={searchCity}
              onChange={(e) => setSearchCity(e.target.value)}
              className="text-xs px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:border-red-500 w-60"
            />
          </div>
        </div>

        <div className="pt-2 border-t border-slate-100">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
            Filter by Blood Group:
          </span>
          <div className="flex flex-wrap gap-2">
            {bloodGroups.map((bg) => (
              <button
                key={bg}
                onClick={() => setSelectedGroup(bg)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  selectedGroup === bg
                    ? 'bg-red-600 text-white shadow-md shadow-red-600/25 scale-105'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {bg}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Aggregated Stock Overview Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {inventory.map((item) => (
          <div
            key={item.blood_group}
            onClick={() => setSelectedGroup(item.blood_group)}
            className={`p-3.5 rounded-2xl border text-center cursor-pointer transition-all ${
              selectedGroup === item.blood_group
                ? 'ring-2 ring-red-500 bg-red-50/50 border-red-200'
                : 'bg-white border-slate-200 hover:border-slate-300'
            }`}
          >
            <span className="text-xs font-extrabold text-red-600 block">{item.blood_group}</span>
            <span className="text-xl font-extrabold font-heading text-slate-900 block my-1">
              {item.available_units}
            </span>
            <span
              className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                item.status === 'Critical'
                  ? 'bg-red-100 text-red-800'
                  : item.status === 'Low'
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              {item.status}
            </span>
          </div>
        ))}
      </div>

      {/* Main Results Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-heading font-bold text-lg text-slate-900">
              {activeTab === 'donors' ? 'Matching Voluntary Donors' : 'Certified Tested Blood Bags in Cold Storage'}
            </h3>
            <p className="text-xs text-slate-500">
              {activeTab === 'donors'
                ? `Showing voluntary donors registered in MySQL for group ${selectedGroup}`
                : 'Stored at 2°C – 6°C with continuous temperature logging'}
            </p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" /> MySQL Active
          </span>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">Loading data from MySQL...</div>
        ) : activeTab === 'donors' ? (
          donors.length === 0 ? (
            <div className="p-12 text-center space-y-3">
              <Users className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-sm font-semibold text-slate-700">
                No matching donors found for &quot;{selectedGroup}&quot; {searchCity ? `in ${searchCity}` : ''}.
              </p>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                No voluntary donors currently match this criteria in MySQL database. You can register as a new donor!
              </p>
              <button
                onClick={() => onNavigate('register-donor')}
                className="px-4 py-2 bg-red-600 text-white rounded-xl text-xs font-bold"
              >
                Register as a Donor
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-100">
                  <tr>
                    <th className="py-3 px-6">Donor Code</th>
                    <th className="py-3 px-6">Name</th>
                    <th className="py-3 px-6">Blood Group</th>
                    <th className="py-3 px-6">Age / Gender</th>
                    <th className="py-3 px-6">City</th>
                    <th className="py-3 px-6">Contact Phone</th>
                    <th className="py-3 px-6">Last Donation</th>
                    <th className="py-3 px-6 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {donors.map((donor) => (
                    <tr key={donor.id || donor.donor_code} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-4 px-6 font-mono font-bold text-slate-800">
                        {donor.donor_code || `DON-${donor.id}`}
                      </td>
                      <td className="py-4 px-6 font-semibold text-slate-900">
                        {donor.full_name || (donor as any).name}
                      </td>
                      <td className="py-4 px-6">
                        <span className="font-heading font-extrabold text-sm text-red-600 bg-red-50 px-2 py-0.5 rounded-md border border-red-100">
                          {donor.blood_group}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-slate-600">
                        {donor.gender || 'Male'}
                      </td>
                      <td className="py-4 px-6 text-slate-600">
                        <span className="inline-flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" /> {donor.city || 'City'}
                        </span>
                      </td>
                      <td className="py-4 px-6 font-mono text-slate-700">
                        {donor.phone}
                      </td>
                      <td className="py-4 px-6 text-slate-500">
                        {donor.last_donation_date || 'First time donor'}
                      </td>
                      <td className="py-4 px-6 text-right">
                        <button
                          onClick={() => onRequestBlood(donor.blood_group)}
                          className="px-3 py-1.5 text-xs font-bold rounded-lg bg-red-600 hover:bg-red-700 text-white shadow-xs cursor-pointer"
                        >
                          Request Blood
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        ) : (
          units.length === 0 ? (
            <div className="p-12 text-center space-y-3">
              <Droplet className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-sm font-semibold text-slate-700">
                No available units currently match &quot;{selectedGroup}&quot;.
              </p>
              <button
                onClick={() => onRequestBlood(selectedGroup !== 'All' ? (selectedGroup as BloodGroup) : 'O+')}
                className="px-4 py-2 bg-red-600 text-white rounded-xl text-xs font-bold"
              >
                Raise Blood Requisition
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-100">
                  <tr>
                    <th className="py-3 px-6">Bag Unit ID</th>
                    <th className="py-3 px-6">Blood Group</th>
                    <th className="py-3 px-6">Component</th>
                    <th className="py-3 px-6">Volume</th>
                    <th className="py-3 px-6">Collection Date</th>
                    <th className="py-3 px-6">Expiry Date</th>
                    <th className="py-3 px-6">Storage Vault</th>
                    <th className="py-3 px-6 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {units.map((unit) => (
                    <tr key={unit.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-4 px-6 font-mono font-bold text-slate-800">
                        {unit.unit_id}
                      </td>
                      <td className="py-4 px-6">
                        <span className="font-heading font-extrabold text-sm text-red-600 bg-red-50 px-2 py-0.5 rounded-md border border-red-100">
                          {unit.blood_group}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-slate-700">{unit.component_type}</td>
                      <td className="py-4 px-6 text-slate-600">{unit.volume_ml} mL</td>
                      <td className="py-4 px-6 text-slate-600">{unit.collection_date}</td>
                      <td className="py-4 px-6 text-slate-600 font-medium">{unit.expiry_date}</td>
                      <td className="py-4 px-6 text-slate-500 font-mono text-[11px]">
                        {unit.storage_location}
                      </td>
                      <td className="py-4 px-6 text-right">
                        <button
                          onClick={() => onRequestBlood(unit.blood_group)}
                          className="px-3 py-1.5 text-xs font-bold rounded-lg bg-red-600 hover:bg-red-700 text-white shadow-xs cursor-pointer"
                        >
                          Request Unit
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        )}
      </div>
    </div>
  );
};
