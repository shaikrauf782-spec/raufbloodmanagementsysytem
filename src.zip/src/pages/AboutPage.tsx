import React from 'react';
import { ShieldCheck, Heart, Droplet, Users, Award, Building2, CheckCircle2 } from 'lucide-react';

interface AboutPageProps {
  onNavigate: (page: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Hero */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold uppercase tracking-widest text-red-600 bg-red-50 px-3 py-1 rounded-full border border-red-200">
          Certified Transfusion Network
        </span>
        <h1 className="font-heading font-extrabold text-4xl sm:text-5xl text-[#14243A] tracking-tight">
          About Rauf Blood Management System
        </h1>
        <p className="text-base text-slate-600 leading-relaxed">
          Founded on the principle that no patient should suffer due to lack of compatible blood, Rauf Blood Management System bridges voluntary donors with emergency operating theaters through real-time technology and strict medical standards.
        </p>
      </div>

      {/* 3 Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center font-bold">
            <Droplet className="w-6 h-6 fill-red-600" />
          </div>
          <h3 className="font-heading font-bold text-lg text-slate-900">Zero Transfusion Delay</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Eliminating bureaucratic friction by digitizing donor records, rapid cross-matching compatibility, and tracking units in real-time.
          </p>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="font-heading font-bold text-lg text-slate-900">Gold Standard Safety</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Every blood bag undergoes rigorous ELISA and Nucleic Acid Testing (NAT) for HIV 1/2, Hepatitis B & C, Syphilis, and Malaria before release.
          </p>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center font-bold">
            <Heart className="w-6 h-6 fill-blue-600" />
          </div>
          <h3 className="font-heading font-bold text-lg text-slate-900">Voluntary Donor Respect</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Protecting donor health with strict 56-day intervals, certified phlebotomists, and recognition for regular voluntary donors.
          </p>
        </div>
      </div>

      {/* Quality Standards Checklist */}
      <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-md">
        <h2 className="font-heading font-extrabold text-2xl text-[#14243A] mb-6">
          Our Operational Quality & Safety Standards
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-700">
          <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-900 block font-semibold">Continuous Cold Chain Monitoring</strong>
              Bags maintained at 2°C – 6°C with computerized temperature alerting and backup power generator redundancy.
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-900 block font-semibold">Barcoded Bag Traceability</strong>
              Unique 128-barcode IDs track collection date, donor reference, serology testing batch, and hospital dispatch.
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-900 block font-semibold">Strict Component Separation</strong>
              A single whole blood unit can be fractionated into Packed RBCs, Fresh Frozen Plasma, and Platelet concentrates.
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-900 block font-semibold">Hospital Compliance Verification</strong>
              Only accredited hospitals with certified transfusion medicine officers receive automated inventory dispatch authorization.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
