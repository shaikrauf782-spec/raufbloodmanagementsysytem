import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  PlusCircle,
  X,
  Building2,
  Phone,
  Droplet,
  User,
  ShieldAlert,
} from 'lucide-react';
import { BloodGroup, BloodRequest } from '../types.js';
import { api } from '../api/client.js';

interface BloodRequestsPageProps {
  onNavigate: (page: string) => void;
  onOpenQuickRequest: () => void;
}

export const BloodRequestsPage: React.FC<BloodRequestsPageProps> = ({ onNavigate, onOpenQuickRequest }) => {
  const [requests, setRequests] = useState<BloodRequest[]>([]);
  const [statusFilter, setStatusFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [bloodGroupFilter, setBloodGroupFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Reject Reason Modal
  const [rejectingId, setRejectingId] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  useEffect(() => {
    loadRequests();
  }, [statusFilter, priorityFilter, bloodGroupFilter]);

  const loadRequests = async () => {
    setLoading(true);
    try {
      const res = await api.getRequests({
        status: statusFilter !== 'All' ? statusFilter : undefined,
        priority: priorityFilter !== 'All' ? priorityFilter : undefined,
        blood_group: bloodGroupFilter !== 'All' ? bloodGroupFilter : undefined,
        search: search || undefined,
      });
      setRequests(res.data);
    } catch (err) {
      console.error('Failed to load blood requests:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadRequests();
  };

  const handleApprove = async (id: number) => {
    try {
      await api.approveRequest(id);
      setFeedback('Requisition status updated to Approved in MySQL.');
      loadRequests();
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleFulfill = async (id: number) => {
    try {
      const res = await api.fulfillRequest(id);
      setFeedback(res.message);
      loadRequests();
      setTimeout(() => setFeedback(null), 4000);
    } catch (err: any) {
      alert(err.message || 'Stock deduction failed');
    }
  };

  const handleConfirmReject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectingId) return;
    try {
      await api.rejectRequest(rejectingId, rejectReason);
      setFeedback('Blood requisition marked as Rejected.');
      setRejectingId(null);
      setRejectReason('');
      loadRequests();
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const bloodGroups: Array<'All' | BloodGroup> = ['All', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-red-600">
            Emergency & Scheduled Requisitions
          </span>
          <h1 className="font-heading font-extrabold text-3xl text-[#14243A]">
            Blood Request Management
          </h1>
          <p className="text-xs text-slate-500">
            Review hospital requisitions, approve triage, and execute atomic stock deduction transactions.
          </p>
        </div>

        <button
          onClick={onOpenQuickRequest}
          className="px-5 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md shadow-red-600/25 flex items-center gap-2 cursor-pointer transition-all"
        >
          <PlusCircle className="w-4 h-4" /> Raise Blood Requisition
        </button>
      </div>

      {feedback && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-medium flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Filter Toolbar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <form onSubmit={handleSearchSubmit} className="flex flex-col md:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              placeholder="Search by requisition code, hospital name, patient name, or ref ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full text-xs pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
            />
          </div>
          <button
            type="submit"
            className="w-full md:w-auto px-5 py-2.5 rounded-xl bg-[#14243A] text-white font-bold text-xs hover:bg-slate-800 transition-colors"
          >
            Search MySQL Requests
          </button>
        </form>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-100 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-bold uppercase text-slate-400 mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Group:
            </span>
            {bloodGroups.map((bg) => (
              <button
                key={bg}
                onClick={() => setBloodGroupFilter(bg)}
                className={`px-3 py-1 text-[11px] font-bold rounded-lg transition-colors cursor-pointer ${
                  bloodGroupFilter === bg
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {bg}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-bold uppercase text-slate-400">Status:</span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="p-1.5 rounded-lg border border-slate-300 font-semibold focus:outline-none focus:border-red-500"
              >
                <option value="All">All Statuses</option>
                <option value="Pending">Pending</option>
                <option value="Approved">Approved</option>
                <option value="Fulfilled">Fulfilled</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-bold uppercase text-slate-400">Priority:</span>
              <select
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value)}
                className="p-1.5 rounded-lg border border-slate-300 font-semibold focus:outline-none focus:border-red-500"
              >
                <option value="All">All Priorities</option>
                <option value="Emergency - Critical">Emergency - Critical</option>
                <option value="Urgent">Urgent</option>
                <option value="Standard">Standard</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Requests Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-heading font-bold text-base text-slate-900">
              Requisition Ledger (blood_bank.blood_requests)
            </h3>
            <p className="text-xs text-slate-500">
              Transactions enforce inventory integrity: available units decrement and physical bags are marked Issued upon fulfillment.
            </p>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {requests.length} Requests Found
          </span>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">Querying requisitions from database...</div>
        ) : requests.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-500">
            No blood requests found matching criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-100">
                <tr>
                  <th className="py-3 px-6">Request Code</th>
                  <th className="py-3 px-6">Hospital & Patient</th>
                  <th className="py-3 px-6">Blood Group</th>
                  <th className="py-3 px-6">Units Req/Fulfilled</th>
                  <th className="py-3 px-6">Required Date</th>
                  <th className="py-3 px-6">Priority</th>
                  <th className="py-3 px-6">Status</th>
                  <th className="py-3 px-6">Emergency Phone</th>
                  <th className="py-3 px-6 text-right">Triage Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {requests.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/70">
                    <td className="py-4 px-6 font-mono font-bold text-slate-800">
                      {r.request_code}
                    </td>
                    <td className="py-4 px-6">
                      <span className="font-bold text-slate-900 block">{r.hospital_name}</span>
                      <span className="text-[11px] text-slate-500 block">
                        Patient: {r.patient_name} ({r.patient_ref_id})
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="font-heading font-extrabold text-sm text-red-600 bg-red-50 px-2 py-0.5 rounded border border-red-100">
                        {r.blood_group}
                      </span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">{r.component_type}</span>
                    </td>
                    <td className="py-4 px-6 font-semibold text-slate-800">
                      {r.units_fulfilled} / {r.units_required} Units
                    </td>
                    <td className="py-4 px-6 text-slate-600 font-medium">
                      {r.required_date}
                    </td>
                    <td className="py-4 px-6">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          r.priority === 'Emergency - Critical'
                            ? 'bg-red-100 text-red-800 animate-pulse'
                            : r.priority === 'Urgent'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {r.priority}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          r.status === 'Fulfilled'
                            ? 'bg-emerald-100 text-emerald-800'
                            : r.status === 'Approved'
                            ? 'bg-blue-100 text-blue-800'
                            : r.status === 'Pending'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-slate-600 font-mono text-[11px]">
                      {r.contact_number}
                    </td>
                    <td className="py-4 px-6 text-right space-x-1.5">
                      {r.status === 'Pending' && (
                        <button
                          onClick={() => handleApprove(r.id)}
                          className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-blue-600 text-white hover:bg-blue-700 cursor-pointer shadow-xs"
                        >
                          Approve
                        </button>
                      )}
                      {r.status !== 'Fulfilled' && (
                        <button
                          onClick={() => handleFulfill(r.id)}
                          className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-red-600 hover:bg-red-700 text-white cursor-pointer shadow-xs"
                        >
                          Fulfill & Deduct
                        </button>
                      )}
                      {r.status === 'Pending' && (
                        <button
                          onClick={() => setRejectingId(r.id)}
                          className="px-2 py-1 text-[11px] font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 cursor-pointer"
                        >
                          Reject
                        </button>
                      )}
                      {r.status === 'Fulfilled' && (
                        <span className="text-[11px] text-emerald-700 font-bold flex items-center justify-end gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Dispatched
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Reject Modal */}
      {rejectingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 space-y-4 text-xs">
            <h3 className="font-heading font-bold text-sm text-slate-900">
              Reject Blood Requisition
            </h3>
            <p className="text-slate-500">
              Provide a clinical reason for audit trail compliance.
            </p>
            <form onSubmit={handleConfirmReject} className="space-y-3">
              <textarea
                required
                rows={3}
                placeholder="Reason (e.g. Incomplete cross-match requisition, duplicate patient entry...)"
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
              />
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRejectingId(null)}
                  className="px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-red-600 text-white font-bold rounded-lg"
                >
                  Confirm Rejection
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
