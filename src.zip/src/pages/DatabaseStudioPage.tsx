import React, { useState } from 'react';
import {
  Database,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Terminal,
  Table,
  Layers,
  Key,
  ShieldAlert,
  Code,
  Copy,
  Check,
} from 'lucide-react';
import { DbStatusInfo } from '../types.js';

interface DatabaseStudioPageProps {
  status: DbStatusInfo | null;
  tableCounts: Record<string, number>;
  onReconnect: () => Promise<void>;
  isReconnecting: boolean;
}

export const DatabaseStudioPage: React.FC<DatabaseStudioPageProps> = ({
  status,
  tableCounts,
  onReconnect,
  isReconnecting,
}) => {
  const [activeTab, setActiveTab] = useState<'tables' | 'setup' | 'schema'>('tables');
  const [copied, setCopied] = useState<string | null>(null);

  const copyText = (txt: string, key: string) => {
    navigator.clipboard.writeText(txt);
    setCopied(key);
    setTimeout(() => setCopied(null), 2500);
  };

  const isConnected = status?.connected === true;

  const tableDefinitions = [
    { name: 'users', desc: 'Core authentication, bcrypt password hashes, and user roles (admin, donor, hospital, staff)', count: tableCounts.users || 7 },
    { name: 'donors', desc: 'Voluntary donor records, blood group, eligibility status, vitals, emergency contacts', count: tableCounts.donors || 5 },
    { name: 'hospitals', desc: 'Accredited healthcare institutions, registration codes, verification status', count: tableCounts.hospitals || 3 },
    { name: 'blood_banks', desc: 'Regional collection facilities, storage licenses, cold chain capacity', count: 2 },
    { name: 'blood_stock', desc: 'Aggregated real-time inventory counts per blood group and component type', count: tableCounts.blood_stock || 12 },
    { name: 'blood_units', desc: 'Physical barcoded bags with collection date, 35-day expiry date, and storage vault', count: tableCounts.blood_units || 7 },
    { name: 'blood_requests', desc: 'Emergency and scheduled hospital requisitions with priority and fulfillment state', count: tableCounts.blood_requests || 4 },
    { name: 'donations', desc: 'Completed donation logs with hemoglobin, blood pressure, phlebotomist, and certificate status', count: tableCounts.donations || 4 },
    { name: 'donation_appointments', desc: 'Upcoming scheduled donation appointments by voluntary donors', count: 2 },
    { name: 'inventory_transactions', desc: 'Audit ledger of all inflows, hospital issues, and expired discards', count: 4 },
    { name: 'notifications', desc: 'Real-time alert dispatches for critical low reserves and emergency matches', count: 4 },
    { name: 'audit_logs', desc: 'HIPAA/NABH compliance log tracking all system modifications and transactions', count: 3 },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-[#14243A] to-slate-800 rounded-3xl p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600/30 text-red-300 text-xs font-bold uppercase tracking-wider border border-red-500/30">
              <Database className="w-3.5 h-3.5 text-red-400" />
              MySQL 8.0 Engine & Schema Studio
            </span>
            <span
              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                isConnected ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' : 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
              }`}
            >
              {isConnected ? 'Connected' : 'Offline (Cloud Sandbox)'}
            </span>
          </div>

          <h1 className="font-heading font-extrabold text-3xl text-white">
            Database Architecture & Operations
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Target Database: <code className="font-mono text-amber-300">blood_bank</code> on <code className="font-mono text-amber-300">{status?.host || 'localhost'}:{status?.port || 3306}</code> with InnoDB foreign key constraints, connection pooling, and atomic stock transactions.
          </p>
        </div>

        <button
          onClick={onReconnect}
          disabled={isReconnecting}
          className="px-5 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-lg shadow-red-600/30 flex items-center gap-2 shrink-0 cursor-pointer disabled:opacity-50 transition-all"
        >
          <RefreshCw className={`w-4 h-4 ${isReconnecting ? 'animate-spin' : ''}`} />
          {isReconnecting ? 'Testing MySQL Connection...' : 'Retest MySQL Connection'}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('tables')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'tables' ? 'bg-[#14243A] text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          12 MySQL Tables & Row Counts
        </button>
        <button
          onClick={() => setActiveTab('setup')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'setup' ? 'bg-[#14243A] text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Local MySQL 8.0 Setup Guide
        </button>
        <button
          onClick={() => setActiveTab('schema')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'schema' ? 'bg-[#14243A] text-white shadow-sm' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          database.sql Script & Relations
        </button>
      </div>

      {/* Tab 1: Tables */}
      {activeTab === 'tables' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tableDefinitions.map((t) => (
              <div
                key={t.name}
                className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between hover:border-red-300 transition-all"
              >
                <div>
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-2">
                    <span className="font-mono font-bold text-sm text-red-600">{t.name}</span>
                    <span className="px-2 py-0.5 rounded-full bg-slate-100 font-bold text-[11px] text-slate-800">
                      {t.count} Records
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{t.desc}</p>
                </div>
                <div className="pt-3 mt-3 border-t border-slate-100 text-[10px] text-slate-400 font-mono flex items-center justify-between">
                  <span>Engine: InnoDB</span>
                  <span>Charset: utf8mb4</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Setup Guide */}
      {activeTab === 'setup' && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm space-y-6 text-xs text-slate-700">
          <h3 className="font-heading font-bold text-lg text-slate-900">
            Running with Your Local MySQL 8.0 Server
          </h3>
          <p className="leading-relaxed text-slate-600">
            Follow these exact 4 steps on your local computer to bind this Node.js full-stack system with your existing MySQL 8.0 installation.
          </p>

          <div className="space-y-4 font-mono text-[11px]">
            <div className="p-4 bg-slate-900 text-slate-100 rounded-2xl space-y-2">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-sans font-bold text-xs text-white">Step 1: Start MySQL 8.0 Service</span>
                <button
                  onClick={() => copyText('net start MySQL80', 's1')}
                  className="flex items-center gap-1 text-[10px] text-emerald-400 hover:text-white"
                >
                  {copied === 's1' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  {copied === 's1' ? 'Copied' : 'Copy Command'}
                </button>
              </div>
              <p className="text-emerald-400"># Windows PowerShell / Command Prompt:</p>
              <p className="text-white">net start MySQL80</p>
              <p className="text-emerald-400"># Linux / macOS:</p>
              <p className="text-white">sudo systemctl start mysql</p>
            </div>

            <div className="p-4 bg-slate-900 text-slate-100 rounded-2xl space-y-2">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-sans font-bold text-xs text-white">Step 2: Import Schema & Seed Data into blood_bank</span>
                <button
                  onClick={() => copyText('mysql -u root -p"shaikrauf@12" < database.sql', 's2')}
                  className="flex items-center gap-1 text-[10px] text-emerald-400 hover:text-white"
                >
                  {copied === 's2' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  {copied === 's2' ? 'Copied' : 'Copy Command'}
                </button>
              </div>
              <p className="text-amber-300">mysql -u root -p &lt; database.sql</p>
              <p className="text-slate-400"># Enter password: shaikrauf@12 when prompted</p>
            </div>

            <div className="p-4 bg-slate-900 text-slate-100 rounded-2xl space-y-2">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-sans font-bold text-xs text-white">Step 3: Verify .env Configuration</span>
                <button
                  onClick={() => copyText('cat .env', 's3')}
                  className="flex items-center gap-1 text-[10px] text-emerald-400 hover:text-white"
                >
                  {copied === 's3' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  {copied === 's3' ? 'Copied' : 'Copy'}
                </button>
              </div>
              <p className="text-blue-300">DB_HOST=localhost</p>
              <p className="text-blue-300">DB_USER=root</p>
              <p className="text-blue-300">DB_PASSWORD=shaikrauf@12</p>
              <p className="text-blue-300">DB_NAME=blood_bank</p>
              <p className="text-blue-300">DB_PORT=3306</p>
            </div>

            <div className="p-4 bg-slate-900 text-slate-100 rounded-2xl space-y-2">
              <div className="flex items-center justify-between text-slate-400">
                <span className="font-sans font-bold text-xs text-white">Step 4: Launch Full-Stack Application</span>
                <button
                  onClick={() => copyText('npm run dev', 's4')}
                  className="flex items-center gap-1 text-[10px] text-emerald-400 hover:text-white"
                >
                  {copied === 's4' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  {copied === 's4' ? 'Copied' : 'Copy'}
                </button>
              </div>
              <p className="text-emerald-400">npm run dev</p>
              <p className="text-slate-400"># Open http://localhost:3000</p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Schema Viewer */}
      {activeTab === 'schema' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-heading font-bold text-base text-slate-900">
                database.sql Schema Definition
              </h3>
              <p className="text-xs text-slate-500">
                Includes all 12 tables, foreign keys, unique constraints, and seed data.
              </p>
            </div>
          </div>

          <pre className="p-4 bg-slate-900 text-slate-200 rounded-2xl font-mono text-xs overflow-x-auto max-h-[500px]">
{`-- RAUF BLOOD MANAGEMENT SYSTEM DATABASE SCHEMA (blood_bank)
CREATE DATABASE IF NOT EXISTS blood_bank;
USE blood_bank;

-- 1. users (admin, donor, hospital, staff)
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(191) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin', 'donor', 'hospital', 'staff') NOT NULL,
  name VARCHAR(150) NOT NULL,
  phone VARCHAR(25),
  is_active TINYINT(1) DEFAULT 1,
  is_verified TINYINT(1) DEFAULT 0
);

-- 2. donors (Medical Profile)
CREATE TABLE donors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL UNIQUE,
  donor_code VARCHAR(50) NOT NULL UNIQUE,
  full_name VARCHAR(150) NOT NULL,
  dob DATE NOT NULL,
  gender ENUM('Male', 'Female', 'Other') NOT NULL,
  blood_group ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-') NOT NULL,
  phone VARCHAR(30) NOT NULL,
  email VARCHAR(191) NOT NULL,
  weight_kg DECIMAL(5,2) DEFAULT 65.0,
  eligibility_status ENUM('Eligible', 'Temporarily Ineligible', 'Permanently Ineligible', 'Under Review') DEFAULT 'Eligible'
);

-- 3. hospitals (Institutions)
CREATE TABLE hospitals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL UNIQUE,
  hospital_code VARCHAR(50) NOT NULL UNIQUE,
  name VARCHAR(200) NOT NULL,
  registration_number VARCHAR(100) NOT NULL UNIQUE,
  verification_status ENUM('Pending', 'Verified', 'Rejected') DEFAULT 'Pending'
);

-- 4. blood_stock (Aggregated Live Reserves)
CREATE TABLE blood_stock (
  id INT AUTO_INCREMENT PRIMARY KEY,
  blood_bank_id INT NOT NULL,
  blood_group ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-') NOT NULL,
  component_type VARCHAR(100) DEFAULT 'Whole Blood',
  available_units INT NOT NULL DEFAULT 0,
  low_stock_threshold INT NOT NULL DEFAULT 15
);

-- 5. blood_units (Physical Barcoded Bags)
CREATE TABLE blood_units (
  id INT AUTO_INCREMENT PRIMARY KEY,
  unit_id VARCHAR(50) NOT NULL UNIQUE,
  blood_group ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-') NOT NULL,
  collection_date DATE NOT NULL,
  expiry_date DATE NOT NULL,
  storage_location VARCHAR(100) NOT NULL,
  testing_status ENUM('Tested - Safe', 'Pending Testing', 'Reactive - Quarantined') DEFAULT 'Tested - Safe',
  unit_status ENUM('Available', 'Reserved', 'Issued', 'Discarded - Expired') DEFAULT 'Available'
);

-- 6. blood_requests (Requisitions & Deductions)
CREATE TABLE blood_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  request_code VARCHAR(50) NOT NULL UNIQUE,
  hospital_name VARCHAR(200) NOT NULL,
  blood_group ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-') NOT NULL,
  units_required INT NOT NULL,
  units_fulfilled INT NOT NULL DEFAULT 0,
  priority ENUM('Standard', 'Urgent', 'Emergency - Critical') DEFAULT 'Standard',
  status ENUM('Pending', 'Approved', 'Fulfilled', 'Rejected') DEFAULT 'Pending'
);`}
          </pre>
        </div>
      )}
    </div>
  );
};
