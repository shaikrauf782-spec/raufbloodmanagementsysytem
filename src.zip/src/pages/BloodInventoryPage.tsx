import React, { useState, useEffect } from 'react';
import {
  Droplet,
  PlusCircle,
  Filter,
  Search,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Trash2,
  Edit3,
  X,
  Package,
  Layers,
} from 'lucide-react';
import { BloodGroup, BloodStockItem, BloodUnit } from '../types.js';
import { api } from '../api/client.js';

interface BloodInventoryPageProps {
  onNavigate: (page: string) => void;
  onRequestBlood: (group: BloodGroup) => void;
}

export const BloodInventoryPage: React.FC<BloodInventoryPageProps> = ({ onNavigate, onRequestBlood }) => {
  const [inventory, setInventory] = useState<BloodStockItem[]>([]);
  const [units, setUnits] = useState<BloodUnit[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Add Unit Modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [newUnitForm, setNewUnitForm] = useState({
    blood_group: 'O+' as BloodGroup,
    component_type: 'Whole Blood',
    volume_ml: 450,
    storage_location: 'Cold Storage Bay A',
    testing_status: 'Tested - Safe' as 'Tested - Safe' | 'Pending Testing' | 'Reactive - Quarantined',
  });

  useEffect(() => {
    loadInventoryData();
  }, [selectedGroup, statusFilter]);

  const loadInventoryData = async () => {
    setLoading(true);
    try {
      const invRes = await api.getInventory();
      setInventory(invRes.inventory);

      const unitRes = await api.getUnits({
        blood_group: selectedGroup !== 'All' ? selectedGroup : undefined,
        status: statusFilter !== 'All' ? statusFilter : undefined,
      });
      setUnits(unitRes.data);
    } catch (err) {
      console.error('Failed to load blood inventory:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddUnit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.addUnit(newUnitForm);
      setFeedback(`New blood bag ${res.unit.unit_id} cataloged into MySQL inventory.`);
      setShowAddModal(false);
      loadInventoryData();
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(err.message || 'Failed to add blood stock');
    }
  };

  const handleUpdateUnitStatus = async (id: number, newStatus: any) => {
    try {
      await api.updateUnit(id, { unit_status: newStatus });
      setFeedback(`Bag status updated to ${newStatus} (Stock balances adjusted).`);
      loadInventoryData();
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const bloodGroups: Array<'All' | BloodGroup> = ['All', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-red-600">
            Certified Transfusion Inventory
          </span>
          <h1 className="font-heading font-extrabold text-3xl text-[#14243A]">
            Blood Bank Inventory Management
          </h1>
          <p className="text-xs text-slate-500">
            Real-time aggregate stock, physical bag barcodes, shelf-life monitoring, and cold chain logs.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-5 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md shadow-red-600/25 flex items-center gap-2 cursor-pointer transition-all"
        >
          <PlusCircle className="w-4 h-4" /> Add Blood Stock / Inflow
        </button>
      </div>

      {feedback && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-medium flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* 8 Blood Group Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {inventory.map((item) => (
          <div
            key={item.blood_group}
            onClick={() => setSelectedGroup(item.blood_group)}
            className={`p-4 rounded-2xl border text-center cursor-pointer transition-all ${
              selectedGroup === item.blood_group
                ? 'ring-2 ring-red-600 bg-red-50/60 border-red-300'
                : 'bg-white border-slate-200 hover:border-slate-300'
            }`}
          >
            <span className="font-heading font-extrabold text-lg text-red-600 block">
              {item.blood_group}
            </span>
            <span className="text-2xl font-extrabold font-heading text-slate-900 block my-1">
              {item.available_units}
            </span>
            <span className="text-[10px] text-slate-400 block font-semibold">Available Units</span>
            <span
              className={`inline-block mt-2 px-2 py-0.5 rounded-full text-[9px] font-bold uppercase ${
                item.status === 'Critical'
                  ? 'bg-red-100 text-red-800'
                  : item.status === 'Low'
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              {item.status}
            </span>
          </div>
        ))}
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-bold uppercase text-slate-400 mr-1 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Group:
          </span>
          {bloodGroups.map((bg) => (
            <button
              key={bg}
              onClick={() => setSelectedGroup(bg)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                selectedGroup === bg
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {bg}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-bold uppercase text-slate-400">Bag Status:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs p-1.5 rounded-lg border border-slate-300 font-semibold focus:outline-none focus:border-red-500"
          >
            <option value="All">All Bags</option>
            <option value="Available">Available (Ready)</option>
            <option value="Issued">Issued (Transfused)</option>
            <option value="Discarded - Expired">Discarded (Expired)</option>
            <option value="Reserved">Reserved</option>
          </select>
        </div>
      </div>

      {/* Physical Bag Units Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-heading font-bold text-base text-slate-900">
              Individual Blood Unit Bags & Cold Storage
            </h3>
            <p className="text-xs text-slate-500">
              Shelf life: 35 days for Whole Blood, 42 days for Packed RBCs. Expired or unquarantined bags are strictly excluded from dispatch.
            </p>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {units.length} Bags Matched
          </span>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">Loading blood bag records from MySQL...</div>
        ) : units.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-500">
            No blood units found matching current filter.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-100">
                <tr>
                  <th className="py-3 px-6">Barcode Unit ID</th>
                  <th className="py-3 px-6">Group & Component</th>
                  <th className="py-3 px-6">Volume</th>
                  <th className="py-3 px-6">Collection Date</th>
                  <th className="py-3 px-6">Expiry Date</th>
                  <th className="py-3 px-6">Storage Vault</th>
                  <th className="py-3 px-6">Testing Status</th>
                  <th className="py-3 px-6">Bag Status</th>
                  <th className="py-3 px-6 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {units.map((unit) => {
                  const isExpired = new Date(unit.expiry_date) < new Date();
                  return (
                    <tr key={unit.id} className="hover:bg-slate-50/70">
                      <td className="py-4 px-6 font-mono font-bold text-slate-800">
                        {unit.unit_id}
                      </td>
                      <td className="py-4 px-6">
                        <span className="font-heading font-extrabold text-sm text-red-600 mr-2">
                          {unit.blood_group}
                        </span>
                        <span className="text-slate-700">{unit.component_type}</span>
                      </td>
                      <td className="py-4 px-6 text-slate-600 font-medium">{unit.volume_ml} mL</td>
                      <td className="py-4 px-6 text-slate-600">{unit.collection_date}</td>
                      <td className="py-4 px-6">
                        <span className={`font-semibold ${isExpired ? 'text-red-600 font-bold' : 'text-slate-700'}`}>
                          {unit.expiry_date}
                          {isExpired && ' (EXPIRED)'}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-slate-500 font-mono text-[11px]">
                        {unit.storage_location}
                      </td>
                      <td className="py-4 px-6">
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                          <ShieldCheck className="w-3 h-3 text-emerald-600" />
                          {unit.testing_status}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            unit.unit_status === 'Available'
                              ? 'bg-emerald-100 text-emerald-800'
                              : unit.unit_status === 'Issued'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {unit.unit_status}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-right space-x-1.5">
                        {unit.unit_status === 'Available' && (
                          <button
                            onClick={() => handleUpdateUnitStatus(unit.id, 'Discarded - Expired')}
                            className="px-2 py-1 text-[10px] font-bold rounded bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200 cursor-pointer"
                          >
                            Mark Discarded
                          </button>
                        )}
                        {unit.unit_status !== 'Available' && (
                          <button
                            onClick={() => handleUpdateUnitStatus(unit.id, 'Available')}
                            className="px-2 py-1 text-[10px] font-bold rounded bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 cursor-pointer"
                          >
                            Restore Available
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Stock Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-heading font-bold text-base text-slate-900">
                Log New Blood Unit Inflow
              </h3>
              <button onClick={() => setShowAddModal(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddUnit} className="space-y-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Blood Group *</label>
                <select
                  value={newUnitForm.blood_group}
                  onChange={(e) => setNewUnitForm({ ...newUnitForm, blood_group: e.target.value as BloodGroup })}
                  className="w-full p-2.5 rounded-lg border border-slate-300 font-bold text-red-600 focus:outline-none focus:border-red-500"
                >
                  {(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as BloodGroup[]).map((bg) => (
                    <option key={bg} value={bg}>{bg}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Component Type</label>
                <select
                  value={newUnitForm.component_type}
                  onChange={(e) => setNewUnitForm({ ...newUnitForm, component_type: e.target.value })}
                  className="w-full p-2.5 rounded-lg border border-slate-300 font-medium focus:outline-none focus:border-red-500"
                >
                  <option value="Whole Blood">Whole Blood (35 days shelf life)</option>
                  <option value="Packed Red Cells">Packed Red Cells (42 days)</option>
                  <option value="Platelets">Platelets (5 days)</option>
                  <option value="Fresh Frozen Plasma">Fresh Frozen Plasma (1 year)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Volume (mL)</label>
                <input
                  type="number"
                  value={newUnitForm.volume_ml}
                  onChange={(e) => setNewUnitForm({ ...newUnitForm, volume_ml: Number(e.target.value) })}
                  className="w-full p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Cold Storage Location</label>
                <input
                  type="text"
                  value={newUnitForm.storage_location}
                  onChange={(e) => setNewUnitForm({ ...newUnitForm, storage_location: e.target.value })}
                  className="w-full p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Testing & Serology Clearance</label>
                <select
                  value={newUnitForm.testing_status}
                  onChange={(e) => setNewUnitForm({ ...newUnitForm, testing_status: e.target.value as any })}
                  className="w-full p-2.5 rounded-lg border border-slate-300 font-semibold focus:outline-none focus:border-red-500"
                >
                  <option value="Tested - Safe">Tested - Safe (HIV, Hep B/C, Syphilis Negative)</option>
                  <option value="Pending Testing">Pending Testing (Quarantine Bay)</option>
                  <option value="Reactive - Quarantined">Reactive - Quarantined</option>
                </select>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700"
                >
                  Catalog into MySQL
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
