import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Droplet } from 'lucide-react';

interface FaqPageProps {
  onNavigate: (page: string) => void;
}

export const FaqPage: React.FC<FaqPageProps> = ({ onNavigate }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Who is eligible to donate blood?',
      a: 'Healthy adults aged 18 to 65 weighing at least 45 kg (99 lbs) with hemoglobin levels ≥ 12.5 g/dL and normal blood pressure (between 100/60 and 140/90 mmHg) are eligible. You must not have had major surgery in the last 6 months or active viral infections.',
    },
    {
      q: 'How frequently can I donate blood?',
      a: 'For whole blood donation, male donors can donate every 90 days (12 weeks) and female donors every 120 days (16 weeks). For apheresis platelets, donations can be made every 15 days up to 24 times a year.',
    },
    {
      q: 'Does donating blood hurt or make me weak?',
      a: 'The actual pinprick takes only a split second. Your body naturally replenishes the lost fluid volume within 24–48 hours, and red blood cells are replaced within 4 to 6 weeks. Eating a nutritious meal and drinking extra fluids ensures you feel energetic shortly after.',
    },
    {
      q: 'How long can donated blood be safely stored in the bank?',
      a: 'Whole blood and Packed Red Blood Cells (PRBC) can be stored under refrigeration (2°C to 6°C) for up to 35 to 42 days. Platelets can be stored at room temperature with continuous agitation for up to 5 days. Fresh Frozen Plasma (FFP) can be stored frozen for up to 1 year.',
    },
    {
      q: 'How does Rauf Blood Management System verify hospital blood requests?',
      a: 'Hospital accounts must be registered with their state healthcare accreditation number and verified by our blood bank medical officer. Once verified, requests are cross-checked for patient ABO compatibility and deducted atomically from inventory.',
    },
    {
      q: 'What is the universal blood donor and recipient type?',
      a: 'O-negative (O-) is the universal red blood cell donor because its red blood cells lack A, B, and Rh antigens, making it safe for all emergency transfusions. AB-positive (AB+) is the universal recipient because patients with this type have all antigens and produce no antibodies against transfused red cells.',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      <div className="text-center space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-red-600 bg-red-50 px-3 py-1 rounded-full border border-red-200">
          Frequently Asked Questions
        </span>
        <h1 className="font-heading font-extrabold text-3xl sm:text-4xl text-[#14243A]">
          Blood Donation & Transfusion FAQ
        </h1>
        <p className="text-xs sm:text-sm text-slate-500">
          Everything you need to know about voluntary donation, medical eligibility, and transfusion protocols.
        </p>
      </div>

      <div className="space-y-4">
        {faqs.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden transition-all"
            >
              <button
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-50 transition-colors"
              >
                <span className="font-heading font-bold text-sm text-slate-900 flex items-center gap-2.5">
                  <Droplet className="w-4 h-4 text-red-600 shrink-0" />
                  {faq.q}
                </span>
                {isOpen ? (
                  <ChevronUp className="w-5 h-5 text-slate-400 shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-400 shrink-0" />
                )}
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-1 text-xs text-slate-600 leading-relaxed border-t border-slate-100">
                  {faq.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
