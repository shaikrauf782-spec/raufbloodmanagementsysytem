import React, { useState, useEffect } from 'react';
import {
  Shield,
  Users,
  Droplet,
  AlertTriangle,
  Building2,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  TrendingUp,
  FileText,
  Activity,
  PlusCircle,
  Search,
  ExternalLink,
  ChevronRight,
  AlertCircle,
  Database,
} from 'lucide-react';
import { BloodStockItem, DashboardStats, Hospital, BloodRequest, Donor } from '../types.js';
import { api } from '../api/client.js';

interface AdminDashboardPageProps {
  onNavigate: (page: string) => void;
  onRequestBlood: (group: any) => void;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ onNavigate }) => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [requests, setRequests] = useState<BloodRequest[]>([]);
  const [donors, setDonors] = useState<Donor[]>([]);
  const [inventory, setInventory] = useState<BloodStockItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      const [statsRes, hospRes, reqRes, donorRes, invRes] = await Promise.all([
        api.getDashboardStats(),
        api.getHospitals(),
        api.getRequests(),
        api.getDonors(),
        api.getInventory(),
      ]);

      setStats(statsRes.stats);
      setHospitals(hospRes.data);
      setRequests(reqRes.data);
      setDonors(donorRes.data);
      setInventory(invRes.inventory);
    } catch (err) {
      console.error('Failed to load admin stats:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyHospital = async (id: number, status: 'Verified' | 'Rejected') => {
    try {
      await api.verifyHospital(id, status);
      setFeedback(`Hospital status successfully updated to ${status} in MySQL!`);
      loadDashboardData();
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(err.message || 'Verification update failed');
    }
  };

  const handleFulfillRequest = async (id: number) => {
    try {
      const res = await api.fulfillRequest(id);
      setFeedback(res.message);
      loadDashboardData();
      setTimeout(() => setFeedback(null), 4000);
    } catch (err: any) {
      alert(err.message || 'Fulfillment error');
    }
  };

  const handleApproveRequest = async (id: number) => {
    try {
      await api.approveRequest(id);
      setFeedback('Blood requisition marked as Approved in database.');
      loadDashboardData();
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-red-700 via-red-800 to-[#14243A] rounded-3xl p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-white text-xs font-bold uppercase tracking-wider">
            <Shield className="w-3.5 h-3.5" /> Administrative Master Console
          </span>
          <h1 className="font-heading font-extrabold text-3xl sm:text-4xl text-white">
            Blood Transfusion Operations Center
          </h1>
          <p className="text-xs sm:text-sm text-red-100">
            Real-time control over regional blood inventory, emergency requisitions, voluntary donors, and hospital accreditations.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => onNavigate('inventory')}
            className="px-4 py-2.5 rounded-xl bg-white text-red-700 text-xs font-bold hover:bg-slate-100 transition-colors shadow-sm"
          >
            Manage Inventory
          </button>
          <button
            onClick={() => onNavigate('requests')}
            className="px-4 py-2.5 rounded-xl bg-red-900/60 hover:bg-red-900 text-white text-xs font-bold border border-white/20 transition-colors"
          >
            Review Requisitions
          </button>
        </div>
      </div>

      {feedback && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-medium flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Total Donors
          </span>
          <span className="text-2xl font-extrabold font-heading text-slate-900 block">
            {stats?.totalDonors || 0}
          </span>
          <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> Registered Heroes
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Blood Units
          </span>
          <span className="text-2xl font-extrabold font-heading text-red-600 block">
            {stats?.totalBloodUnits || 0}
          </span>
          <span className="text-[10px] text-slate-500 font-medium">Whole Blood & Tested</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Requisitions
          </span>
          <span className="text-2xl font-extrabold font-heading text-slate-900 block">
            {stats?.totalBloodRequests || 0}
          </span>
          <span className="text-[10px] text-slate-500 font-medium">Hospital Orders</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-amber-600 uppercase tracking-wider block">
            Pending Triage
          </span>
          <span className="text-2xl font-extrabold font-heading text-amber-600 block">
            {stats?.pendingRequests || 0}
          </span>
          <span className="text-[10px] text-amber-700 font-semibold">Requires Approval</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-emerald-600 uppercase tracking-wider block">
            Fulfilled
          </span>
          <span className="text-2xl font-extrabold font-heading text-emerald-600 block">
            {stats?.fulfilledRequests || 0}
          </span>
          <span className="text-[10px] text-emerald-700 font-semibold">Dispatched to OR</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Donations
          </span>
          <span className="text-2xl font-extrabold font-heading text-blue-600 block">
            {stats?.completedDonations || 0}
          </span>
          <span className="text-[10px] text-blue-700 font-medium">Sessions Logged</span>
        </div>
      </div>

      {/* Blood Group Distribution & Low Stock Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Blood Group Inventory Distribution Bar Visualization */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-heading font-bold text-base text-slate-900">
                Blood Group Inventory Levels (MySQL Live)
              </h3>
              <p className="text-xs text-slate-500">
                Current bag count vs minimum reserve threshold
              </p>
            </div>
            <button
              onClick={() => onNavigate('inventory')}
              className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1"
            >
              Inventory Management <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-4">
            {inventory.slice(0, 8).map((item) => {
              const maxScale = 100;
              const pct = Math.min(100, Math.round((item.available_units / maxScale) * 100));
              const isLow = item.status === 'Low' || item.status === 'Critical';

              return (
                <div key={item.blood_group} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="flex items-center gap-2">
                      <span className="w-8 font-extrabold text-red-600 text-sm">{item.blood_group}</span>
                      <span className="text-slate-700 font-mono text-[11px]">{item.available_units} units available</span>
                    </span>
                    <span
                      className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                        item.status === 'Critical'
                          ? 'bg-red-100 text-red-800'
                          : item.status === 'Low'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {item.status} (Min: {item.low_threshold})
                    </span>
                  </div>

                  <div className="w-full h-3 rounded-full bg-slate-100 overflow-hidden flex">
                    <div
                      style={{ width: `${pct}%` }}
                      className={`h-full transition-all duration-500 rounded-full ${
                        item.status === 'Critical'
                          ? 'bg-red-600'
                          : item.status === 'Low'
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Low Stock Alerts & Critical Triage */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-4 border-b border-slate-100">
              <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-heading font-bold text-sm text-slate-900">
                  Critical Stock Warnings
                </h3>
                <p className="text-[11px] text-slate-500">Groups below safety reserve</p>
              </div>
            </div>

            <div className="mt-4 space-y-3">
              {inventory.filter((i) => i.status === 'Low' || i.status === 'Critical').length === 0 ? (
                <div className="p-4 rounded-xl bg-emerald-50 text-emerald-800 text-xs text-center font-medium">
                  All 8 blood groups maintain adequate safety reserves.
                </div>
              ) : (
                inventory
                  .filter((i) => i.status === 'Low' || i.status === 'Critical')
                  .map((low) => (
                    <div
                      key={low.blood_group}
                      className="p-3 rounded-xl bg-red-50/80 border border-red-200 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-extrabold font-heading text-red-700 text-sm block">
                          Group {low.blood_group}
                        </span>
                        <span className="text-[11px] text-slate-600 block">
                          Only {low.available_units} units in bank (Safety buffer: {low.low_threshold})
                        </span>
                      </div>
                      <button
                        onClick={() => onNavigate('donors')}
                        className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-red-600 text-white hover:bg-red-700"
                      >
                        Mobilize
                      </button>
                    </div>
                  ))
              )}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <button
              onClick={() => onNavigate('donations')}
              className="w-full py-2.5 rounded-xl bg-slate-900 text-white hover:bg-slate-800 text-xs font-bold flex items-center justify-center gap-2"
            >
              <Calendar className="w-4 h-4" /> Schedule Emergency Blood Drive
            </button>
          </div>
        </div>
      </div>

      {/* Hospital Verification Management Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-heading font-bold text-base text-slate-900">
              Hospital Accreditation & Access Approval
            </h3>
            <p className="text-xs text-slate-500">
              Administrators must verify hospital credentials before they can receive blood dispatches
            </p>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {hospitals.length} Registered Hospitals
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-100">
              <tr>
                <th className="py-3 px-6">Hospital</th>
                <th className="py-3 px-6">License / Code</th>
                <th className="py-3 px-6">Contact Person</th>
                <th className="py-3 px-6">Emergency Phone</th>
                <th className="py-3 px-6">Status</th>
                <th className="py-3 px-6 text-right">Administrative Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {hospitals.map((hosp) => (
                <tr key={hosp.id} className="hover:bg-slate-50/70">
                  <td className="py-4 px-6 font-semibold text-slate-800">
                    {hosp.name}
                    <span className="block text-[11px] text-slate-400 font-normal">{hosp.city}, {hosp.state}</span>
                  </td>
                  <td className="py-4 px-6 font-mono text-slate-600">
                    {hosp.registration_number}
                    <span className="block text-[10px] text-slate-400">{hosp.hospital_code}</span>
                  </td>
                  <td className="py-4 px-6 text-slate-700">
                    {hosp.contact_person}
                    <span className="block text-[10px] text-slate-400">{hosp.designation}</span>
                  </td>
                  <td className="py-4 px-6 text-red-600 font-mono font-medium">
                    {hosp.emergency_phone}
                  </td>
                  <td className="py-4 px-6">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        hosp.verification_status === 'Verified'
                          ? 'bg-emerald-100 text-emerald-800'
                          : hosp.verification_status === 'Pending'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {hosp.verification_status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right space-x-2">
                    {hosp.verification_status !== 'Verified' && (
                      <button
                        onClick={() => handleVerifyHospital(hosp.id, 'Verified')}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] shadow-xs cursor-pointer"
                      >
                        Verify & Grant Access
                      </button>
                    )}
                    {hosp.verification_status !== 'Rejected' && (
                      <button
                        onClick={() => handleVerifyHospital(hosp.id, 'Rejected')}
                        className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] cursor-pointer"
                      >
                        Reject
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Emergency Requisitions Pending Action */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-heading font-bold text-base text-slate-900">
              Active Blood Requisitions & Stock Deduction Controls
            </h3>
            <p className="text-xs text-slate-500">
              Click &quot;Fulfill & Deduct Stock&quot; to execute real-time inventory deduction and issue barcodes
            </p>
          </div>
          <button
            onClick={() => onNavigate('requests')}
            className="text-xs font-bold text-red-600 hover:text-red-700"
          >
            View Full Requisition Log
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-100">
              <tr>
                <th className="py-3 px-6">Request ID</th>
                <th className="py-3 px-6">Hospital & Patient</th>
                <th className="py-3 px-6">Blood Type</th>
                <th className="py-3 px-6">Units Req/Fulfilled</th>
                <th className="py-3 px-6">Priority</th>
                <th className="py-3 px-6">Status</th>
                <th className="py-3 px-6 text-right">Inventory Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {requests.slice(0, 5).map((reqItem) => (
                <tr key={reqItem.id} className="hover:bg-slate-50/70">
                  <td className="py-4 px-6 font-mono font-bold text-slate-800">
                    {reqItem.request_code}
                  </td>
                  <td className="py-4 px-6">
                    <span className="font-bold text-slate-900 block">{reqItem.hospital_name}</span>
                    <span className="text-[11px] text-slate-500 block">Patient: {reqItem.patient_name} ({reqItem.patient_ref_id})</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="font-heading font-extrabold text-sm text-red-600 bg-red-50 px-2 py-0.5 rounded border border-red-100">
                      {reqItem.blood_group}
                    </span>
                  </td>
                  <td className="py-4 px-6 font-semibold text-slate-800">
                    {reqItem.units_fulfilled} / {reqItem.units_required} Units
                  </td>
                  <td className="py-4 px-6">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                        reqItem.priority === 'Emergency - Critical'
                          ? 'bg-red-100 text-red-800 animate-pulse'
                          : reqItem.priority === 'Urgent'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {reqItem.priority}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        reqItem.status === 'Fulfilled'
                          ? 'bg-emerald-100 text-emerald-800'
                          : reqItem.status === 'Approved'
                          ? 'bg-blue-100 text-blue-800'
                          : reqItem.status === 'Pending'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {reqItem.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right space-x-2">
                    {reqItem.status === 'Pending' && (
                      <button
                        onClick={() => handleApproveRequest(reqItem.id)}
                        className="px-2.5 py-1 rounded bg-blue-600 text-white font-bold text-[11px] hover:bg-blue-700"
                      >
                        Approve
                      </button>
                    )}
                    {reqItem.status !== 'Fulfilled' && (
                      <button
                        onClick={() => handleFulfillRequest(reqItem.id)}
                        className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-[11px] shadow-xs cursor-pointer"
                      >
                        Fulfill & Deduct Stock
                      </button>
                    )}
                    {reqItem.status === 'Fulfilled' && (
                      <span className="text-[11px] text-emerald-700 font-bold flex items-center justify-end gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Dispatched
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
