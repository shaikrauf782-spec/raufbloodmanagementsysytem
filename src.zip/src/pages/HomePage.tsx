import React from 'react';
import {
  Droplet,
  Heart,
  Shield,
  Search,
  PlusCircle,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Building2,
  Users,
  Activity,
  Award,
  Calendar,
  Clock,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { BloodStockItem, DashboardStats } from '../types.js';

interface HomePageProps {
  onNavigate: (page: string) => void;
  inventory: BloodStockItem[];
  stats: DashboardStats | null;
  onOpenQuickRequest: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  inventory,
  stats,
  onOpenQuickRequest,
}) => {
  // Compatibility data
  const compatibilityList = [
    { group: 'O-', canGiveTo: 'All Blood Groups (Universal Donor)', canReceiveFrom: 'O-' },
    { group: 'O+', canGiveTo: 'O+, A+, B+, AB+', canReceiveFrom: 'O+, O-' },
    { group: 'A-', canGiveTo: 'A-, A+, AB-, AB+', canReceiveFrom: 'A-, O-' },
    { group: 'A+', canGiveTo: 'A+, AB+', canReceiveFrom: 'A+, A-, O+, O-' },
    { group: 'B-', canGiveTo: 'B-, B+, AB-, AB+', canReceiveFrom: 'B-, O-' },
    { group: 'B+', canGiveTo: 'B+, AB+', canReceiveFrom: 'B+, B-, O+, O-' },
    { group: 'AB-', canGiveTo: 'AB-, AB+', canReceiveFrom: 'AB-, A-, B-, O-' },
    { group: 'AB+', canGiveTo: 'AB+ Only', canReceiveFrom: 'All Blood Groups (Universal Recipient)' },
  ];

  return (
    <div className="space-y-16 pb-20">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-red-50/70 via-white to-[#F8FAFC] pt-12 pb-20 border-b border-red-100">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-red-100/50 blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-blue-100/40 blur-3xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Heading and CTAs */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-100/80 border border-red-200 text-red-800 text-xs font-semibold">
                <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></span>
                Rauf Blood Management System • Live Network
              </div>

              <h1 className="font-heading font-extrabold text-4xl sm:text-5xl lg:text-6xl text-[#14243A] tracking-tight leading-[1.15]">
                Every Drop Counts. <br />
                <span className="text-red-600">Every Donor Matters.</span>
              </h1>

              <p className="text-base sm:text-lg text-slate-600 max-w-2xl leading-relaxed">
                Rauf Blood Management System provides real-time tracking of blood inventory, instant hospital requisition fulfillment, and voluntary donor mobilization to ensure zero preventable delays during critical surgeries.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3.5 pt-2">
                <button
                  onClick={() => onNavigate('register-donor')}
                  className="px-6 py-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm shadow-lg shadow-red-600/30 flex items-center gap-2 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
                >
                  <Heart className="w-4 h-4 fill-white" />
                  Become a Donor
                </button>

                <button
                  onClick={() => onNavigate('find-blood')}
                  className="px-6 py-3.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-bold text-sm border border-slate-300 shadow-sm flex items-center gap-2 hover:scale-[1.02] transition-all cursor-pointer"
                >
                  <Search className="w-4 h-4 text-red-600" />
                  Find Blood Available
                </button>

                <button
                  onClick={onOpenQuickRequest}
                  className="px-5 py-3.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-sm border border-red-200 flex items-center gap-2 transition-all cursor-pointer"
                >
                  <AlertTriangle className="w-4 h-4" />
                  Emergency Request
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="pt-6 border-t border-slate-200/80 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs text-slate-500 font-medium">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" /> 100% Tested & Safe Units
                </span>
                <span className="flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-emerald-600" /> NABH / Blood Bank Certified
                </span>
                <span className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-emerald-600" /> 24/7 Rapid Dispatch
                </span>
              </div>
            </div>

            {/* Right Column: Live Blood Availability Quick Card */}
            <div className="lg:col-span-5">
              <div className="bg-white rounded-2xl p-6 shadow-xl border border-slate-200 relative">
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
                      <Droplet className="w-4 h-4 fill-red-600" />
                    </div>
                    <div>
                      <h3 className="font-heading font-bold text-slate-900 text-sm">
                        Live Blood Stock Levels
                      </h3>
                      <p className="text-[11px] text-slate-500">Real-time inventory from database</p>
                    </div>
                  </div>
                  <button
                    onClick={() => onNavigate('inventory')}
                    className="text-xs font-semibold text-red-600 hover:text-red-700 flex items-center gap-1"
                  >
                    View All <ArrowRight className="w-3 h-3" />
                  </button>
                </div>

                <div className="grid grid-cols-4 gap-2.5 my-5">
                  {inventory.slice(0, 8).map((item) => (
                    <div
                      key={item.blood_group}
                      onClick={() => onNavigate('find-blood')}
                      className={`p-3 rounded-xl border text-center cursor-pointer transition-all hover:scale-105 ${
                        item.status === 'Critical'
                          ? 'bg-red-50/80 border-red-300 text-red-900'
                          : item.status === 'Low'
                          ? 'bg-amber-50/80 border-amber-300 text-amber-900'
                          : 'bg-slate-50 border-slate-200 text-slate-800'
                      }`}
                    >
                      <span className="font-heading font-extrabold text-base block text-red-600">
                        {item.blood_group}
                      </span>
                      <span className="text-sm font-bold block">{item.available_units}</span>
                      <span className="text-[9px] uppercase tracking-wider block font-semibold text-slate-500">
                        Units
                      </span>
                    </div>
                  ))}
                </div>

                <div className="p-3 bg-red-50/80 rounded-xl border border-red-100 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                    <span className="text-red-900 font-medium">
                      O- & B- are in high demand today.
                    </span>
                  </div>
                  <button
                    onClick={() => onNavigate('register-donor')}
                    className="font-bold text-red-700 hover:text-red-800 underline decoration-red-300"
                  >
                    Donate Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Live System Counter Statistics */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-md flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-red-100 text-red-600 flex items-center justify-center shrink-0">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <span className="text-2xl font-extrabold font-heading text-slate-900 block">
                {stats?.totalDonors || 14}
              </span>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Registered Donors
              </span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-md flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
              <Droplet className="w-6 h-6 fill-emerald-600" />
            </div>
            <div>
              <span className="text-2xl font-extrabold font-heading text-slate-900 block">
                {stats?.totalBloodUnits || 247}
              </span>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Available Blood Units
              </span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-md flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <span className="text-2xl font-extrabold font-heading text-slate-900 block">
                {stats?.fulfilledRequests || 18}
              </span>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Requests Fulfilled
              </span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-md flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center shrink-0">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <span className="text-2xl font-extrabold font-heading text-slate-900 block">
                3
              </span>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Partner Hospitals
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10">
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <span className="text-xs font-bold uppercase tracking-widest text-red-600 bg-red-50 px-3 py-1 rounded-full border border-red-200">
            Simple 4-Step Process
          </span>
          <h2 className="font-heading font-extrabold text-3xl sm:text-4xl text-[#14243A]">
            How Blood Donation Works
          </h2>
          <p className="text-sm text-slate-600">
            A single donation takes less than 45 minutes from check-in to refreshments, but saves up to 3 lives.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative group hover:border-red-300 transition-all">
            <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 font-extrabold font-heading flex items-center justify-center mb-4 text-base">
              01
            </div>
            <h3 className="font-heading font-bold text-base text-slate-900 mb-2">Registration</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Create your voluntary donor profile with contact info, blood group, and medical history.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative group hover:border-red-300 transition-all">
            <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 font-extrabold font-heading flex items-center justify-center mb-4 text-base">
              02
            </div>
            <h3 className="font-heading font-bold text-base text-slate-900 mb-2">Health Checkup</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              A certified phlebotomist tests your hemoglobin (&ge; 12.5 g/dL), blood pressure, and pulse.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative group hover:border-red-300 transition-all">
            <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 font-extrabold font-heading flex items-center justify-center mb-4 text-base">
              03
            </div>
            <h3 className="font-heading font-bold text-base text-slate-900 mb-2">The Donation</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Relax in a sterile medical lounge while approximately 350-450 mL of blood is collected safely in 10 minutes.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative group hover:border-red-300 transition-all">
            <div className="w-10 h-10 rounded-xl bg-red-100 text-red-700 font-extrabold font-heading flex items-center justify-center mb-4 text-base">
              04
            </div>
            <h3 className="font-heading font-bold text-base text-slate-900 mb-2">Refresh & Certificate</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Enjoy juice and snacks, receive your official donor certification, and earn digital donor badges.
            </p>
          </div>
        </div>
      </section>

      {/* Universal Blood Compatibility Matrix */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-md">
          <div className="max-w-3xl mb-8 space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-red-600">
              Transfusion Biology
            </span>
            <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-[#14243A]">
              Blood Group Compatibility Matrix
            </h2>
            <p className="text-xs text-slate-600">
              Understanding ABO and Rh antigen compatibility prevents acute hemolytic transfusion reactions.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-700 font-bold uppercase tracking-wider">
                  <th className="py-3 px-4">Blood Group</th>
                  <th className="py-3 px-4">Can Donate Blood To</th>
                  <th className="py-3 px-4">Can Receive Blood From</th>
                  <th className="py-3 px-4">Clinical Specialty</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {compatibilityList.map((row) => (
                  <tr key={row.group} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-4 font-heading font-extrabold text-sm text-red-600">
                      {row.group}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-800">{row.canGiveTo}</td>
                    <td className="py-3.5 px-4 text-slate-600">{row.canReceiveFrom}</td>
                    <td className="py-3.5 px-4">
                      {row.group === 'O-' ? (
                        <span className="inline-block px-2 py-0.5 rounded-full bg-red-100 text-red-800 font-bold text-[10px]">
                          Universal Red Cell Donor
                        </span>
                      ) : row.group === 'AB+' ? (
                        <span className="inline-block px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold text-[10px]">
                          Universal Recipient
                        </span>
                      ) : (
                        <span className="text-slate-500">Standard Compatibility</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Testimonials Section (Clearly Marked Sample Content as Required) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto space-y-2 mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-slate-400">
            Community Impact (Sample Verified Stories)
          </span>
          <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-[#14243A]">
            Stories of Hope & Recovery
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <p className="text-xs text-slate-600 italic leading-relaxed">
              &quot;When our ICU received a severe multi-trauma patient requiring 6 units of O-negative blood, the Rauf Blood Management System real-time inventory located units in 4 minutes. A lifesaver for our surgical team.&quot;
            </p>
            <div className="pt-2 border-t border-slate-100 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs">
                EH
              </div>
              <div>
                <span className="font-heading font-bold text-xs text-slate-900 block">Dr. Evelyn Howard</span>
                <span className="text-[10px] text-slate-400">Chief Medical Officer, St. Jude General</span>
              </div>
            </div>
            <span className="text-[9px] uppercase tracking-wider text-slate-400 block font-mono">
              [Sample Clinical Testimonial]
            </span>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <p className="text-xs text-slate-600 italic leading-relaxed">
              &quot;I have donated blood 12 times through Rauf Blood Management System. The digital health tracking and SMS reminders when an emergency blood request matches my B-negative type make giving blood effortless.&quot;
            </p>
            <div className="pt-2 border-t border-slate-100 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-red-100 text-red-700 font-bold flex items-center justify-center text-xs">
                MV
              </div>
              <div>
                <span className="font-heading font-bold text-xs text-slate-900 block">Marcus Vance</span>
                <span className="text-[10px] text-slate-400">Voluntary Donor (12 Donations)</span>
              </div>
            </div>
            <span className="text-[9px] uppercase tracking-wider text-slate-400 block font-mono">
              [Sample Donor Testimonial]
            </span>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <p className="text-xs text-slate-600 italic leading-relaxed">
              &quot;My daughter required whole blood transfusion during pediatric surgery. Thanks to the voluntary donors registered on this platform, the hospital had the exact blood match on standby.&quot;
            </p>
            <div className="pt-2 border-t border-slate-100 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 font-bold flex items-center justify-center text-xs">
                SL
              </div>
              <div>
                <span className="font-heading font-bold text-xs text-slate-900 block">Sarah L.</span>
                <span className="text-[10px] text-slate-400">Patient Family Advocate</span>
              </div>
            </div>
            <span className="text-[9px] uppercase tracking-wider text-slate-400 block font-mono">
              [Sample Recipient Testimonial]
            </span>
          </div>
        </div>
      </section>

      {/* Emergency Callout Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-red-600 to-red-800 rounded-3xl p-8 sm:p-12 text-white shadow-xl shadow-red-600/20 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-3 max-w-2xl">
            <span className="inline-block px-3 py-1 rounded-full bg-white/20 text-white text-xs font-bold uppercase tracking-wider">
              Are You a Certified Hospital or Clinic?
            </span>
            <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-white">
              Connect Your Hospital Transfusion Wing Today
            </h2>
            <p className="text-xs sm:text-sm text-red-100 leading-relaxed">
              Register your institution for instant requisition rights, priority cross-matching, and real-time inventory allocation.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={() => onNavigate('register-hospital')}
              className="px-6 py-3.5 rounded-xl bg-white text-red-700 hover:bg-slate-100 font-bold text-xs shadow-md transition-all cursor-pointer"
            >
              Register Hospital
            </button>
            <button
              onClick={onOpenQuickRequest}
              className="px-6 py-3.5 rounded-xl bg-red-900/60 hover:bg-red-900 text-white font-bold text-xs border border-white/20 transition-all cursor-pointer"
            >
              Emergency Requisition
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
