import React, { useState, useEffect } from 'react';
import {
  Heart,
  Calendar,
  Award,
  CheckCircle2,
  Clock,
  Droplet,
  Shield,
  Activity,
  MapPin,
  QrCode,
  Download,
} from 'lucide-react';
import { Donor, Donation, User } from '../types.js';
import { api } from '../api/client.js';

interface DonorDashboardPageProps {
  currentUser: User | null;
  onNavigate: (page: string) => void;
}

export const DonorDashboardPage: React.FC<DonorDashboardPageProps> = ({ currentUser, onNavigate }) => {
  const [donor, setDonor] = useState<Donor | null>(null);
  const [donations, setDonations] = useState<Donation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDonorData();
  }, [currentUser]);

  const loadDonorData = async () => {
    setLoading(true);
    try {
      const res = await api.getDonors();
      // Match by user_id or email, or pick first donor for showcase
      const matched = res.data.find(
        (d) => (currentUser && d.user_id === currentUser.id) || (currentUser && d.email === currentUser.email)
      ) || res.data[0];

      if (matched) {
        setDonor(matched);
        const donRes = await api.getDonorById(matched.id);
        setDonations(donRes.donations);
      }
    } catch (err) {
      console.error('Failed to load donor portal:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !donor) {
    return <div className="max-w-7xl mx-auto p-12 text-center text-xs text-slate-400">Loading Donor Hub from MySQL...</div>;
  }

  // Calculate next eligible donation date (56 days for whole blood)
  let nextDateStr = 'Eligible Now';
  if (donor.last_donation_date) {
    const last = new Date(donor.last_donation_date);
    const next = new Date(last);
    next.setDate(last.getDate() + 56);
    if (next > new Date()) {
      nextDateStr = next.toISOString().split('T')[0];
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-600 via-red-700 to-slate-900 rounded-3xl p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-white text-xs font-bold uppercase tracking-wider">
            <Heart className="w-3.5 h-3.5 fill-white" /> Voluntary Hero Portal
          </span>
          <h1 className="font-heading font-extrabold text-3xl text-white">
            Welcome Back, {donor.full_name}
          </h1>
          <p className="text-xs sm:text-sm text-red-100">
            Donor Code: <strong className="font-mono text-white">{donor.donor_code}</strong> • Blood Group: <strong className="font-bold text-white text-base">{donor.blood_group}</strong>
          </p>
        </div>

        <button
          onClick={() => onNavigate('donations')}
          className="px-5 py-3 rounded-xl bg-white text-red-700 font-bold text-xs hover:bg-slate-100 transition-colors shadow-md cursor-pointer shrink-0"
        >
          Book Next Donation Appointment
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Digital Donor Card */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-gradient-to-br from-red-600 to-red-900 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
            <div className="absolute right-0 top-0 -mr-10 -mt-10 w-40 h-40 bg-white/10 rounded-full blur-2xl"></div>

            <div className="flex items-center justify-between pb-4 border-b border-white/20">
              <div className="flex items-center gap-2">
                <Droplet className="w-5 h-5 fill-white" />
                <span className="font-heading font-extrabold tracking-tight text-sm">RAUF BLOOD DONOR CARD</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-white/20 text-[10px] font-bold">CERTIFIED</span>
            </div>

            <div className="my-6 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-red-200 block">Donor Name</span>
                <span className="font-heading font-extrabold text-lg block">{donor.full_name}</span>
                <span className="text-xs font-mono text-red-200 block">{donor.donor_code}</span>
              </div>
              <div className="w-16 h-16 rounded-2xl bg-white text-red-600 flex items-center justify-center font-heading font-extrabold text-3xl shadow-lg">
                {donor.blood_group}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-4 border-t border-white/20 text-xs">
              <div>
                <span className="text-[10px] text-red-200 block">Total Donations</span>
                <span className="font-bold text-base">{donor.total_donations_count} Bags</span>
              </div>
              <div>
                <span className="text-[10px] text-red-200 block">Next Eligible Date</span>
                <span className="font-bold text-sm text-emerald-300">{nextDateStr}</span>
              </div>
            </div>
          </div>

          {/* Quick Health Summary */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 className="font-heading font-bold text-sm text-slate-900 pb-2 border-b border-slate-100">
              Medical Eligibility Summary
            </h3>
            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Eligibility Status</span>
                <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  {donor.eligibility_status}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Weight</span>
                <span className="font-bold text-slate-800">{donor.weight_kg} kg</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Gender & DOB</span>
                <span className="font-bold text-slate-800">{donor.gender} ({donor.dob})</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Registered City</span>
                <span className="font-bold text-slate-800">{donor.city}, {donor.state}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Donation History & Certificates */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-heading font-bold text-base text-slate-900">
                  My Lifetime Blood Donation History
                </h3>
                <p className="text-xs text-slate-500">
                  Certified records logged by regional blood transfusion services
                </p>
              </div>
              <span className="text-xs font-bold text-red-600">
                {donations.length} Sessions Logged
              </span>
            </div>

            {donations.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 space-y-2">
                <p>No logged donation sessions found for this donor account yet.</p>
                <button
                  onClick={() => onNavigate('donations')}
                  className="px-4 py-2 bg-red-600 text-white rounded-xl font-bold"
                >
                  Record Initial Donation
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {donations.map((don) => (
                  <div
                    key={don.id}
                    className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center font-bold text-sm">
                        <Droplet className="w-5 h-5 fill-red-600" />
                      </div>
                      <div>
                        <span className="font-bold text-slate-900 block text-sm">
                          {don.units_donated} Unit {don.blood_group} Whole Blood
                        </span>
                        <span className="text-slate-500 block text-[11px]">
                          Date: {don.donation_date} • Session: {don.donation_code}
                        </span>
                        <span className="text-slate-500 block text-[11px]">
                          Vitals: Hb {don.hemoglobin_level} g/dL • BP: {don.blood_pressure}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[11px]">
                        <Award className="w-3.5 h-3.5" /> Certificate Verified
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
