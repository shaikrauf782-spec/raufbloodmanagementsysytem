import React, { useState, useEffect } from 'react';
import {
  Building2,
  AlertTriangle,
  Clock,
  CheckCircle2,
  PlusCircle,
  Phone,
  ShieldCheck,
  Search,
  Droplet,
} from 'lucide-react';
import { Hospital, BloodRequest, BloodStockItem, User } from '../types.js';
import { api } from '../api/client.js';

interface HospitalDashboardPageProps {
  currentUser: User | null;
  onNavigate: (page: string) => void;
  onOpenQuickRequest: () => void;
}

export const HospitalDashboardPage: React.FC<HospitalDashboardPageProps> = ({
  currentUser,
  onNavigate,
  onOpenQuickRequest,
}) => {
  const [hospital, setHospital] = useState<Hospital | null>(null);
  const [requests, setRequests] = useState<BloodRequest[]>([]);
  const [inventory, setInventory] = useState<BloodStockItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHospitalData();
  }, [currentUser]);

  const loadHospitalData = async () => {
    setLoading(true);
    try {
      const [hospRes, reqRes, invRes] = await Promise.all([
        api.getHospitals(),
        api.getRequests(),
        api.getInventory(),
      ]);

      const matched = hospRes.data.find(
        (h) => (currentUser && h.user_id === currentUser.id) || (currentUser && h.email === currentUser.email)
      ) || hospRes.data[0];

      setHospital(matched || null);
      setRequests(reqRes.data.filter((r) => matched && r.hospital_name.toLowerCase().includes(matched.name.toLowerCase().slice(0, 7))));
      setInventory(invRes.inventory);
    } catch (err) {
      console.error('Failed to load hospital dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !hospital) {
    return <div className="max-w-7xl mx-auto p-12 text-center text-xs text-slate-400">Loading Hospital Portal from MySQL...</div>;
  }

  const isVerified = hospital.verification_status === 'Verified';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-[#14243A] to-slate-800 rounded-3xl p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold uppercase tracking-wider border border-blue-400/30">
              <Building2 className="w-3.5 h-3.5" /> Accredited Institution
            </span>
            <span
              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                isVerified ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' : 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
              }`}
            >
              Status: {hospital.verification_status}
            </span>
          </div>

          <h1 className="font-heading font-extrabold text-3xl text-white">
            {hospital.name}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300">
            Reg: <strong className="font-mono text-white">{hospital.registration_number}</strong> • Hospital Code: <strong className="font-mono text-white">{hospital.hospital_code}</strong>
          </p>
        </div>

        <button
          onClick={onOpenQuickRequest}
          className="px-5 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-lg shadow-red-600/30 flex items-center gap-2 cursor-pointer shrink-0 transition-all"
        >
          <AlertTriangle className="w-4 h-4" /> Raise Blood Requisition
        </button>
      </div>

      {!isVerified && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-3">
          <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold">Institutional Account Verification Pending</p>
            <p className="text-slate-700">
              Your hospital account is awaiting formal review by the state blood bank administrator. Requisitions may be submitted, but automated emergency dispatches require verified credentials.
            </p>
          </div>
        </div>
      )}

      {/* Live Blood Group Availability Grid */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="font-heading font-bold text-base text-slate-900">
              Central Blood Bank Live Inventory Reserve
            </h3>
            <p className="text-xs text-slate-500">
              Available units ready for pre-transfusion cross-matching
            </p>
          </div>
          <button
            onClick={() => onNavigate('find-blood')}
            className="text-xs font-bold text-red-600 hover:text-red-700"
          >
            Find Blood Details
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {inventory.slice(0, 8).map((item) => (
            <div
              key={item.blood_group}
              className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-center"
            >
              <span className="font-heading font-extrabold text-base text-red-600 block">
                {item.blood_group}
              </span>
              <span className="text-xl font-extrabold font-heading text-slate-900 block my-1">
                {item.available_units}
              </span>
              <span className="text-[10px] text-slate-400 block font-semibold uppercase">Units Ready</span>
            </div>
          ))}
        </div>
      </div>

      {/* Requisitions Placed By This Hospital */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-heading font-bold text-base text-slate-900">
              Hospital Requisition Tracking (Live MySQL Status)
            </h3>
            <p className="text-xs text-slate-500">
              Active patient requisitions and transit tracking
            </p>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {requests.length} Requests
          </span>
        </div>

        {requests.length === 0 ? (
          <div className="p-10 text-center text-xs text-slate-500 space-y-3">
            <p>No requisitions on record yet for {hospital.name}.</p>
            <button
              onClick={onOpenQuickRequest}
              className="px-4 py-2 bg-red-600 text-white rounded-xl font-bold"
            >
              Submit Emergency Request
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-100">
                <tr>
                  <th className="py-3 px-6">Request Code</th>
                  <th className="py-3 px-6">Patient Name & Ref</th>
                  <th className="py-3 px-6">Blood Group</th>
                  <th className="py-3 px-6">Units</th>
                  <th className="py-3 px-6">Required Date</th>
                  <th className="py-3 px-6">Priority</th>
                  <th className="py-3 px-6">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {requests.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/70">
                    <td className="py-4 px-6 font-mono font-bold text-slate-800">
                      {r.request_code}
                    </td>
                    <td className="py-4 px-6 font-semibold text-slate-900">
                      {r.patient_name}
                      <span className="block text-[11px] text-slate-400 font-normal">{r.patient_ref_id}</span>
                    </td>
                    <td className="py-4 px-6 font-heading font-extrabold text-sm text-red-600">
                      {r.blood_group}
                    </td>
                    <td className="py-4 px-6 font-bold text-slate-800">
                      {r.units_fulfilled} / {r.units_required} Units
                    </td>
                    <td className="py-4 px-6 text-slate-600">{r.required_date}</td>
                    <td className="py-4 px-6 font-bold text-red-600">{r.priority}</td>
                    <td className="py-4 px-6">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          r.status === 'Fulfilled'
                            ? 'bg-emerald-100 text-emerald-800'
                            : r.status === 'Approved'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
