import React, { useState } from 'react';
import { Shield, Heart, Building2, Lock, Mail, ArrowRight, AlertCircle, CheckCircle2, KeyRound } from 'lucide-react';
import { User } from '../types.js';
import { api } from '../api/client.js';

interface LoginPageProps {
  initialRole?: 'admin' | 'donor' | 'hospital';
  onLoginSuccess: (user: User, role: string) => void;
  onNavigate: (page: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  initialRole = 'donor',
  onLoginSuccess,
  onNavigate,
}) => {
  const [activeTab, setActiveTab] = useState<'donor' | 'hospital' | 'admin'>(initialRole);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const setDemoCredentials = (role: 'donor' | 'hospital' | 'admin') => {
    setActiveTab(role);
    if (role === 'admin') {
      setEmail('admin@raufblood.org');
      setPassword('admin123');
    } else if (role === 'donor') {
      setEmail('robert.chen@email.com');
      setPassword('admin123');
    } else if (role === 'hospital') {
      setEmail('stjude@metrohealth.org');
      setPassword('admin123');
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await api.login({
        email,
        password,
        role: activeTab,
      });

      onLoginSuccess(res.user, activeTab);
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
        {/* Header Tabs */}
        <div className="p-6 bg-slate-900 text-white text-center space-y-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Secure MySQL Authentication Portal
          </span>
          <h2 className="font-heading font-extrabold text-2xl text-white">
            {activeTab === 'admin'
              ? 'Admin Master Console'
              : activeTab === 'hospital'
              ? 'Hospital Transfusion Wing'
              : 'Donor Personal Hub'}
          </h2>
          <p className="text-xs text-slate-400">
            Select your access role and provide encrypted credentials.
          </p>

          {/* Role Switcher */}
          <div className="grid grid-cols-3 gap-1 bg-slate-800 p-1 rounded-xl mt-4 text-xs font-semibold">
            <button
              onClick={() => { setActiveTab('donor'); setError(null); }}
              className={`py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'donor' ? 'bg-red-600 text-white shadow-xs font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Heart className="w-3.5 h-3.5" /> Donor
            </button>
            <button
              onClick={() => { setActiveTab('hospital'); setError(null); }}
              className={`py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'hospital' ? 'bg-blue-600 text-white shadow-xs font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" /> Hospital
            </button>
            <button
              onClick={() => { setActiveTab('admin'); setError(null); }}
              className={`py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'admin' ? 'bg-red-800 text-white shadow-xs font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Shield className="w-3.5 h-3.5" /> Admin
            </button>
          </div>
        </div>

        {/* Quick Fill Testing Credentials */}
        <div className="px-6 pt-4 pb-2 bg-slate-50 border-b border-slate-200 text-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1.5">
            <span className="font-semibold text-[11px] flex items-center gap-1">
              <KeyRound className="w-3 h-3 text-red-500" /> Quick Seed Test Fill:
            </span>
            <span className="text-[10px] text-slate-400">Password: admin123</span>
          </div>
          <div className="flex gap-1.5">
            <button
              type="button"
              onClick={() => setDemoCredentials('donor')}
              className="px-2 py-1 bg-white border border-slate-300 rounded text-[11px] font-medium text-slate-700 hover:bg-slate-100"
            >
              Fill Donor
            </button>
            <button
              type="button"
              onClick={() => setDemoCredentials('hospital')}
              className="px-2 py-1 bg-white border border-slate-300 rounded text-[11px] font-medium text-slate-700 hover:bg-slate-100"
            >
              Fill Hospital
            </button>
            <button
              type="button"
              onClick={() => setDemoCredentials('admin')}
              className="px-2 py-1 bg-red-100 border border-red-300 rounded text-[11px] font-bold text-red-800 hover:bg-red-200"
            >
              Fill Admin
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleLogin} className="p-6 space-y-4">
          {error && (
            <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
              <input
                type="email"
                required
                placeholder="your.email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md shadow-red-600/25 flex items-center justify-center gap-2 disabled:opacity-50 transition-all cursor-pointer mt-2"
          >
            {loading ? 'Validating against MySQL...' : `Sign In as ${activeTab.toUpperCase()}`}
            <ArrowRight className="w-4 h-4" />
          </button>

          {/* Links for Registration */}
          <div className="pt-4 border-t border-slate-100 text-center text-xs text-slate-500 space-y-2">
            {activeTab === 'donor' && (
              <p>
                Not registered yet?{' '}
                <button
                  type="button"
                  onClick={() => onNavigate('register-donor')}
                  className="font-bold text-red-600 hover:underline"
                >
                  Create voluntary donor profile
                </button>
              </p>
            )}
            {activeTab === 'hospital' && (
              <p>
                Need hospital accreditation?{' '}
                <button
                  type="button"
                  onClick={() => onNavigate('register-hospital')}
                  className="font-bold text-blue-600 hover:underline"
                >
                  Submit institutional application
                </button>
              </p>
            )}
            {activeTab === 'admin' && (
              <p className="text-[11px] text-slate-400">
                Notice: Admin access requires pre-authorized credentials configured in database.sql. Public sign-up is disabled for security.
              </p>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
