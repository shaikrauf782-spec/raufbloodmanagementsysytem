import React, { useState, useEffect } from 'react';
import {
  Calendar,
  PlusCircle,
  CheckCircle2,
  Heart,
  Droplet,
  Award,
  Search,
  X,
  Activity,
  FileCheck,
} from 'lucide-react';
import { BloodGroup, Donation, Donor } from '../types.js';
import { api } from '../api/client.js';

interface DonationsPageProps {
  onNavigate: (page: string) => void;
}

export const DonationsPage: React.FC<DonationsPageProps> = ({ onNavigate }) => {
  const [donations, setDonations] = useState<Donation[]>([]);
  const [donors, setDonors] = useState<Donor[]>([]);
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<string | null>(null);

  // New Donation Modal
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    donor_id: 1,
    blood_group: 'O+' as BloodGroup,
    component_type: 'Whole Blood',
    units_donated: 1,
    hemoglobin_level: 14.5,
    blood_pressure: '120/80',
    pulse_rate: 72,
    nurse_or_phlebotomist: 'Nurse Lisa Ray',
    remarks: 'Smooth collection. Normal recovery.',
  });

  useEffect(() => {
    loadDonations();
  }, []);

  const loadDonations = async () => {
    setLoading(true);
    try {
      const [donRes, donorRes] = await Promise.all([
        api.getDonations(),
        api.getDonors(),
      ]);
      setDonations(donRes.data);
      setDonors(donorRes.data);
      if (donorRes.data.length > 0) {
        setFormData((prev) => ({
          ...prev,
          donor_id: donorRes.data[0].id,
          blood_group: donorRes.data[0].blood_group,
        }));
      }
    } catch (err) {
      console.error('Failed to load donations:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDonorSelect = (id: number) => {
    const d = donors.find((dn) => dn.id === id);
    if (d) {
      setFormData({
        ...formData,
        donor_id: id,
        blood_group: d.blood_group,
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await api.recordDonation(formData);
      setFeedback(`Donation ${res.donation.donation_code} recorded into MySQL! Inventory automatically restocked with ${formData.units_donated} unit(s) of ${formData.blood_group}.`);
      setShowModal(false);
      loadDonations();
      setTimeout(() => setFeedback(null), 4000);
    } catch (err: any) {
      alert(err.message || 'Failed to record donation');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-red-600">
            Certified Blood Collection Registry
          </span>
          <h1 className="font-heading font-extrabold text-3xl text-[#14243A]">
            Donation Management
          </h1>
          <p className="text-xs text-slate-500">
            Log completed donor visits, track vitals, issue certificates, and automatically increase stock in MySQL.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-5 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md shadow-red-600/25 flex items-center gap-2 cursor-pointer transition-all"
        >
          <PlusCircle className="w-4 h-4" /> Record Completed Donation
        </button>
      </div>

      {feedback && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-medium flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Donations Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-heading font-bold text-base text-slate-900">
              Completed Blood Donations (blood_bank.donations)
            </h3>
            <p className="text-xs text-slate-500">
              Showing official certified donation sessions logged by phlebotomy staff
            </p>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {donations.length} Sessions Logged
          </span>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">Loading donation sessions from MySQL...</div>
        ) : donations.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-500">
            No donation records logged yet.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-100">
                <tr>
                  <th className="py-3 px-6">Donation Code</th>
                  <th className="py-3 px-6">Donor ID & Details</th>
                  <th className="py-3 px-6">Blood Type</th>
                  <th className="py-3 px-6">Units Collected</th>
                  <th className="py-3 px-6">Date</th>
                  <th className="py-3 px-6">Screening Vitals (Hb / BP)</th>
                  <th className="py-3 px-6">Phlebotomist</th>
                  <th className="py-3 px-6">Status & Certificate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {donations.map((don) => {
                  const donor = donors.find((d) => d.id === don.donor_id);
                  return (
                    <tr key={don.id} className="hover:bg-slate-50/70">
                      <td className="py-4 px-6 font-mono font-bold text-slate-800">
                        {don.donation_code}
                      </td>
                      <td className="py-4 px-6">
                        <span className="font-bold text-slate-900 block">
                          {donor ? donor.full_name : `Donor #${don.donor_id}`}
                        </span>
                        <span className="text-[11px] text-slate-400 block font-mono">
                          {donor ? donor.donor_code : ''}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <span className="font-heading font-extrabold text-sm text-red-600 bg-red-50 px-2 py-0.5 rounded border border-red-100">
                          {don.blood_group}
                        </span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">{don.component_type}</span>
                      </td>
                      <td className="py-4 px-6 font-bold text-slate-800">
                        {don.units_donated} Unit (450 mL)
                      </td>
                      <td className="py-4 px-6 text-slate-600">
                        {don.donation_date}
                      </td>
                      <td className="py-4 px-6 text-slate-700">
                        <span className="font-semibold block">{don.hemoglobin_level} g/dL Hb</span>
                        <span className="text-[11px] text-slate-500 font-mono block">BP: {don.blood_pressure} • {don.pulse_rate} bpm</span>
                      </td>
                      <td className="py-4 px-6 text-slate-600">
                        {don.nurse_or_phlebotomist}
                      </td>
                      <td className="py-4 px-6">
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                          <Award className="w-3.5 h-3.5 text-emerald-600" />
                          Certificate Issued
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Record Donation Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-heading font-bold text-base text-slate-900">
                Record Blood Donation & Auto-Restock
              </h3>
              <button onClick={() => setShowModal(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Select Registered Donor *</label>
                <select
                  value={formData.donor_id}
                  onChange={(e) => handleDonorSelect(Number(e.target.value))}
                  className="w-full p-2.5 rounded-lg border border-slate-300 font-medium focus:outline-none focus:border-red-500"
                >
                  {donors.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.full_name} ({d.donor_code} • {d.blood_group})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Blood Group</label>
                  <input
                    type="text"
                    disabled
                    value={formData.blood_group}
                    className="w-full p-2.5 rounded-lg border border-slate-200 bg-slate-50 font-bold text-red-600 font-heading"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Units Donated</label>
                  <input
                    type="number"
                    min="1"
                    max="2"
                    required
                    value={formData.units_donated}
                    onChange={(e) => setFormData({ ...formData, units_donated: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-lg border border-slate-300 font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Hemoglobin (g/dL)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="12.5"
                    max="20.0"
                    required
                    value={formData.hemoglobin_level}
                    onChange={(e) => setFormData({ ...formData, hemoglobin_level: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-lg border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Blood Pressure</label>
                  <input
                    type="text"
                    required
                    placeholder="120/80"
                    value={formData.blood_pressure}
                    onChange={(e) => setFormData({ ...formData, blood_pressure: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-slate-300 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Attending Phlebotomist / Nurse</label>
                <input
                  type="text"
                  required
                  value={formData.nurse_or_phlebotomist}
                  onChange={(e) => setFormData({ ...formData, nurse_or_phlebotomist: e.target.value })}
                  className="w-full p-2.5 rounded-lg border border-slate-300"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Session Remarks</label>
                <input
                  type="text"
                  value={formData.remarks}
                  onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                  className="w-full p-2.5 rounded-lg border border-slate-300"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700"
                >
                  Confirm & Restock MySQL
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
