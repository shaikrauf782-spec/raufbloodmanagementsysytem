import React, { useState } from 'react';
import { Building2, ShieldAlert, CheckCircle2, AlertCircle, FileText, Lock } from 'lucide-react';
import { api } from '../api/client.js';

interface HospitalRegistrationPageProps {
  onNavigate: (page: string) => void;
  onRegistered: () => void;
}

export const HospitalRegistrationPage: React.FC<HospitalRegistrationPageProps> = ({
  onNavigate,
  onRegistered,
}) => {
  const [formData, setFormData] = useState({
    name: '',
    registration_number: '',
    contact_person: '',
    designation: 'Chief of Blood Transfusion',
    phone: '',
    emergency_phone: '',
    email: '',
    password: '',
    confirm_password: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successCode, setSuccessCode] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (formData.password !== formData.confirm_password) {
      setError('Passwords do not match. Please verify.');
      return;
    }

    setLoading(true);

    try {
      const res = await api.registerHospital(formData);
      setSuccessCode(res.hospital.hospital_code);
      setTimeout(() => {
        onRegistered();
      }, 3500);
    } catch (err: any) {
      setError(err.message || 'Hospital registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
        {/* Header Banner */}
        <div className="p-8 bg-gradient-to-r from-[#14243A] to-slate-800 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold uppercase tracking-wider border border-blue-400/30">
              <Building2 className="w-3.5 h-3.5" /> Institutional Accreditation
            </span>
            <h1 className="font-heading font-extrabold text-2xl sm:text-3xl text-white">
              Hospital & Trauma Center Registration
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Register your healthcare facility for direct blood bank requisition rights. Accounts undergo administrator validation before blood dispatch authorization.
            </p>
          </div>
          <button
            onClick={() => onNavigate('login-hospital')}
            className="px-4 py-2 bg-white text-slate-900 text-xs font-bold rounded-xl hover:bg-slate-100 transition-colors shrink-0"
          >
            Hospital Sign In
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {error && (
            <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successCode && (
            <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-2 animate-in fade-in">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                <h3 className="font-heading font-bold text-base">Institution Registered (Status: Pending Verification)</h3>
              </div>
              <p className="text-xs text-slate-700">
                Hospital Code: <strong className="font-mono text-blue-700 text-sm">{successCode}</strong>.
                Per healthcare compliance rules, your registration is stored in MySQL and queued for administrator verification.
              </p>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Hospital / Clinic Official Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Metro Heart & Trauma Institute"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">State Medical License / Reg Number *</label>
              <input
                type="text"
                required
                placeholder="e.g. REG-HOSP-NY-8452"
                value={formData.registration_number}
                onChange={(e) => setFormData({ ...formData, registration_number: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nodal Contact Person *</label>
              <input
                type="text"
                required
                placeholder="e.g. Dr. Arthur Sterling"
                value={formData.contact_person}
                onChange={(e) => setFormData({ ...formData, contact_person: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Designation</label>
              <input
                type="text"
                value={formData.designation}
                onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Official Board Line Phone *</label>
              <input
                type="tel"
                required
                placeholder="+1 (555) 000-0000"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">24/7 Transfusion Emergency Phone *</label>
              <input
                type="tel"
                required
                placeholder="+1 (555) 000-0911"
                value={formData.emergency_phone}
                onChange={(e) => setFormData({ ...formData, emergency_phone: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-500 font-bold text-red-600"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">Official Hospital Email Address *</label>
              <input
                type="email"
                required
                placeholder="transfusion@metrohealth.org"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">City *</label>
              <input
                type="text"
                required
                placeholder="Metro City"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">State *</label>
              <input
                type="text"
                required
                placeholder="State"
                value={formData.state}
                onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">Physical Address *</label>
              <input
                type="text"
                required
                placeholder="Medical campus road, building, block"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Portal Password *</label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Confirm Password *</label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={formData.confirm_password}
                onChange={(e) => setFormData({ ...formData, confirm_password: e.target.value })}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="pt-4 flex items-center justify-between border-t border-slate-100">
            <span className="text-xs text-slate-400">
              Accounts are cross-verified with state healthcare regulatory boards.
            </span>
            <button
              type="submit"
              disabled={loading}
              className="px-8 py-3.5 rounded-xl bg-[#14243A] hover:bg-slate-800 text-white font-bold text-xs shadow-md transition-all cursor-pointer"
            >
              {loading ? 'Submitting...' : 'Register Hospital'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
