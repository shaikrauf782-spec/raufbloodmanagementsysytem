import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle2, Building2 } from 'lucide-react';

interface ContactPageProps {
  onNavigate: (page: string) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ onNavigate }) => {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'Blood Donation Camp Inquiry',
    message: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to submit inquiry');
      setSubmitted(true);
      setFormData({ name: '', email: '', phone: '', subject: 'Blood Donation Camp Inquiry', message: '' });
      setTimeout(() => setSubmitted(false), 5000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-red-600 bg-red-50 px-3 py-1 rounded-full border border-red-200">
          24/7 Operations & Helplines
        </span>
        <h1 className="font-heading font-extrabold text-3xl sm:text-4xl text-[#14243A]">
          Contact Rauf Blood Management Centers
        </h1>
        <p className="text-xs sm:text-sm text-slate-500">
          Reach our transfusion desk, organize a corporate or college blood donation camp, or inquire about emergency shipments.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Contact Information & Centers */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#14243A] text-white rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            <h3 className="font-heading font-bold text-lg text-white">
              Transfusion Control Headquarters
            </h3>

            <div className="space-y-4 text-xs">
              <div className="flex items-start gap-3.5">
                <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center shrink-0">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">
                    Emergency Dispatch (24/7)
                  </span>
                  <span className="text-sm font-bold text-white block">+1 (555) 019-2834</span>
                  <span className="text-[11px] text-slate-400">Toll-Free: 1-800-LIFE-DROP</span>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-8 h-8 rounded-lg bg-slate-800 text-slate-300 flex items-center justify-center shrink-0">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">
                    Official Inquiries & Camps
                  </span>
                  <span className="text-sm font-medium text-white block">transfusion@lifedrop.org</span>
                  <span className="text-[11px] text-slate-400">admin@lifedrop.org</span>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-8 h-8 rounded-lg bg-slate-800 text-slate-300 flex items-center justify-center shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">
                    Central Blood Bank Facility
                  </span>
                  <span className="text-xs text-white block">
                    742 Evergreen Healthcare Blvd, Suite 100, Metro City, 10001
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-8 h-8 rounded-lg bg-slate-800 text-slate-300 flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">
                    Donor Walk-In Hours
                  </span>
                  <span className="text-xs text-white block">
                    Mon - Sun: 08:00 AM – 08:00 PM (Emergency Desk 24/7)
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-3 text-xs">
            <h4 className="font-heading font-bold text-sm text-slate-900">Regional Blood Bank Stations</h4>
            <div className="p-3 bg-slate-50 rounded-xl space-y-1">
              <span className="font-bold text-slate-800 block">North Valley Regional Center</span>
              <span className="text-slate-500 block">124 North Valley Medical Campus • Phone: +1 (555) 100-3000</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl space-y-1">
              <span className="font-bold text-slate-800 block">South Bay Trauma Transfusion Depot</span>
              <span className="text-slate-500 block">89 Harbor Medical Way, Bay 3 • Phone: +1 (555) 100-4000</span>
            </div>
          </div>
        </div>

        {/* Contact / Inquiry Form */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
          <h3 className="font-heading font-bold text-lg text-slate-900 mb-2">
            Send an Inquiry or Book a Corporate Blood Drive
          </h3>
          <p className="text-xs text-slate-500 mb-6">
            Our medical coordination staff will respond within 2 hours.
          </p>

          {submitted && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-medium flex items-center gap-2 mb-6">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>Thank you! Your message has been saved in the MySQL database and our team will contact you shortly.</span>
            </div>
          )}

          {error && (
            <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-900 text-xs font-medium flex items-center gap-2 mb-6">
              <span>Error: {error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Your Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="Dr. Arthur Sterling"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Your Email Address *</label>
                <input
                  type="email"
                  required
                  placeholder="arthur@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Phone Number</label>
                <input
                  type="tel"
                  placeholder="+1 555-019-2834"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Subject</label>
                <select
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full p-3 rounded-xl border border-slate-300 font-medium focus:outline-none focus:border-red-500"
                >
                  <option value="Blood Donation Camp Inquiry">Organize a Blood Donation Camp</option>
                  <option value="Hospital Blood Requisition Help">Hospital Transfusion Requisition Inquiry</option>
                  <option value="Voluntary Donor Question">Voluntary Donor Eligibility Question</option>
                  <option value="General Question">General Healthcare Inquiry</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Message *</label>
              <textarea
                required
                rows={4}
                placeholder="Describe your organization, estimated donor count, or hospital requirements..."
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                className="w-full p-3 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
              />
            </div>

            <button
              type="submit"
              className="px-6 py-3.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-md shadow-red-600/30 flex items-center gap-2 cursor-pointer transition-all"
            >
              <Send className="w-4 h-4" /> Send Inquiry
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
