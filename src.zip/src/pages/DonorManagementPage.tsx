import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Filter,
  PlusCircle,
  Edit3,
  Trash2,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Eye,
  X,
  Phone,
  Mail,
  MapPin,
  Heart,
} from 'lucide-react';
import { BloodGroup, Donor } from '../types.js';
import { api } from '../api/client.js';

interface DonorManagementPageProps {
  onNavigate: (page: string) => void;
}

export const DonorManagementPage: React.FC<DonorManagementPageProps> = ({ onNavigate }) => {
  const [donors, setDonors] = useState<Donor[]>([]);
  const [search, setSearch] = useState('');
  const [bloodGroupFilter, setBloodGroupFilter] = useState('All');
  const [eligibilityFilter, setEligibilityFilter] = useState('All');
  const [loading, setLoading] = useState(true);

  // Edit Modal State
  const [editingDonor, setEditingDonor] = useState<Donor | null>(null);
  const [viewingDonor, setViewingDonor] = useState<Donor | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    loadDonors();
  }, [bloodGroupFilter, eligibilityFilter]);

  const loadDonors = async () => {
    setLoading(true);
    try {
      const res = await api.getDonors({
        blood_group: bloodGroupFilter !== 'All' ? bloodGroupFilter : undefined,
        eligibility: eligibilityFilter !== 'All' ? eligibilityFilter : undefined,
        search: search || undefined,
      });
      setDonors(res.data);
    } catch (err) {
      console.error('Failed to load donors:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadDonors();
  };

  const handleDelete = async (id: number, name: string) => {
    if (!confirm(`Are you sure you want to deactivate/delete donor ${name}?`)) return;
    try {
      await api.deleteDonor(id);
      setFeedback(`Donor ${name} record removed / deactivated from database.`);
      loadDonors();
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDonor) return;
    try {
      await api.updateDonor(editingDonor.id, editingDonor);
      setFeedback(`Donor ${editingDonor.full_name} updated successfully in MySQL!`);
      setEditingDonor(null);
      loadDonors();
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const bloodGroups: Array<'All' | BloodGroup> = ['All', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-red-600">
            Registered Voluntary Life Savers
          </span>
          <h1 className="font-heading font-extrabold text-3xl text-[#14243A]">
            Donor Management
          </h1>
          <p className="text-xs text-slate-500">
            Search, filter, view donation history, and update medical eligibility records.
          </p>
        </div>

        <button
          onClick={() => onNavigate('register-donor')}
          className="px-5 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md shadow-red-600/25 flex items-center gap-2 cursor-pointer transition-all"
        >
          <PlusCircle className="w-4 h-4" /> Register New Donor
        </button>
      </div>

      {feedback && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-medium flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <form onSubmit={handleSearchSubmit} className="flex flex-col md:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              placeholder="Search donors by name, donor code, phone, or city..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full text-xs pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:border-red-500"
            />
          </div>

          <button
            type="submit"
            className="w-full md:w-auto px-5 py-2.5 rounded-xl bg-[#14243A] text-white font-bold text-xs hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Search MySQL Records
          </button>
        </form>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-bold uppercase text-slate-400 mr-1">
              Group:
            </span>
            {bloodGroups.map((bg) => (
              <button
                key={bg}
                onClick={() => setBloodGroupFilter(bg)}
                className={`px-3 py-1 text-[11px] font-bold rounded-lg transition-colors cursor-pointer ${
                  bloodGroupFilter === bg
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {bg}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold uppercase text-slate-400">Eligibility:</span>
            <select
              value={eligibilityFilter}
              onChange={(e) => setEligibilityFilter(e.target.value)}
              className="text-xs p-1.5 rounded-lg border border-slate-300 font-medium focus:outline-none focus:border-red-500"
            >
              <option value="All">All Statuses</option>
              <option value="Eligible">Eligible</option>
              <option value="Temporarily Ineligible">Temporarily Ineligible</option>
              <option value="Under Review">Under Review</option>
            </select>
          </div>
        </div>
      </div>

      {/* Donors List Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-heading font-bold text-base text-slate-900">
              Donor Directory & Medical Vitals
            </h3>
            <p className="text-xs text-slate-500">
              Showing {donors.length} registered donors stored in blood_bank.donors table
            </p>
          </div>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">Querying donors from database...</div>
        ) : donors.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-500">
            No donors found matching criteria. Try resetting filters.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-100">
                <tr>
                  <th className="py-3 px-6">Donor Code</th>
                  <th className="py-3 px-6">Full Name & Gender</th>
                  <th className="py-3 px-6">Blood Group</th>
                  <th className="py-3 px-6">Contact & City</th>
                  <th className="py-3 px-6">Last Donation</th>
                  <th className="py-3 px-6">Total Units</th>
                  <th className="py-3 px-6">Eligibility</th>
                  <th className="py-3 px-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {donors.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50/70">
                    <td className="py-4 px-6 font-mono font-bold text-slate-700">
                      {d.donor_code}
                    </td>
                    <td className="py-4 px-6">
                      <span className="font-bold text-slate-900 block">{d.full_name}</span>
                      <span className="text-[11px] text-slate-400 block">{d.gender} • DOB: {d.dob}</span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="font-heading font-extrabold text-sm text-red-600 bg-red-50 px-2 py-0.5 rounded border border-red-100">
                        {d.blood_group}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-slate-800 block">{d.phone}</span>
                      <span className="text-[11px] text-slate-500 block">{d.city}, {d.state}</span>
                    </td>
                    <td className="py-4 px-6 text-slate-600">
                      {d.last_donation_date || 'Never donated'}
                    </td>
                    <td className="py-4 px-6 font-bold text-slate-900">
                      {d.total_donations_count} Bags
                    </td>
                    <td className="py-4 px-6">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          d.eligibility_status === 'Eligible'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {d.eligibility_status}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-right space-x-1.5">
                      <button
                        onClick={() => setViewingDonor(d)}
                        title="View Full Profile"
                        className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setEditingDonor(d)}
                        title="Edit Donor Record"
                        className="p-1.5 rounded-lg text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition-colors cursor-pointer"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(d.id, d.full_name)}
                        title="Delete Donor"
                        className="p-1.5 rounded-lg text-red-600 hover:text-red-800 hover:bg-red-50 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit Donor Modal */}
      {editingDonor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-heading font-bold text-base text-slate-900">
                Edit Donor Profile ({editingDonor.donor_code})
              </h3>
              <button onClick={() => setEditingDonor(null)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={editingDonor.full_name}
                  onChange={(e) => setEditingDonor({ ...editingDonor, full_name: e.target.value })}
                  className="w-full p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={editingDonor.phone}
                    onChange={(e) => setEditingDonor({ ...editingDonor, phone: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    value={editingDonor.weight_kg}
                    onChange={(e) => setEditingDonor({ ...editingDonor, weight_kg: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">City</label>
                  <input
                    type="text"
                    value={editingDonor.city}
                    onChange={(e) => setEditingDonor({ ...editingDonor, city: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Eligibility Status</label>
                  <select
                    value={editingDonor.eligibility_status}
                    onChange={(e) => setEditingDonor({ ...editingDonor, eligibility_status: e.target.value as any })}
                    className="w-full p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
                  >
                    <option value="Eligible">Eligible</option>
                    <option value="Temporarily Ineligible">Temporarily Ineligible</option>
                    <option value="Permanently Ineligible">Permanently Ineligible</option>
                    <option value="Under Review">Under Review</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Medical Assessment Notes</label>
                <textarea
                  rows={3}
                  value={editingDonor.medical_notes || ''}
                  onChange={(e) => setEditingDonor({ ...editingDonor, medical_notes: e.target.value })}
                  className="w-full p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingDonor(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700"
                >
                  Save Changes to MySQL
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Donor Profile Modal */}
      {viewingDonor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center font-bold text-base font-heading">
                  {viewingDonor.blood_group}
                </div>
                <div>
                  <h3 className="font-heading font-bold text-base text-slate-900">{viewingDonor.full_name}</h3>
                  <span className="font-mono text-slate-400">{viewingDonor.donor_code}</span>
                </div>
              </div>
              <button onClick={() => setViewingDonor(null)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-slate-700">
              <p><strong>Phone:</strong> {viewingDonor.phone}</p>
              <p><strong>Email:</strong> {viewingDonor.email}</p>
              <p><strong>Date of Birth:</strong> {viewingDonor.dob} ({viewingDonor.gender})</p>
              <p><strong>Weight:</strong> {viewingDonor.weight_kg} kg</p>
              <p><strong>Address:</strong> {viewingDonor.address}, {viewingDonor.city}, {viewingDonor.state} - {viewingDonor.pincode}</p>
              <p><strong>Total Lifetime Donations:</strong> {viewingDonor.total_donations_count} Units</p>
              <p><strong>Last Donated:</strong> {viewingDonor.last_donation_date || 'N/A'}</p>
              <p><strong>Emergency Contact:</strong> {viewingDonor.emergency_contact_name || 'None'} ({viewingDonor.emergency_contact_phone || 'None'})</p>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <strong>Medical Notes:</strong>
                <p className="mt-1 text-slate-600">{viewingDonor.medical_notes || 'No specific clinical flags recorded.'}</p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 text-right">
              <button
                onClick={() => setViewingDonor(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-lg font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
