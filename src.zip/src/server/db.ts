import mysql, { Pool, PoolConnection } from 'mysql2/promise';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';

dotenv.config();

export interface DbStatus {
  connected: boolean;
  host: string;
  port: number;
  user: string;
  database: string;
  errorMessage?: string;
  errorCode?: string;
  lastChecked: string;
  activeStorage: 'mysql' | 'memory-mirror';
  poolStats?: {
    activeConnections: number;
  };
}

let pool: Pool | null = null;
let lastDbStatus: DbStatus = {
  connected: false,
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'root',
  database: process.env.DB_NAME || 'blood_bank_db',
  errorMessage: 'Connection not attempted yet',
  lastChecked: new Date().toISOString(),
  activeStorage: 'mysql',
};

// Seed datasets matching database.sql
export interface UserRecord {
  id: number;
  email: string;
  password_hash: string;
  role: 'admin' | 'donor' | 'hospital' | 'staff';
  name: string;
  phone: string;
  is_active: number;
  is_verified: number;
  created_at: string;
}

export interface DonorRecord {
  id: number;
  user_id?: number | null;
  donor_code: string;
  full_name: string;
  dob: string;
  gender: 'Male' | 'Female' | 'Other';
  blood_group: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  phone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  weight_kg: number;
  last_donation_date?: string | null;
  eligibility_status: 'Eligible' | 'Temporarily Ineligible' | 'Permanently Ineligible' | 'Under Review';
  medical_notes?: string;
  emergency_contact_name?: string;
  emergency_contact_phone?: string;
  total_donations_count: number;
  created_at: string;
}

export interface HospitalRecord {
  id: number;
  user_id?: number | null;
  hospital_code: string;
  name: string;
  registration_number: string;
  contact_person: string;
  designation?: string;
  phone: string;
  emergency_phone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  verification_status: 'Pending' | 'Verified' | 'Rejected';
  verified_by_user_id?: number | null;
  verified_at?: string | null;
  rejection_reason?: string | null;
  created_at: string;
}

export interface BloodStockRecord {
  id: number;
  blood_bank_id: number;
  blood_group: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  component_type: string;
  available_units: number;
  reserved_units: number;
  low_stock_threshold: number;
  critical_threshold: number;
  last_restocked_at: string;
}

export interface BloodUnitRecord {
  id: number;
  unit_id: string;
  blood_bank_id: number;
  donor_id?: number | null;
  blood_group: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  component_type: string;
  volume_ml: number;
  collection_date: string;
  expiry_date: string;
  storage_location: string;
  testing_status: 'Tested - Safe' | 'Pending Testing' | 'Reactive - Quarantined';
  unit_status: 'Available' | 'Reserved' | 'Issued' | 'Discarded - Expired' | 'Discarded - Contaminated';
  issued_to_hospital_id?: number | null;
  created_at: string;
}

export interface BloodRequestRecord {
  id: number;
  request_code: string;
  hospital_id?: number | null;
  patient_name: string;
  patient_ref_id: string;
  hospital_name: string;
  blood_group: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  component_type: string;
  units_required: number;
  units_fulfilled: number;
  required_date: string;
  priority: 'Standard' | 'Urgent' | 'Emergency - Critical';
  status: 'Pending' | 'Approved' | 'Partially Fulfilled' | 'Fulfilled' | 'Rejected' | 'Cancelled';
  contact_number: string;
  doctor_name?: string;
  diagnosis_reason?: string;
  additional_notes?: string;
  approved_by_user_id?: number | null;
  approved_at?: string | null;
  fulfilled_at?: string | null;
  rejection_reason?: string | null;
  created_at: string;
}

export interface DonationRecord {
  id: number;
  donation_code: string;
  donor_id: number;
  blood_bank_id: number;
  donation_date: string;
  blood_group: string;
  component_type: string;
  units_donated: number;
  hemoglobin_level: number;
  blood_pressure: string;
  pulse_rate: number;
  donation_status: 'Completed' | 'Screening Failed' | 'Adverse Reaction' | 'Cancelled';
  nurse_or_phlebotomist: string;
  remarks?: string;
  certificate_issued: number;
  created_at: string;
}

export interface AuditLogRecord {
  id: number;
  user_id?: number | null;
  action: string;
  entity_type: string;
  entity_id?: number | null;
  details?: string;
  ip_address?: string;
  created_at: string;
}

// In-Memory store mirror so the app never shows a blank white page if MySQL is local to user's computer
export const memoryStore = {
  users: [
    {
      id: 1,
      email: 'admin@lifedrop.org',
      password_hash: '$2a$10$iJ7zD6Q/mO.vS5Kk.01t8OCQ5ZkHqSgHlT4c605oG7rJz0F672Qum', // admin123
      role: 'admin',
      name: 'Dr. Sarah Mitchell',
      phone: '+1 (555) 019-2834',
      is_active: 1,
      is_verified: 1,
      created_at: new Date().toISOString(),
    },
    {
      id: 2,
      email: 'robert.chen@email.com',
      password_hash: '$2a$10$iJ7zD6Q/mO.vS5Kk.01t8OCQ5ZkHqSgHlT4c605oG7rJz0F672Qum', // donor123
      role: 'donor',
      name: 'Robert Chen',
      phone: '+1 (555) 234-5678',
      is_active: 1,
      is_verified: 1,
      created_at: new Date().toISOString(),
    },
    {
      id: 3,
      email: 'anita.patel@email.com',
      password_hash: '$2a$10$iJ7zD6Q/mO.vS5Kk.01t8OCQ5ZkHqSgHlT4c605oG7rJz0F672Qum',
      role: 'donor',
      name: 'Anita Patel',
      phone: '+1 (555) 345-6789',
      is_active: 1,
      is_verified: 1,
      created_at: new Date().toISOString(),
    },
    {
      id: 4,
      email: 'stjude@metrohealth.org',
      password_hash: '$2a$10$iJ7zD6Q/mO.vS5Kk.01t8OCQ5ZkHqSgHlT4c605oG7rJz0F672Qum', // hosp123
      role: 'hospital',
      name: 'St. Jude General Hospital',
      phone: '+1 (555) 987-6543',
      is_active: 1,
      is_verified: 1,
      created_at: new Date().toISOString(),
    },
    {
      id: 5,
      email: 'apex.trauma@apexhealth.net',
      password_hash: '$2a$10$iJ7zD6Q/mO.vS5Kk.01t8OCQ5ZkHqSgHlT4c605oG7rJz0F672Qum',
      role: 'hospital',
      name: 'Apex Trauma & Multispecialty',
      phone: '+1 (555) 876-5432',
      is_active: 1,
      is_verified: 1,
      created_at: new Date().toISOString(),
    },
  ] as UserRecord[],

  donors: [
    {
      id: 1,
      user_id: 2,
      donor_code: 'DON-2024-001',
      full_name: 'Robert Chen',
      dob: '1992-05-14',
      gender: 'Male',
      blood_group: 'O+',
      phone: '+1 (555) 234-5678',
      email: 'robert.chen@email.com',
      address: '452 Pinecrest Ave',
      city: 'Metro City',
      state: 'State',
      pincode: '10002',
      weight_kg: 74.5,
      last_donation_date: '2026-08-10',
      eligibility_status: 'Eligible',
      medical_notes: 'Regular universal donor. Excellent vitals.',
      emergency_contact_name: 'Lisa Chen',
      emergency_contact_phone: '+1 (555) 234-5679',
      total_donations_count: 8,
      created_at: '2026-01-10T10:00:00Z',
    },
    {
      id: 2,
      user_id: 3,
      donor_code: 'DON-2024-002',
      full_name: 'Anita Patel',
      dob: '1995-11-22',
      gender: 'Female',
      blood_group: 'A+',
      phone: '+1 (555) 345-6789',
      email: 'anita.patel@email.com',
      address: '88 Maple Grove Lane',
      city: 'Metro City',
      state: 'State',
      pincode: '10005',
      weight_kg: 61.0,
      last_donation_date: '2026-09-02',
      eligibility_status: 'Eligible',
      medical_notes: 'Verified donor. Platelet apheresis eligible.',
      emergency_contact_name: 'Dev Patel',
      emergency_contact_phone: '+1 (555) 345-6780',
      total_donations_count: 5,
      created_at: '2026-02-14T11:30:00Z',
    },
    {
      id: 3,
      user_id: null,
      donor_code: 'DON-2024-003',
      full_name: 'Marcus Vance',
      dob: '1988-03-30',
      gender: 'Male',
      blood_group: 'B-',
      phone: '+1 (555) 456-7890',
      email: 'marcus.vance@email.com',
      address: '312 Oakwood Heights',
      city: 'North Valley',
      state: 'State',
      pincode: '10046',
      weight_kg: 82.0,
      last_donation_date: '2026-10-12',
      eligibility_status: 'Eligible',
      medical_notes: 'Rare negative group donor. Priority notified.',
      emergency_contact_name: 'Sarah Vance',
      emergency_contact_phone: '+1 (555) 456-7891',
      total_donations_count: 12,
      created_at: '2026-03-05T09:15:00Z',
    },
    {
      id: 4,
      user_id: null,
      donor_code: 'DON-2024-004',
      full_name: 'Elena Rostova',
      dob: '1996-07-19',
      gender: 'Female',
      blood_group: 'AB+',
      phone: '+1 (555) 567-8901',
      email: 'elena.rostova@sample.org',
      address: '19 Riverview Terrace',
      city: 'Metro City',
      state: 'State',
      pincode: '10009',
      weight_kg: 58.0,
      last_donation_date: '2026-06-25',
      eligibility_status: 'Eligible',
      medical_notes: 'Universal plasma donor.',
      emergency_contact_name: 'Boris Rostov',
      emergency_contact_phone: '+1 (555) 567-8902',
      total_donations_count: 4,
      created_at: '2026-04-12T14:20:00Z',
    },
    {
      id: 5,
      user_id: null,
      donor_code: 'DON-2024-005',
      full_name: 'David Kim',
      dob: '1990-12-05',
      gender: 'Male',
      blood_group: 'O-',
      phone: '+1 (555) 678-9012',
      email: 'david.kim@sample.org',
      address: '702 Horizon Blvd',
      city: 'North Valley',
      state: 'State',
      pincode: '10048',
      weight_kg: 76.0,
      last_donation_date: '2026-07-15',
      eligibility_status: 'Eligible',
      medical_notes: 'Universal red cell emergency donor.',
      emergency_contact_name: 'Grace Kim',
      emergency_contact_phone: '+1 (555) 678-9013',
      total_donations_count: 14,
      created_at: '2026-05-20T16:45:00Z',
    },
  ] as DonorRecord[],

  hospitals: [
    {
      id: 1,
      user_id: 4,
      hospital_code: 'HOSP-2024-001',
      name: 'St. Jude General Hospital',
      registration_number: 'REG-HOSP-NY-9021',
      contact_person: 'Dr. Evelyn Howard',
      designation: 'Chief Medical Officer',
      phone: '+1 (555) 987-6543',
      emergency_phone: '+1 (555) 987-0911',
      email: 'stjude@metrohealth.org',
      address: '500 Health Sciences Way',
      city: 'Metro City',
      state: 'State',
      pincode: '10003',
      verification_status: 'Verified',
      verified_by_user_id: 1,
      verified_at: '2026-01-05T08:00:00Z',
      created_at: '2026-01-02T10:00:00Z',
    },
    {
      id: 2,
      user_id: 5,
      hospital_code: 'HOSP-2024-002',
      name: 'Apex Trauma & Multispecialty',
      registration_number: 'REG-HOSP-NY-8452',
      contact_person: 'Dr. James Thorne',
      designation: 'Director of Critical Care',
      phone: '+1 (555) 876-5432',
      emergency_phone: '+1 (555) 876-0911',
      email: 'apex.trauma@apexhealth.net',
      address: '1200 Emergency Corridor',
      city: 'Metro City',
      state: 'State',
      pincode: '10004',
      verification_status: 'Verified',
      verified_by_user_id: 1,
      verified_at: '2026-02-10T09:30:00Z',
      created_at: '2026-02-08T11:00:00Z',
    },
    {
      id: 3,
      user_id: null,
      hospital_code: 'HOSP-2024-003',
      name: 'City Care Memorial Hospital',
      registration_number: 'REG-HOSP-NY-7721',
      contact_person: 'Carla Cruz',
      designation: 'Head of Transfusion',
      phone: '+1 (555) 765-4321',
      emergency_phone: '+1 (555) 765-0911',
      email: 'citycare@healthnet.org',
      address: '321 Civic Center Dr',
      city: 'North Valley',
      state: 'State',
      pincode: '10047',
      verification_status: 'Pending',
      created_at: '2026-05-18T14:10:00Z',
    },
  ] as HospitalRecord[],

  bloodStock: [
    { id: 1, blood_bank_id: 1, blood_group: 'A+', component_type: 'Whole Blood', available_units: 48, reserved_units: 4, low_stock_threshold: 20, critical_threshold: 8, last_restocked_at: new Date().toISOString() },
    { id: 2, blood_bank_id: 1, blood_group: 'A-', component_type: 'Whole Blood', available_units: 14, reserved_units: 2, low_stock_threshold: 15, critical_threshold: 5, last_restocked_at: new Date().toISOString() },
    { id: 3, blood_bank_id: 1, blood_group: 'B+', component_type: 'Whole Blood', available_units: 52, reserved_units: 6, low_stock_threshold: 20, critical_threshold: 8, last_restocked_at: new Date().toISOString() },
    { id: 4, blood_bank_id: 1, blood_group: 'B-', component_type: 'Whole Blood', available_units: 9, reserved_units: 2, low_stock_threshold: 12, critical_threshold: 4, last_restocked_at: new Date().toISOString() },
    { id: 5, blood_bank_id: 1, blood_group: 'AB+', component_type: 'Whole Blood', available_units: 22, reserved_units: 1, low_stock_threshold: 10, critical_threshold: 4, last_restocked_at: new Date().toISOString() },
    { id: 6, blood_bank_id: 1, blood_group: 'AB-', component_type: 'Whole Blood', available_units: 6, reserved_units: 1, low_stock_threshold: 10, critical_threshold: 3, last_restocked_at: new Date().toISOString() },
    { id: 7, blood_bank_id: 1, blood_group: 'O+', component_type: 'Whole Blood', available_units: 85, reserved_units: 8, low_stock_threshold: 30, critical_threshold: 10, last_restocked_at: new Date().toISOString() },
    { id: 8, blood_bank_id: 1, blood_group: 'O-', component_type: 'Whole Blood', available_units: 11, reserved_units: 3, low_stock_threshold: 20, critical_threshold: 6, last_restocked_at: new Date().toISOString() },
  ] as BloodStockRecord[],

  bloodUnits: [
    { id: 1, unit_id: 'LD-2026-O101', blood_bank_id: 1, donor_id: 1, blood_group: 'O+', component_type: 'Whole Blood', volume_ml: 450, collection_date: '2026-10-28', expiry_date: '2026-12-02', storage_location: 'Cold Storage A-12', testing_status: 'Tested - Safe', unit_status: 'Available', created_at: '2026-10-28T10:00:00Z' },
    { id: 2, unit_id: 'LD-2026-O102', blood_bank_id: 1, donor_id: 1, blood_group: 'O+', component_type: 'Whole Blood', volume_ml: 450, collection_date: '2026-10-31', expiry_date: '2026-12-05', storage_location: 'Cold Storage A-13', testing_status: 'Tested - Safe', unit_status: 'Available', created_at: '2026-10-31T11:00:00Z' },
    { id: 3, unit_id: 'LD-2026-A201', blood_bank_id: 1, donor_id: 2, blood_group: 'A+', component_type: 'Whole Blood', volume_ml: 450, collection_date: '2026-10-24', expiry_date: '2026-11-28', storage_location: 'Cold Storage B-04', testing_status: 'Tested - Safe', unit_status: 'Available', created_at: '2026-10-24T09:30:00Z' },
    { id: 4, unit_id: 'LD-2026-B301', blood_bank_id: 1, donor_id: 3, blood_group: 'B-', component_type: 'Whole Blood', volume_ml: 450, collection_date: '2026-11-02', expiry_date: '2026-12-07', storage_location: 'Cold Storage B-19', testing_status: 'Tested - Safe', unit_status: 'Available', created_at: '2026-11-02T14:00:00Z' },
    { id: 5, unit_id: 'LD-2026-O901', blood_bank_id: 1, donor_id: 5, blood_group: 'O-', component_type: 'Whole Blood', volume_ml: 450, collection_date: '2026-11-03', expiry_date: '2026-12-08', storage_location: 'Critical Reserve Vault 1', testing_status: 'Tested - Safe', unit_status: 'Available', created_at: '2026-11-03T15:20:00Z' },
    { id: 6, unit_id: 'LD-2026-AB41', blood_bank_id: 1, donor_id: 4, blood_group: 'AB+', component_type: 'Whole Blood', volume_ml: 450, collection_date: '2026-10-20', expiry_date: '2026-11-24', storage_location: 'Cold Storage C-02', testing_status: 'Tested - Safe', unit_status: 'Available', created_at: '2026-10-20T12:15:00Z' },
    { id: 7, unit_id: 'LD-2026-B302', blood_bank_id: 1, donor_id: 3, blood_group: 'B-', component_type: 'Whole Blood', volume_ml: 450, collection_date: '2026-09-20', expiry_date: '2026-10-25', storage_location: 'Cold Storage Quarantined', testing_status: 'Tested - Safe', unit_status: 'Discarded - Expired', created_at: '2026-09-20T10:00:00Z' },
  ] as BloodUnitRecord[],

  bloodRequests: [
    {
      id: 1,
      request_code: 'REQ-2026-001',
      hospital_id: 1,
      patient_name: 'Jonathan Miller',
      patient_ref_id: 'PT-MED-4482',
      hospital_name: 'St. Jude General Hospital',
      blood_group: 'O-',
      component_type: 'Whole Blood',
      units_required: 3,
      units_fulfilled: 3,
      required_date: '2026-11-05',
      priority: 'Emergency - Critical',
      status: 'Fulfilled',
      contact_number: '+1 (555) 987-0911',
      doctor_name: 'Dr. Evelyn Howard',
      diagnosis_reason: 'Motor vehicle accident with severe hemorrhaging.',
      additional_notes: 'Urgent transfusion administered successfully.',
      approved_by_user_id: 1,
      approved_at: '2026-11-05T08:30:00Z',
      fulfilled_at: '2026-11-05T09:15:00Z',
      created_at: '2026-11-05T08:00:00Z',
    },
    {
      id: 2,
      request_code: 'REQ-2026-002',
      hospital_id: 2,
      patient_name: 'Maria Santos',
      patient_ref_id: 'PT-TRAUMA-912',
      hospital_name: 'Apex Trauma & Multispecialty',
      blood_group: 'B-',
      component_type: 'Whole Blood',
      units_required: 2,
      units_fulfilled: 2,
      required_date: '2026-11-06',
      priority: 'Urgent',
      status: 'Approved',
      contact_number: '+1 (555) 876-0911',
      doctor_name: 'Dr. James Thorne',
      diagnosis_reason: 'Emergency cardiovascular bypass surgery.',
      additional_notes: 'Pre-crossmatched units allocated.',
      approved_by_user_id: 1,
      approved_at: '2026-11-05T14:00:00Z',
      created_at: '2026-11-05T13:20:00Z',
    },
    {
      id: 3,
      request_code: 'REQ-2026-003',
      hospital_id: 1,
      patient_name: 'Samuel Bennett',
      patient_ref_id: 'PT-MED-4510',
      hospital_name: 'St. Jude General Hospital',
      blood_group: 'A+',
      component_type: 'Whole Blood',
      units_required: 4,
      units_fulfilled: 0,
      required_date: '2026-11-07',
      priority: 'Standard',
      status: 'Pending',
      contact_number: '+1 (555) 987-6543',
      doctor_name: 'Dr. K. Patel',
      diagnosis_reason: 'Scheduled oncological surgery transfusion preparation.',
      additional_notes: 'Routine verification needed.',
      created_at: '2026-11-05T16:45:00Z',
    },
    {
      id: 4,
      request_code: 'REQ-2026-004',
      hospital_id: 3,
      patient_name: 'Chloe Evans',
      patient_ref_id: 'PT-MEM-1088',
      hospital_name: 'City Care Memorial Hospital',
      blood_group: 'O+',
      component_type: 'Whole Blood',
      units_required: 2,
      units_fulfilled: 0,
      required_date: '2026-11-06',
      priority: 'Urgent',
      status: 'Pending',
      contact_number: '+1 (555) 765-0911',
      doctor_name: 'Dr. Cruz',
      diagnosis_reason: 'Severe acute anemia transfusion therapy.',
      additional_notes: 'Awaiting hospital account verification.',
      created_at: '2026-11-05T18:10:00Z',
    },
  ] as BloodRequestRecord[],

  donations: [
    {
      id: 1,
      donation_code: 'DON-REC-8801',
      donor_id: 1,
      blood_bank_id: 1,
      donation_date: '2026-11-01',
      blood_group: 'O+',
      component_type: 'Whole Blood',
      units_donated: 1,
      hemoglobin_level: 15.1,
      blood_pressure: '118/76',
      pulse_rate: 68,
      donation_status: 'Completed',
      nurse_or_phlebotomist: 'Nurse Lisa Ray',
      remarks: 'Donor felt comfortable throughout. Standard refreshment given.',
      certificate_issued: 1,
      created_at: '2026-11-01T10:30:00Z',
    },
    {
      id: 2,
      donation_code: 'DON-REC-8802',
      donor_id: 2,
      blood_bank_id: 1,
      donation_date: '2026-10-24',
      blood_group: 'A+',
      component_type: 'Whole Blood',
      units_donated: 1,
      hemoglobin_level: 13.8,
      blood_pressure: '122/80',
      pulse_rate: 74,
      donation_status: 'Completed',
      nurse_or_phlebotomist: 'Phleb. Marcus Cole',
      remarks: 'Smooth vein access. Rapid collection.',
      certificate_issued: 1,
      created_at: '2026-10-24T11:45:00Z',
    },
    {
      id: 3,
      donation_code: 'DON-REC-8803',
      donor_id: 3,
      blood_bank_id: 1,
      donation_date: '2026-11-02',
      blood_group: 'B-',
      component_type: 'Whole Blood',
      units_donated: 1,
      hemoglobin_level: 14.6,
      blood_pressure: '124/82',
      pulse_rate: 70,
      donation_status: 'Completed',
      nurse_or_phlebotomist: 'Nurse Lisa Ray',
      remarks: 'Rare group donation tagged for priority reserve.',
      certificate_issued: 1,
      created_at: '2026-11-02T14:15:00Z',
    },
    {
      id: 4,
      donation_code: 'DON-REC-8804',
      donor_id: 5,
      blood_bank_id: 1,
      donation_date: '2026-11-03',
      blood_group: 'O-',
      component_type: 'Whole Blood',
      units_donated: 1,
      hemoglobin_level: 15.5,
      blood_pressure: '116/74',
      pulse_rate: 66,
      donation_status: 'Completed',
      nurse_or_phlebotomist: 'Phleb. Marcus Cole',
      remarks: 'Universal donor donation into trauma emergency reserve.',
      certificate_issued: 1,
      created_at: '2026-11-03T15:30:00Z',
    },
  ] as DonationRecord[],

  auditLogs: [
    { id: 1, user_id: 1, action: 'SYSTEM_BOOT', entity_type: 'SYSTEM', entity_id: null, details: 'Rauf Blood Management System initialized', ip_address: '127.0.0.1', created_at: new Date().toISOString() },
    { id: 2, user_id: 1, action: 'REQUEST_FULFILL', entity_type: 'blood_requests', entity_id: 1, details: 'Emergency blood units issued to St. Jude', ip_address: '127.0.0.1', created_at: new Date().toISOString() },
  ] as AuditLogRecord[],
};

// Initialize or test the MySQL Connection Pool
export async function initDbPool(): Promise<DbStatus> {
  const host = process.env.DB_HOST || 'localhost';
  const port = Number(process.env.DB_PORT) || 3306;
  const user = process.env.DB_USER || 'root';
  const password = process.env.DB_PASSWORD || 'shaikrauf@12';
  const database = process.env.DB_NAME || 'blood_bank_db';

  try {
    // First connect without database to ensure database exists
    const rootConnection = await mysql.createConnection({
      host,
      port,
      user,
      password,
      connectTimeout: 4000,
    });

    await rootConnection.query(`CREATE DATABASE IF NOT EXISTS \`${database}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`);
    await rootConnection.end();

    // Now establish the connection pool to the database
    pool = mysql.createPool({
      host,
      port,
      user,
      password,
      database,
      waitForConnections: true,
      connectionLimit: 15,
      queueLimit: 0,
      connectTimeout: 4000,
    });

    // Test: SELECT 1;
    const [rows] = await pool.query('SELECT 1 as test');

    // Display connection success
    console.log('MySQL connected successfully');
    console.log(`Database: ${database}`);

    lastDbStatus = {
      connected: true,
      host,
      port,
      user,
      database,
      lastChecked: new Date().toISOString(),
      activeStorage: 'mysql',
      poolStats: {
        activeConnections: 1,
      },
    };
    return lastDbStatus;
  } catch (error: any) {
    const err = error as Error & { code?: string };
    lastDbStatus = {
      connected: false,
      host,
      port,
      user,
      database,
      errorMessage: err.message,
      errorCode: err.code || 'UNKNOWN',
      lastChecked: new Date().toISOString(),
      activeStorage: 'memory-mirror',
    };
    console.warn(`[RAUF BLOOD DB NOTICE] Could not connect to local MySQL at ${host}:${port} (${err.code || err.message}).`);
    console.warn(`[RAUF BLOOD DB NOTICE] Active mode: High-fidelity Live Seeded Memory Store.`);
    console.warn(`[RAUF BLOOD DB NOTICE] When running on your local machine with MySQL 8.0 running on port 3306, it will automatically connect to MySQL!`);
    return lastDbStatus;
  }
}

export function getDbPool(): Pool | null {
  return pool;
}

export function getDbStatus(): DbStatus {
  return lastDbStatus;
}
