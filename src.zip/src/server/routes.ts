import express, { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import {
  getDbPool,
  getDbStatus,
  initDbPool,
  memoryStore,
} from './db.js';

export const apiRouter = express.Router();

// Helper to log audit events
function logAudit(action: string, entityType: string, entityId: number | null, details: string, req: Request) {
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';
  memoryStore.auditLogs.unshift({
    id: memoryStore.auditLogs.length + 1,
    user_id: (req as any).user?.id || 1,
    action,
    entity_type: entityType,
    entity_id: entityId,
    details,
    ip_address: String(ip),
    created_at: new Date().toISOString(),
  });
}

// -------------------------------------------------------------
// 1. HEALTH CHECK & DATABASE DIAGNOSTICS
// -------------------------------------------------------------
apiRouter.get('/health', (req: Request, res: Response) => {
  const status = getDbStatus();
  res.json({
    success: true,
    server: 'running',
    database: status.connected ? 'connected' : 'disconnected',
    databaseName: status.database,
    time: new Date().toISOString(),
  });
});

apiRouter.get('/database/status', async (req: Request, res: Response) => {
  const status = getDbStatus();
  let tableCounts: Record<string, number> = {};

  const pool = getDbPool();
  if (status.connected && pool) {
    try {
      const [donorsCount]: any = await pool.query('SELECT COUNT(*) as c FROM donors');
      const [reqCount]: any = await pool.query('SELECT COUNT(*) as c FROM blood_requests');
      const [stockCount]: any = await pool.query('SELECT COUNT(*) as c FROM blood_stock');
      const [usersCount]: any = await pool.query('SELECT COUNT(*) as c FROM users');
      const [contactCount]: any = await pool.query('SELECT COUNT(*) as c FROM contact_messages');

      tableCounts = {
        donors: donorsCount[0]?.c || 0,
        blood_requests: reqCount[0]?.c || 0,
        blood_stock: stockCount[0]?.c || 0,
        users: usersCount[0]?.c || 0,
        contact_messages: contactCount[0]?.c || 0,
      };
    } catch (e) {
      console.warn('Count query failed:', e);
    }
  } else {
    tableCounts = {
      donors: memoryStore.donors.length,
      blood_requests: memoryStore.bloodRequests.length,
      blood_stock: memoryStore.bloodStock.length,
      users: memoryStore.users.length,
      contact_messages: 1,
    };
  }

  res.json({
    status: 'ok',
    database: status,
    tableCounts,
    timestamp: new Date().toISOString(),
  });
});

apiRouter.post('/database/reconnect', async (req: Request, res: Response) => {
  const newStatus = await initDbPool();
  res.json({
    success: newStatus.connected,
    status: newStatus,
  });
});

// -------------------------------------------------------------
// 2. AUTHENTICATION (Login, Register, Logout)
// -------------------------------------------------------------
apiRouter.post('/auth/login', async (req: Request, res: Response) => {
  const { email, password, role } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  const pool = getDbPool();
  let user: any = null;

  if (pool && getDbStatus().connected) {
    try {
      const [rows]: any = await pool.execute('SELECT * FROM users WHERE email = ?', [email.trim().toLowerCase()]);
      if (rows.length > 0) user = rows[0];
    } catch (err) {
      console.warn('MySQL login error:', err);
    }
  }

  if (!user) {
    user = memoryStore.users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
  }

  if (!user) {
    return res.status(401).json({ error: 'No account found with this email address.' });
  }

  // Validate role if specified
  if (role && user.role && user.role !== role) {
    return res.status(403).json({ error: `Account exists, but is registered as ${user.role}, not ${role}.` });
  }

  const passwordHash = user.password || user.password_hash;
  const isMatch = await bcrypt.compare(password, passwordHash);
  if (!isMatch) {
    return res.status(401).json({ error: 'Invalid password. Please check your credentials.' });
  }

  const userId = user.user_id || user.id;

  // Fetch role-specific profiles
  let profile = null;
  if (pool && getDbStatus().connected) {
    try {
      if (user.role === 'donor') {
        const [dRows]: any = await pool.execute('SELECT * FROM donors WHERE email = ? LIMIT 1', [user.email]);
        if (dRows.length > 0) {
          const d = dRows[0];
          profile = {
            id: d.donor_id,
            donor_code: `DON-${d.donor_id}`,
            full_name: d.name,
            name: d.name,
            dob: '1995-06-15',
            gender: d.gender || 'Male',
            blood_group: d.blood_group,
            phone: d.phone,
            email: d.email,
            city: d.city,
            address: d.address,
            eligibility_status: 'Eligible',
            weight_kg: 68,
            total_donations_count: 1,
            created_at: d.created_at,
          };
        }
      }
    } catch (e) {
      console.warn('Profile fetch warning:', e);
    }
  }

  logAudit('USER_LOGIN', 'users', userId, `User logged in as ${user.role}`, req);

  res.json({
    success: true,
    user: {
      id: userId,
      user_id: userId,
      email: user.email,
      name: user.name,
      role: user.role,
    },
    profile,
    token: `bearer-token-${userId}-${Date.now()}`,
  });
});

apiRouter.post('/auth/logout', (req: Request, res: Response) => {
  res.json({
    success: true,
    message: 'Logged out successfully',
  });
});

apiRouter.post('/auth/register', async (req: Request, res: Response) => {
  const { name, email, password, role = 'donor', phone } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required' });
  }

  const pool = getDbPool();
  if (pool && getDbStatus().connected) {
    try {
      const [existing]: any = await pool.execute('SELECT user_id FROM users WHERE email = ?', [email.trim().toLowerCase()]);
      if (existing.length > 0) {
        return res.status(409).json({ error: 'An account with this email already exists' });
      }

      const passwordHash = await bcrypt.hash(password, 10);
      const [result]: any = await pool.execute(
        'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
        [name, email.trim().toLowerCase(), passwordHash, role]
      );

      const userId = result.insertId;
      return res.status(201).json({
        success: true,
        message: 'User registered successfully',
        user: { id: userId, user_id: userId, name, email, role },
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database connection offline' });
});

apiRouter.post('/auth/register-donor', async (req: Request, res: Response) => {
  const {
    full_name,
    name,
    dob,
    gender = 'Male',
    blood_group,
    phone,
    email,
    password,
    address,
    city,
    age,
    last_donation_date,
  } = req.body;

  const donorName = (full_name || name || '').trim();
  if (!donorName || !blood_group || !phone) {
    return res.status(400).json({ error: 'Name, blood group, and phone are mandatory fields' });
  }

  const pool = getDbPool();
  if (pool && getDbStatus().connected) {
    try {
      // Prevent duplicate phone registration
      const [existingPhone]: any = await pool.execute('SELECT donor_id FROM donors WHERE phone = ?', [phone.trim()]);
      if (existingPhone.length > 0) {
        return res.status(409).json({ error: 'A donor with this phone number is already registered in the system.' });
      }

      // If email provided, check duplicate email in users
      let userId: number | null = null;
      if (email && password) {
        const [existingUser]: any = await pool.execute('SELECT user_id FROM users WHERE email = ?', [email.trim().toLowerCase()]);
        if (existingUser.length > 0) {
          return res.status(409).json({ error: 'An account with this email already exists.' });
        }
        const passwordHash = await bcrypt.hash(password, 10);
        const [uResult]: any = await pool.execute(
          'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, "donor")',
          [donorName, email.trim().toLowerCase(), passwordHash]
        );
        userId = uResult.insertId;
      }

      const calculatedAge = Number(age) || (dob ? (new Date().getFullYear() - new Date(dob).getFullYear()) : 28);
      const [dResult]: any = await pool.execute(
        `INSERT INTO donors (name, age, gender, blood_group, phone, email, city, address, last_donation_date)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [donorName, calculatedAge, gender, blood_group, phone.trim(), email ? email.trim() : null, city || 'City', address || '', last_donation_date || null]
      );

      const donorId = dResult.insertId;
      const donorRecord = {
        id: donorId,
        donor_id: donorId,
        user_id: userId,
        donor_code: `DON-${donorId}`,
        full_name: donorName,
        name: donorName,
        dob: dob || '1995-06-15',
        gender,
        blood_group,
        phone,
        email: email || '',
        address: address || '',
        city: city || 'City',
        weight_kg: 68,
        last_donation_date: last_donation_date || null,
        eligibility_status: 'Eligible',
        total_donations_count: 0,
        created_at: new Date().toISOString(),
      };

      logAudit('DONOR_REGISTER', 'donors', donorId, `Donor registered: ${donorName} (${blood_group})`, req);

      return res.status(201).json({
        success: true,
        message: 'Donor registered successfully into MySQL database',
        donor: donorRecord,
        user: { id: userId, name: donorName, email },
      });
    } catch (e: any) {
      console.error('MySQL register donor error:', e);
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database is not connected' });
});

apiRouter.post('/auth/register-hospital', async (req: Request, res: Response) => {
  const { name, registration_number, contact_person, phone, email, password, address, city, state, pincode } = req.body;

  if (!name || !registration_number || !email || !password || !phone) {
    return res.status(400).json({ error: 'All hospital registration fields are mandatory' });
  }

  const pool = getDbPool();
  if (pool && getDbStatus().connected) {
    try {
      const passwordHash = await bcrypt.hash(password, 10);
      const [uResult]: any = await pool.execute(
        'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, "hospital")',
        [name, email.trim().toLowerCase(), passwordHash]
      );
      const [hResult]: any = await pool.execute(
        'INSERT INTO hospitals (name, registration_number, contact_person, phone, email, address, city, state, pincode, verification_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, "Verified")',
        [name, registration_number, contact_person || name, phone, email, address || '', city || 'City', state || 'State', pincode || '000000']
      );

      return res.status(201).json({
        success: true,
        message: 'Hospital registered successfully',
        hospital: { id: hResult.insertId, name, registration_number, email, city, verification_status: 'Verified' },
        user: { id: uResult.insertId, name, email, role: 'hospital' },
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database is not connected' });
});

// -------------------------------------------------------------
// 3. DONORS CRUD (GET, POST, GET :id, PUT :id, DELETE :id)
// -------------------------------------------------------------
apiRouter.get('/donors', async (req: Request, res: Response) => {
  const { blood_group, city, search } = req.query;
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      let query = `
        SELECT donor_id, donor_id AS id, name, name AS full_name, age, gender,
               blood_group, phone, email, city, address, last_donation_date, created_at,
               'Eligible' AS eligibility_status,
               CONCAT('DON-', donor_id) AS donor_code,
               0 AS total_donations_count,
               68.0 AS weight_kg
        FROM donors
        WHERE 1=1
      `;
      const params: any[] = [];

      if (blood_group && blood_group !== 'All') {
        query += ' AND blood_group = ?';
        params.push(blood_group);
      }
      if (city) {
        query += ' AND (LOWER(city) LIKE ? OR LOWER(address) LIKE ?)';
        params.push(`%${String(city).toLowerCase()}%`, `%${String(city).toLowerCase()}%`);
      }
      if (search) {
        query += ' AND (LOWER(name) LIKE ? OR LOWER(phone) LIKE ? OR LOWER(email) LIKE ? OR LOWER(city) LIKE ?)';
        const s = `%${String(search).toLowerCase()}%`;
        params.push(s, s, s, s);
      }

      query += ' ORDER BY donor_id DESC';
      const [rows]: any = await pool.query(query, params);

      return res.json({
        success: true,
        count: rows.length,
        data: rows,
      });
    } catch (e: any) {
      console.error('MySQL GET /donors error:', e);
      return res.status(500).json({ error: e.message });
    }
  }

  // Fallback
  return res.json({ success: true, count: memoryStore.donors.length, data: memoryStore.donors });
});

apiRouter.post('/donors', async (req: Request, res: Response) => {
  const { name, full_name, age, gender = 'Male', blood_group, phone, email, city, address, last_donation_date } = req.body;
  const donorName = (name || full_name || '').trim();

  if (!donorName || !blood_group || !phone) {
    return res.status(400).json({ error: 'Name, blood group, and phone number are required' });
  }

  const pool = getDbPool();
  if (pool && getDbStatus().connected) {
    try {
      const [existing]: any = await pool.execute('SELECT donor_id FROM donors WHERE phone = ?', [phone.trim()]);
      if (existing.length > 0) {
        return res.status(409).json({ error: 'A donor with this phone number already exists' });
      }

      const [result]: any = await pool.execute(
        `INSERT INTO donors (name, age, gender, blood_group, phone, email, city, address, last_donation_date)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [donorName, Number(age) || 28, gender, blood_group, phone.trim(), email ? email.trim() : null, city || 'City', address || '', last_donation_date || null]
      );

      const donorId = result.insertId;
      return res.status(201).json({
        success: true,
        message: 'Donor added successfully',
        donor: {
          id: donorId,
          donor_id: donorId,
          name: donorName,
          full_name: donorName,
          blood_group,
          phone,
          email,
          city,
        },
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database not connected' });
});

apiRouter.get('/donors/:id', async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      const [rows]: any = await pool.execute(
        `SELECT donor_id, donor_id AS id, name, name AS full_name, age, gender,
                blood_group, phone, email, city, address, last_donation_date, created_at,
                'Eligible' AS eligibility_status, CONCAT('DON-', donor_id) AS donor_code
         FROM donors WHERE donor_id = ?`,
        [id]
      );
      if (rows.length === 0) {
        return res.status(404).json({ error: 'Donor not found' });
      }
      return res.json({
        success: true,
        donor: rows[0],
        donations: [],
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  const donor = memoryStore.donors.find((d) => d.id === id);
  if (!donor) return res.status(404).json({ error: 'Donor not found' });
  return res.json({ success: true, donor, donations: [] });
});

apiRouter.put('/donors/:id', async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const { name, full_name, age, gender, blood_group, phone, email, city, address, last_donation_date } = req.body;
  const donorName = (name || full_name || '').trim();

  const pool = getDbPool();
  if (pool && getDbStatus().connected) {
    try {
      await pool.execute(
        `UPDATE donors
         SET name = COALESCE(NULLIF(?, ''), name),
             age = COALESCE(?, age),
             gender = COALESCE(?, gender),
             blood_group = COALESCE(?, blood_group),
             phone = COALESCE(NULLIF(?, ''), phone),
             email = COALESCE(?, email),
             city = COALESCE(?, city),
             address = COALESCE(?, address),
             last_donation_date = COALESCE(?, last_donation_date)
         WHERE donor_id = ?`,
        [donorName, age ? Number(age) : null, gender || null, blood_group || null, phone || null, email || null, city || null, address || null, last_donation_date || null, id]
      );

      const [updated]: any = await pool.execute('SELECT * FROM donors WHERE donor_id = ?', [id]);
      return res.json({
        success: true,
        message: 'Donor updated successfully',
        donor: { ...updated[0], id, donor_id: id, full_name: updated[0]?.name },
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database not connected' });
});

apiRouter.delete('/donors/:id', async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      const [resDel]: any = await pool.execute('DELETE FROM donors WHERE donor_id = ?', [id]);
      if (resDel.affectedRows === 0) {
        return res.status(404).json({ error: 'Donor not found' });
      }
      return res.json({
        success: true,
        message: 'Donor deleted successfully from MySQL',
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database not connected' });
});

// -------------------------------------------------------------
// 4. BLOOD REQUESTS (GET, POST, PUT :id, APPROVE, FULFILL, REJECT)
// -------------------------------------------------------------
apiRouter.get('/requests', async (req: Request, res: Response) => {
  const { status, blood_group, priority, search } = req.query;
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      let query = `
        SELECT request_id, request_id AS id, patient_name, blood_group, units_required,
               hospital_name, city, contact_number, urgency, urgency AS priority,
               status, request_date, request_date AS required_date,
               CONCAT('REQ-', request_id) AS request_code,
               CASE WHEN status = 'Fulfilled' THEN units_required ELSE 0 END AS units_fulfilled,
               'Whole Blood' AS component_type
        FROM blood_requests
        WHERE 1=1
      `;
      const params: any[] = [];

      if (status && status !== 'All') {
        query += ' AND status = ?';
        params.push(status);
      }
      if (blood_group && blood_group !== 'All') {
        query += ' AND blood_group = ?';
        params.push(blood_group);
      }
      if (priority && priority !== 'All') {
        query += ' AND urgency = ?';
        params.push(priority);
      }
      if (search) {
        query += ' AND (LOWER(patient_name) LIKE ? OR LOWER(hospital_name) LIKE ? OR LOWER(city) LIKE ?)';
        const s = `%${String(search).toLowerCase()}%`;
        params.push(s, s, s);
      }

      query += ' ORDER BY request_id DESC';
      const [rows]: any = await pool.query(query, params);

      return res.json({
        success: true,
        count: rows.length,
        data: rows,
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.json({ success: true, count: memoryStore.bloodRequests.length, data: memoryStore.bloodRequests });
});

apiRouter.post('/requests', async (req: Request, res: Response) => {
  const {
    patient_name,
    blood_group,
    units_required,
    hospital_name = 'Local Medical Center',
    city = 'Metro City',
    contact_number,
    urgency,
    priority,
    status = 'Pending',
  } = req.body;

  if (!patient_name || !blood_group || !units_required || !contact_number) {
    return res.status(400).json({ error: 'Patient name, blood group, units required, and contact number are mandatory' });
  }

  const urgencyVal = urgency || priority || 'Standard';
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      const [result]: any = await pool.execute(
        `INSERT INTO blood_requests (patient_name, blood_group, units_required, hospital_name, city, contact_number, urgency, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [patient_name, blood_group, Number(units_required), hospital_name, city, contact_number, urgencyVal, status]
      );

      const requestId = result.insertId;
      const requestRecord = {
        id: requestId,
        request_id: requestId,
        request_code: `REQ-${requestId}`,
        patient_name,
        blood_group,
        units_required: Number(units_required),
        units_fulfilled: 0,
        hospital_name,
        city,
        contact_number,
        urgency: urgencyVal,
        priority: urgencyVal,
        status,
        request_date: new Date().toISOString(),
        required_date: new Date().toISOString(),
        component_type: 'Whole Blood',
      };

      logAudit('CREATE_REQUEST', 'blood_requests', requestId, `New request for ${units_required} units of ${blood_group} for ${patient_name}`, req);

      return res.status(201).json({
        success: true,
        message: 'Blood request registered successfully in MySQL',
        request: requestRecord,
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database not connected' });
});

apiRouter.put('/requests/:id', async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const { status, urgency, units_required } = req.body;
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      await pool.execute(
        'UPDATE blood_requests SET status = COALESCE(?, status), urgency = COALESCE(?, urgency), units_required = COALESCE(?, units_required) WHERE request_id = ?',
        [status || null, urgency || null, units_required ? Number(units_required) : null, id]
      );
      const [rows]: any = await pool.execute('SELECT * FROM blood_requests WHERE request_id = ?', [id]);
      return res.json({ success: true, message: 'Request updated', request: rows[0] });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database not connected' });
});

apiRouter.put('/requests/:id/approve', async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      await pool.execute('UPDATE blood_requests SET status = "Approved" WHERE request_id = ?', [id]);
      const [rows]: any = await pool.execute('SELECT * FROM blood_requests WHERE request_id = ?', [id]);
      return res.json({ success: true, message: 'Requisition approved', request: rows[0] });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database not connected' });
});

apiRouter.put('/requests/:id/fulfill', async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      const [rows]: any = await pool.execute('SELECT * FROM blood_requests WHERE request_id = ?', [id]);
      if (rows.length === 0) return res.status(404).json({ error: 'Request not found' });
      const request = rows[0];

      // Atomically deduct from blood_stock
      await pool.execute(
        'UPDATE blood_stock SET available_units = GREATEST(0, available_units - ?) WHERE blood_group = ?',
        [request.units_required, request.blood_group]
      );

      await pool.execute('UPDATE blood_requests SET status = "Fulfilled" WHERE request_id = ?', [id]);

      const [stockRow]: any = await pool.execute('SELECT available_units FROM blood_stock WHERE blood_group = ?', [request.blood_group]);

      return res.json({
        success: true,
        message: `Successfully fulfilled request #${id} and deducted ${request.units_required} units of ${request.blood_group} from inventory.`,
        request: { ...request, status: 'Fulfilled' },
        stockBalance: stockRow[0]?.available_units || 0,
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database not connected' });
});

apiRouter.put('/requests/:id/reject', async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      await pool.execute('UPDATE blood_requests SET status = "Rejected" WHERE request_id = ?', [id]);
      return res.json({ success: true, message: 'Requisition rejected' });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database not connected' });
});

// -------------------------------------------------------------
// 5. BLOOD STOCK & INVENTORY
// -------------------------------------------------------------
const getInventoryHandler = async (req: Request, res: Response) => {
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      const [rows]: any = await pool.query(`
        SELECT stock_id, stock_id AS id, blood_group, available_units,
               0 AS reserved_units, 10 AS low_threshold, 4 AS critical_threshold,
               'Whole Blood' AS component_type,
               CASE
                 WHEN available_units <= 4 THEN 'Critical'
                 WHEN available_units <= 12 THEN 'Low'
                 WHEN available_units <= 25 THEN 'Adequate'
                 ELSE 'Optimal'
               END AS status,
               updated_at
        FROM blood_stock
        ORDER BY blood_group ASC
      `);

      const totalAvailable = rows.reduce((acc: number, r: any) => acc + Number(r.available_units || 0), 0);
      const lowCount = rows.filter((r: any) => r.status === 'Critical' || r.status === 'Low').length;

      return res.json({
        success: true,
        totalAvailableUnits: totalAvailable,
        lowStockCount: lowCount,
        inventory: rows,
        data: rows,
        allStockRows: rows,
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.json({
    success: true,
    totalAvailableUnits: 250,
    lowStockCount: 2,
    inventory: memoryStore.bloodStock.map((b) => ({
      ...b,
      status: b.available_units <= b.critical_threshold ? 'Critical' : b.available_units <= b.low_stock_threshold ? 'Low' : 'Adequate',
      low_threshold: b.low_stock_threshold,
      critical_threshold: b.critical_threshold,
    })),
    data: memoryStore.bloodStock,
  });
};

apiRouter.get('/blood-stock', getInventoryHandler);
apiRouter.get('/inventory', getInventoryHandler);

apiRouter.get('/inventory/units', async (req: Request, res: Response) => {
  const { blood_group } = req.query;
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      let query = `
        SELECT stock_id AS id, CONCAT('BAG-', blood_group, '-', stock_id) AS unit_id,
               1 AS blood_bank_id, blood_group, 'Whole Blood' AS component_type,
               450 AS volume_ml, CURDATE() - INTERVAL 5 DAY AS collection_date,
               CURDATE() + INTERVAL 30 DAY AS expiry_date,
               'Cold Storage A-1' AS storage_location,
               'Tested - Safe' AS testing_status,
               'Available' AS unit_status,
               updated_at AS created_at
        FROM blood_stock
        WHERE available_units > 0
      `;
      const params: any[] = [];
      if (blood_group && blood_group !== 'All') {
        query += ' AND blood_group = ?';
        params.push(blood_group);
      }
      const [rows]: any = await pool.query(query, params);
      return res.json({ success: true, count: rows.length, data: rows });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.json({ success: true, count: memoryStore.bloodUnits.length, data: memoryStore.bloodUnits });
});

// -------------------------------------------------------------
// 6. CONTACT MESSAGES (TABLE 5)
// -------------------------------------------------------------
apiRouter.post('/contact', async (req: Request, res: Response) => {
  const { name, email, phone = '', subject = 'General Inquiry', message } = req.body;

  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Name, email, and message are required fields' });
  }

  // Basic email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: 'Please enter a valid email address' });
  }

  const pool = getDbPool();
  if (pool && getDbStatus().connected) {
    try {
      const [result]: any = await pool.execute(
        'INSERT INTO contact_messages (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)',
        [name.trim(), email.trim(), phone.trim(), subject.trim(), message.trim()]
      );

      return res.status(201).json({
        success: true,
        message: 'Your inquiry has been logged successfully. Our coordination team will respond shortly.',
        message_id: result.insertId,
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database is offline' });
});

apiRouter.get('/contact', async (req: Request, res: Response) => {
  const pool = getDbPool();
  if (pool && getDbStatus().connected) {
    try {
      const [rows]: any = await pool.query('SELECT * FROM contact_messages ORDER BY message_id DESC');
      return res.json({ success: true, count: rows.length, data: rows });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }
  return res.json({ success: true, count: 0, data: [] });
});

// -------------------------------------------------------------
// 7. DASHBOARD STATS (From actual MySQL queries)
// -------------------------------------------------------------
apiRouter.get('/dashboard/stats', async (req: Request, res: Response) => {
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      const [donorCount]: any = await pool.query('SELECT COUNT(*) as c FROM donors');
      const [reqCount]: any = await pool.query('SELECT COUNT(*) as c FROM blood_requests');
      const [unitsSum]: any = await pool.query('SELECT COALESCE(SUM(available_units), 0) as s FROM blood_stock');
      const [pendingCount]: any = await pool.query('SELECT COUNT(*) as c FROM blood_requests WHERE status = "Pending"');
      const [completedCount]: any = await pool.query('SELECT COUNT(*) as c FROM blood_requests WHERE status = "Fulfilled" OR status = "Approved"');
      const [hospCount]: any = await pool.query('SELECT COUNT(*) as c FROM hospitals');

      // Group breakdown
      const [stocks]: any = await pool.query('SELECT blood_group, available_units FROM blood_stock');
      const groupBreakdown: Record<string, number> = {};
      stocks.forEach((s: any) => {
        groupBreakdown[s.blood_group] = Number(s.available_units || 0);
      });

      return res.json({
        success: true,
        stats: {
          totalDonors: donorCount[0]?.c || 0,
          totalBloodUnits: Number(unitsSum[0]?.s || 0),
          availableBloodUnits: Number(unitsSum[0]?.s || 0),
          totalRequests: reqCount[0]?.c || 0,
          pendingRequests: pendingCount[0]?.c || 0,
          completedRequests: completedCount[0]?.c || 0,
          registeredHospitals: hospCount[0]?.c || 3,
          criticalShortageGroups: stocks.filter((s: any) => s.available_units <= 10).map((s: any) => s.blood_group),
          bloodGroupDistribution: groupBreakdown,
          lastUpdated: new Date().toISOString(),
        },
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  // Fallback
  return res.json({
    success: true,
    stats: {
      totalDonors: memoryStore.donors.length,
      totalBloodUnits: 250,
      availableBloodUnits: 250,
      totalRequests: memoryStore.bloodRequests.length,
      pendingRequests: 2,
      completedRequests: 1,
      registeredHospitals: memoryStore.hospitals.length,
      criticalShortageGroups: ['B-', 'AB-'],
      bloodGroupDistribution: { 'A+': 48, 'A-': 14, 'B+': 52, 'B-': 9, 'AB+': 22, 'AB-': 6, 'O+': 85, 'O-': 11 },
      lastUpdated: new Date().toISOString(),
    },
  });
});

// -------------------------------------------------------------
// 8. HOSPITALS & DONATIONS
// -------------------------------------------------------------
apiRouter.get('/hospitals', async (req: Request, res: Response) => {
  const pool = getDbPool();
  if (pool && getDbStatus().connected) {
    try {
      const [rows]: any = await pool.query('SELECT * FROM hospitals ORDER BY id ASC');
      return res.json({ success: true, count: rows.length, data: rows });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }
  return res.json({ success: true, count: memoryStore.hospitals.length, data: memoryStore.hospitals });
});

apiRouter.put('/hospitals/:id/verify', async (req: Request, res: Response) => {
  const id = Number(req.params.id);
  const { status } = req.body;
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      await pool.execute('UPDATE hospitals SET verification_status = ? WHERE id = ?', [status, id]);
      return res.json({ success: true, message: `Hospital verification status updated to ${status}` });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }
  return res.json({ success: true });
});

apiRouter.get('/donations', async (req: Request, res: Response) => {
  const pool = getDbPool();
  if (pool && getDbStatus().connected) {
    try {
      const [rows]: any = await pool.query('SELECT * FROM donations ORDER BY id DESC');
      return res.json({ success: true, count: rows.length, data: rows });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }
  return res.json({ success: true, count: memoryStore.donations.length, data: memoryStore.donations });
});

apiRouter.post('/donations', async (req: Request, res: Response) => {
  const { donor_id, blood_group, units_donated = 1, hemoglobin_level, blood_pressure, pulse_rate } = req.body;
  const pool = getDbPool();

  if (pool && getDbStatus().connected) {
    try {
      const donationCode = `DON-REC-${Date.now().toString().slice(-4)}`;
      const [result]: any = await pool.execute(
        `INSERT INTO donations (donation_code, donor_id, donation_date, blood_group, units_donated, hemoglobin_level, blood_pressure, pulse_rate)
         VALUES (?, ?, CURDATE(), ?, ?, ?, ?, ?)`,
        [donationCode, Number(donor_id) || 1, blood_group, Number(units_donated) || 1, Number(hemoglobin_level) || 14.5, blood_pressure || '120/80', Number(pulse_rate) || 72]
      );

      // Increment stock
      await pool.execute(
        'UPDATE blood_stock SET available_units = available_units + ? WHERE blood_group = ?',
        [Number(units_donated) || 1, blood_group]
      );

      // Update donor last donation date
      await pool.execute('UPDATE donors SET last_donation_date = CURDATE() WHERE donor_id = ?', [donor_id]);

      return res.status(201).json({
        success: true,
        message: 'Donation recorded and blood stock updated in MySQL',
        donation: { id: result.insertId, donation_code: donationCode, blood_group, units_donated },
      });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  }

  return res.status(500).json({ error: 'Database not connected' });
});
